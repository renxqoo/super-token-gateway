import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { cpus } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { SQL } from "bun";
const here = dirname(fileURLToPath(import.meta.url));
const fixtureModule = pathToFileURL(join(process.cwd(),"tests/support/native-fixture.ts")).href;
const samplerModule = pathToFileURL(join(process.cwd(),"scripts/benchmark-metrics.ts")).href;
const uid = () => randomUUID();
const stages = 2;
const batchMax = 128;
const collectionMs = 8;
const inflightMax = 8192;
const deadlineMs = 5000;
const wall = () => performance.timeOrigin + performance.now();
const sleep = Bun.sleep;

async function consume(port, token) {
  const url = "http://127.0.0.1:" + port;
  async function send(path, body) {
    const res = await fetch(url + path, { method: "POST", headers: { authorization: "Bearer " + token,"content-type":"application/json" },body: JSON.stringify(body) });
    if (res.status !== 200) throw new Error("consumer response " + res.status + " " + path);
    return res.json();
  }
  for (;;) {
    const page = await send("/claim",{});
    if (page.stop) break;
    if (!page.events.length) { await sleep(3); continue; }
    for (const e of page.events) {
      assert.equal(e.customer_atoms,100);assert.equal(e.supplier_atoms,59);
      assert.deepEqual([e.input_tokens,e.cached_tokens,e.output_tokens,e.reasoning_tokens],[7,3,5,2]);
      assert([1,2].includes(e.revision));assert(e.event_id && e.request_id && e.attempt_id);
    }
    const ids = page.events.map(e=>e.event_id);
    const ack = await send("/ack",{lease:page.lease,ids});
    assert.equal(ack.acknowledged,ids.length);
    await send("/observed",{at:wall(),events:page.events.map(e=>[e.request_id,e.event_id,e.revision])});
  }
}
async function run() {
  if (Bun.argv[2] === "consumer") return consume(Number(Bun.argv[3]), process.env.COMPACT_OBSERVER_TOKEN);
  const rate = Number(Bun.argv[2] ?? 3000);
  const seconds = Number(Bun.argv[3] ?? 60);
  const output = Bun.argv[4] ?? join(here,"result.json");
  assert(Number.isSafeInteger(rate) && rate>0 && rate<=6000);
  assert(Number.isSafeInteger(seconds) && seconds>0 && seconds<=60);
  const count=seconds*rate;
  const {createNativeFixture}=await import(fixtureModule);
  const {startProcessSampler}=await import(samplerModule);
  const fixture=await createNativeFixture({
    postgresToolsDirectory: join(process.cwd(),".local/toolchain/pg17/bin"),redisServer:join(process.cwd(),".local/toolchain/redis74/bin/redis-server"),
    diskBudgetBytes: 10*1024**3,truncateProcessOutput:true
  });
  let primary,standby,db,rd,sampler,http,child,stopping=false,result;
  const timings=[];
  async function measure(name,n,run){
    const before=wall();
    const result=await run();
    timings.push([before,name,n,wall()-before]);
    return result;
  }
  const plans=[];
  const planBoundaries=[1200,4800,9000,14800,25000,37500,49000];
  async function checkPlans(age,batch){
    if(!planBoundaries.length || age<planBoundaries[0])return;
    planBoundaries.shift();
    const running=plans.at(-1);
    if(running?.pending)return;
    const trace={atMs:age,size:batch.length,pending:true};
    plans.push(trace);
    const tap=(label,conn)=>function(tags,...args){
      const sql=tags.reduce((s,part,i)=>s+(i?('$'+i):'')+part,'');
      return conn.unsafe("EXPLAIN (ANALYZE,BUFFERS,SETTINGS,FORMAT JSON) "+sql,args).then(x=>{trace[label]=x[0]['QUERY PLAN']; return [];});
    };
    try {
      await terminalWitness(batch,tap('terminal',rd),true);
      await grantWitness(batch,tap('grant',rd),true);
      trace.statistics=await db`SELECT relname,n_live_tup::int,n_mod_since_analyze::int,last_autoanalyze,autoanalyze_count::int FROM pg_stat_user_tables WHERE schemaname='compact'`;
    }catch(error){trace.error=String(error);}
    trace.pending=false;
  }
  
  async function grant(batch) {
    return (await db`SELECT compact.grant_batch(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.command)}::uuid[],${batch.map(x=>x.wallet)}::int[])::text[] ids`)[0].ids;
  }
  async function settle(batch) {
    return (await db`SELECT compact.settle_batch(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.first)}::uuid[],${batch.map(x=>x.final)}::uuid[],${batch.map(x=>x.input)}::int[],${batch.map(x=>x.cached)}::int[],${batch.map(x=>x.output)}::int[],${batch.map(x=>x.reasoning)}::int[])::text[] ids`)[0].ids;
  }
  async function grantWitness(batch,conn=rd,explain=false) {
    const rows=await conn`
      SELECT p.request_id FROM unnest(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.command)}::uuid[],${batch.map(x=>x.wallet)}::int[]) i(id,attempt,command,wallet_id)
      JOIN LATERAL (SELECT * FROM compact.permit pp WHERE pp.request_id=i.id LIMIT 1) p ON
        (p.attempt_id,p.command_id,p.wallet_id)=(i.attempt,i.command,i.wallet_id)
      WHERE pg_is_in_recovery() AND p.epoch=1 AND p.tariff=1 AND p.customer_hold=100 AND p.supplier_hold=100 AND p.cell=i.wallet_id%16`;
    if(!explain)assert.equal(rows.length,batch.length);
  }
  async function terminalWitness(batch,conn=rd,explain=false) {
    const rows=await conn`
      SELECT t.request_id FROM unnest(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.first)}::uuid[],${batch.map(x=>x.final)}::uuid[]) i(id,attempt,e1,e2)
      JOIN LATERAL (SELECT p1.attempt_id FROM compact.permit p1 WHERE p1.request_id=i.id LIMIT 1) p ON p.attempt_id=i.attempt
      JOIN LATERAL (SELECT * FROM compact.terminal t1 WHERE t1.request_id=i.id LIMIT 1) t ON t.first_event=i.e1 AND t.final_event=i.e2
      JOIN LATERAL (SELECT o.request_id,o.revision FROM compact.outbox o WHERE o.event_id=i.e1 LIMIT 1) o1 ON o1.request_id=i.id AND o1.revision=1
      JOIN LATERAL (SELECT o.request_id,o.revision FROM compact.outbox o WHERE o.event_id=i.e2 LIMIT 1) o2 ON o2.request_id=i.id AND o2.revision=2
      WHERE pg_is_in_recovery() AND t.customer_atoms=100 AND t.supplier_atoms=59 AND t.input_tokens=7 AND t.cached_tokens=3 AND t.output_tokens=5 AND t.reasoning_tokens=2
        AND (SELECT count(*)=4 AND sum(side*atoms) FILTER(WHERE book=1)=0 AND sum(side*atoms) FILTER(WHERE book=2)=0 AND bool_and(atoms=CASE book WHEN 1 THEN 100 ELSE 59 END) FROM compact.posting WHERE request_id=i.id)`;
    if(!explain)assert.equal(rows.length,batch.length);
  }
  const row = (wallet,seq) => ({id:uid(),attempt:uid(),command:uid(),first:uid(),final:uid(),wallet,seq,input:7,cached:3,output:5,reasoning:2,terminal:0,acked:0,seen:0});
  try {
    primary=await fixture.startPostgres(true);
    standby=await fixture.startPostgresStandby(primary);
    const config = new SQL(primary.url,{max:1});
    try {
      const name=(await config`SELECT current_database() name`)[0].name;
      assert(/^[a-zA-Z0-9_]+$/.test(name));
      await config.unsafe('ALTER DATABASE "'+name+'" SET synchronous_commit=remote_apply');
      await config.unsafe('ALTER DATABASE "'+name+'" SET statement_timeout=15000');
    } finally {await config.close();}
    db=new SQL(primary.url,{max:10});rd=new SQL(standby.url,{max:10});
    await db.unsafe(await Bun.file(join(here,"model.sql")).text());
    const settings=async conn=>(await conn`SELECT version(),current_setting('synchronous_commit') commit,
      current_setting('fsync') fsync,current_setting('full_page_writes') fpw,pg_is_in_recovery() recovery`)[0];
    const primarySettings=await settings(db),standbySettings=await settings(rd);
    assert(!primarySettings.recovery);assert(standbySettings.recovery);
    for(const s of [primarySettings,standbySettings]){assert.equal(s.commit,"remote_apply");assert.equal(s.fsync,"on");assert.equal(s.fpw,"on");}
    const replication=(await db`SELECT application_name,sync_state,state FROM pg_stat_replication`)[0];
    assert.equal(replication.sync_state,"sync");assert.equal(replication.state,"streaming");
    const warm=row(1000,-1);
    assert.deepEqual(await grant([warm]),[warm.id]);await grantWitness([warm]);
    assert.deepEqual(await grant([warm]),[]);
    await assert.rejects(grant([{...warm,attempt:uid()}]),/grant identity conflict/);
    await assert.rejects(grant([row(1000,-2)]),/insufficient funds/);
    assert.deepEqual(await settle([warm]),[warm.id]);await terminalWitness([warm]);
    assert.deepEqual(await settle([warm]),[]);await assert.rejects(settle([{...warm,output:7}]),/terminal identity conflict/);await assert.rejects(settle([{...warm,first:uid()}]),/terminal identity conflict/);
    const race=await Promise.allSettled([grant([row(1001,-3)]),grant([row(1001,-4)])]);
    assert.equal(race.filter(x=>x.status==="fulfilled").length,1);
    assert.equal(race.filter(x=>x.status==="rejected" && String(x.reason).includes("insufficient funds")).length,1);
    await db`UPDATE compact.outbox SET acked=true WHERE request_id=${warm.id}`;
    const heldRace=(await db`SELECT request_id FROM compact.permit WHERE wallet_id=1001`)[0].request_id;
    const raceReceipt=(await db`SELECT attempt_id,command_id FROM compact.permit WHERE request_id=${heldRace}`)[0];
    const qRace={...row(1001,-3),id:heldRace,attempt:raceReceipt.attempt_id,command:raceReceipt.command_id};
    await settle([qRace]);await terminalWitness([qRace]);await db`UPDATE compact.outbox SET acked=true WHERE request_id=${qRace.id}`;
    const varied={...row(1002,-5),input:1,cached:9,output:2,reasoning:1};
    await grant([varied]);await grantWitness([varied]);await settle([varied]);
    const variant=await rd`SELECT t.customer_atoms customer,t.supplier_atoms supplier,t.input_tokens uncached,t.cached_tokens cached,t.output_tokens output,t.reasoning_tokens reasoning,
      (SELECT sum(atoms) FROM compact.posting WHERE request_id=t.request_id AND book=1 AND side=1)::int customer_posted,
      (SELECT sum(atoms) FROM compact.posting WHERE request_id=t.request_id AND book=2 AND side=1)::int supplier_posted,
      (SELECT count(*) FROM compact.outbox WHERE request_id=t.request_id AND event_id=ANY(${[varied.first,varied.final]}::uuid[]))::int events
      FROM compact.terminal t WHERE pg_is_in_recovery() AND t.request_id=${varied.id}`;
    assert.deepEqual([variant[0].customer,variant[0].supplier,variant[0].uncached,variant[0].cached,variant[0].output,variant[0].reasoning,variant[0].customer_posted,variant[0].supplier_posted,variant[0].events],[100,26,1,9,2,1,100,26,2]);
    await db`UPDATE compact.outbox SET acked=true WHERE request_id=${varied.id}`;
    const baselineCells=await db`SELECT id,spent::text FROM compact.supplier_cell ORDER BY id`;
    const callCount={grant:0,settle:0,claim:0,ack:0,max_grant_batch:0,max_settle_batch:0};
    const token=uid();const index=new Map();let running=0,peak=0,shed=0,duplicateObs=0;
    let fatal;let arrivalsDone=false;
    const detect=(err)=>{fatal??=err;};
    const updateDone=x=>{if(x.terminal && x.seen===3 && !x.complete){x.complete=Math.max(x.terminal,x.acked);running--;}};
    http=Bun.serve({hostname:"127.0.0.1",port:0,idleTimeout:20,maxRequestBodySize:512*1024,
      async fetch(req){
        try{
          if(req.headers.get("authorization")!=="Bearer "+token) return new Response("",{status:403});
          const route=new URL(req.url).pathname;const body=await req.json();
          if(route==="/claim"){
            if(stopping)return Response.json({stop:true});
            const lease=uid();
            const es=await db`WITH picked AS (
              SELECT o.event_id FROM compact.outbox o WHERE NOT acked AND (until_at IS NULL OR until_at<clock_timestamp())
              ORDER BY position LIMIT 512 FOR UPDATE SKIP LOCKED
            ), claimed AS (
              UPDATE compact.outbox o SET lease=${lease}::uuid,until_at=clock_timestamp()+interval '10 seconds'
              FROM picked k WHERE k.event_id=o.event_id RETURNING o.event_id,o.request_id,o.revision
            ) SELECT c.*,p.attempt_id,t.customer_atoms,t.supplier_atoms,t.input_tokens,t.cached_tokens,t.output_tokens,t.reasoning_tokens
              FROM claimed c JOIN compact.terminal t USING(request_id) JOIN compact.permit p USING(request_id)`;
            callCount.claim++;return Response.json({lease,events:es});
          }
          if(route==="/ack"){
            const {lease,ids}=body;assert(Array.isArray(ids)&&ids.length>0&&ids.length<=512);
            const es=await db`UPDATE compact.outbox SET acked=true,lease=NULL,until_at=NULL
              WHERE lease=${lease}::uuid AND NOT acked AND until_at>=clock_timestamp() AND event_id=ANY(${ids}::uuid[]) RETURNING event_id`;
            assert.equal(es.length,ids.length);
            const evidence=await rd`SELECT count(*)::int n FROM compact.outbox WHERE pg_is_in_recovery() AND acked AND event_id=ANY(${ids}::uuid[])`;
            assert.equal(evidence[0].n,es.length);callCount.ack++;return Response.json({acknowledged:es.length});
          }
          if(route==="/observed"){
            for(const [id,e,rev] of body.events){
              const x=index.get(id);assert(x && e===(rev===1?x.first:x.final));assert(rev===1||rev===2);
              if(x.seen&rev)duplicateObs++;x.seen|=rev;x.acked=Math.max(x.acked,body.at);updateDone(x);
            }
            return Response.json({ok:true});
          }
          return new Response("",{status:404});
        }catch(err){detect(err);return new Response("observer failed",{status:500});}
      }});
    child=Bun.spawn([process.execPath,"--no-env-file",fileURLToPath(import.meta.url),"consumer",String(http.port)],{
      env:{PATH:process.env.PATH,COMPACT_OBSERVER_TOKEN:token},stdout:"ignore",stderr:"pipe"
    });
    const childErr=new Response(child.stderr).text();
    void child.exited.then(async code=>{if(!stopping)detect(new Error("consumer exited "+code+" "+(await childErr).slice(0,200)));});
    const sizes=async()=> (await db`SELECT pg_current_wal_insert_lsn()::text lsn,pg_database_size(current_database())::text db_bytes,
      (SELECT sum(pg_total_relation_size(oid)) FROM pg_class WHERE relnamespace='compact'::regnamespace AND relkind='r')::text model_bytes`)[0];
    const before=await sizes();
    sampler=startProcessSampler(async()=>({primary:[primary.pid],standby:[standby.pid],consumer:[child.pid],driver:[process.pid]}),500);
    await sampler.start();
    const queued=Array.from({length:stages},()=>[]);
    const start=wall()+50, end=start+seconds*1000;
    const works=queued.map(async waiting=>{
      while(!fatal&&(!arrivalsDone||waiting.length)){
        if(!waiting.length||(!arrivalsDone&&waiting.length<batchMax&&wall()-waiting[0].offered<collectionMs)){await sleep(1);continue;}
        const batch=waiting.splice(0,batchMax);
        try{
          const ids=await measure("grant",batch.length,()=>grant(batch));assert.equal(ids.length,batch.length);
          await measure("grantWitness",batch.length,()=>grantWitness(batch));callCount.grant++;callCount.max_grant_batch=Math.max(callCount.max_grant_batch,batch.length);
          const granted=wall();for(const x of batch)x.granted=granted;
          const finalized=await measure("settle",batch.length,()=>settle(batch));assert.equal(finalized.length,batch.length);
          await measure("terminalWitness",batch.length,()=>terminalWitness(batch));void checkPlans(wall()-start,batch);callCount.settle++;callCount.max_settle_batch=Math.max(callCount.max_settle_batch,batch.length);
          const at=wall();for(const x of batch){x.terminal=at;updateDone(x);}
        }catch(e){detect(e);}
      }
    });
    const ids=[]; let offers=0;
    while(offers<count&&!fatal){
      const now=wall();
      const due=Math.min(count,Math.max(0,Math.floor((now-start)*rate/1000)+1));
      while(offers<due){
        const seq=offers++,x=row(seq%1000,seq);x.scheduled=start+seq*1000/rate;x.offered=wall();
        ids.push(x);index.set(x.id,x);
        if(running===inflightMax){shed++;continue;}
        running++;peak=Math.max(peak,running);queued[x.wallet%stages].push(x);
      }
      if(offers<count)await sleep(1);
    }
    arrivalsDone=true;await Promise.all(works);
    while(running&&!fatal&&wall()<end+30000)await sleep(5);
    if(fatal)throw fatal;
    const drained=wall();
    stopping=true;await child.exited;
    const processMetrics=await sampler.stop(Math.max(1,offers));sampler=undefined;
    const after=await sizes();
    const wal=Number((await db`SELECT pg_wal_lsn_diff(${after.lsn}::pg_lsn,${before.lsn}::pg_lsn)::text n`)[0].n);
    const money=await rd`SELECT w.id,w.reserved::text,w.spent::text,w.deposited::text,count(t.request_id)::int n
      FROM compact.wallet w LEFT JOIN compact.permit p ON p.wallet_id=w.id LEFT JOIN compact.terminal t USING(request_id)
      WHERE w.id<1000 GROUP BY w.id ORDER BY w.id`;
    const perWallet=new Uint32Array(1000),perCell=new Uint32Array(16);
    const completed=ids.filter(x=>x.complete);for (const x of completed){perWallet[x.wallet]++;perCell[x.wallet%16]++;}
    const badWallets=money.filter(x=> x.n!==perWallet[x.id]||+x.reserved!==0||+x.spent!==perWallet[x.id]*100||+x.deposited!==1000000);
    const cells=await rd`SELECT id,reserved::text,spent::text,deposited::text FROM compact.supplier_cell ORDER BY id`;
    const badCells=cells.filter(c=>+c.reserved!==0||+c.spent-Number(baselineCells[c.id].spent)!==59*perCell[c.id]||+c.deposited!==1000000000);
    const proof=(await rd`SELECT (SELECT count(*)::int FROM compact.permit WHERE wallet_id<1000) grants,
      (SELECT count(*)::int FROM compact.terminal t JOIN compact.permit p USING(request_id) WHERE p.wallet_id<1000) terminals,
      (SELECT count(*)::int FROM compact.posting l JOIN compact.permit p USING(request_id) WHERE p.wallet_id<1000) postings,
      (SELECT count(*)::int FROM compact.outbox e JOIN compact.permit p USING(request_id) WHERE p.wallet_id<1000 AND acked) acked`)[0];
    const quant=(values)=>{values.sort((a,b)=>a-b);return Object.fromEntries([.5,.95,.99,.999,1].map(q=>[String(q),+Number(values[Math.max(0,Math.ceil(q*values.length)-1)]??0).toFixed(3)]));};
    const byWindow=completed.filter(x=>x.complete<end).length;
    const accounted=shed===0&&running===0&&duplicateObs===0&&offers===count&&completed.length===count&&badWallets.length===0&&badCells.length===0&&proof.grants===count&&proof.terminals===count&&proof.postings===4*count&&proof.acked===2*count;
    const elapsed=Math.max(...[drained-start,seconds*1000]);
    result={scope:"compact two-stage funding and settlement feasibility with independent HTTP event observer",createdAt:new Date().toISOString(),
      hardware:{logicalCpus:cpus().length,cpuModel:cpus()[0]?.model,bun:Bun.version},configuration:{rate,seconds,count,owners:stages,batchMax,collectionMs,inflightMax,deadlineMs,wallets:1000,supplierCells:16,primarySettings,standbySettings,replication},
      verified:{secondTariffCase:variant[0],grantReplayNoFresh:true,grantConflictRefused:true,insufficientFundsRefused:true,concurrentLastFundsExactlyOne:true,terminalReplayNoCharge:true,terminalConflictRefused:true},
      accounting:{measurementStartEpochMs:start,measurementEndEpochMs:end,...proof,offers,shed,peak,completed:completed.length,byWindow,completeRpsWithinWindow:byWindow/seconds,completeIncludingDrainRps:completed.length*1000/elapsed,
        deadlineMisses:completed.filter(x=>x.complete-x.scheduled>deadlineMs).length,badWallets:badWallets.length,badSupplierCells:badCells.length,duplicateObserved:duplicateObs,accounted,drainMs:Math.max(0,drained-end)},
      metrics:{callCount,grantDelayMs:quant(completed.map(x=>x.granted-x.scheduled)),terminalDelayMs:quant(completed.map(x=>x.terminal-x.scheduled)),
        completeDelayMs:quant(completed.map(x=>x.complete-x.scheduled)),dispatchLagMs:quant(ids.map(x=>x.offered-x.scheduled)),walBytes:wal,walPerOffered:wal/offers,modelBytesDelta:Number(after.model_bytes)-Number(before.model_bytes),
        databaseBytesDelta:Number(after.db_bytes)-Number(before.db_bytes),cpu:Object.fromEntries(Object.entries(processMetrics.processes).map(([k,v])=>[k,{cpuSeconds:v.cpu_seconds,cpuMsPerOffered:v.cpu_ms_per_request,peakRss:v.peak_rss_bytes}])),cpuSampleErrors:processMetrics.errors},
      limits:["No public Gateway, plugin, provider call or mTLS identity, per-request signatures, multidimensional production pricing, Redis quota lifecycle or transition recovery worker.",
        "Benchmark tariff: fixed 100 customer atoms per completed request; supplier uncached/cached/output unit rates 3/1/7. One fixed load mix, one separate varied-usage preflight, synthetic 100/100 reservations, and four double-entry ledger lines. Two event revisions are synthetic and emitted together. No cancellation, disputes, corrections, rate limits, mixed approvals or rejection isolation in mixed batches.",
        "Single configured writer per shard in this driver. No multi-writer fencing, crash/failover, API idempotency after promotion or consumer fault-injection validation. Data model is a feasibility probe, not production."],
      schemaSha256:new Bun.CryptoHasher("sha256").update(await Bun.file(join(here,"model.sql")).bytes()).digest("hex"),
      probeSha256:new Bun.CryptoHasher("sha256").update(await Bun.file(fileURLToPath(import.meta.url)).bytes()).digest("hex")};
    await Bun.write(output.replace(".json",".plans.json"),JSON.stringify(plans,null,2));
    await Bun.write(output.replace(".json",".timings.tsv"),timings.map(r=>r.join("\t")).join("\n"));
    const auditPath=output.replace(/\.json$/,".identities.tsv");
    const writer=Bun.file(auditPath).writer();
    writer.write("seq\trequest_id\tattempt_id\tcommand_id\tfirst_event\tfinal_event\twallet\tscheduled_epoch_ms\tgrant_witness_epoch_ms\tterminal_witness_epoch_ms\tack_observed_epoch_ms\n");
    for (const x of ids)writer.write([x.seq,x.id,x.attempt,x.command,x.first,x.final,x.wallet,x.scheduled,x.granted??"",x.terminal??"",x.acked??""].join("\t")+"\n");
    await writer.end();
    result.identityAudit={file:auditPath.split("/").at(-1),sha256:new Bun.CryptoHasher("sha256").update(await Bun.file(auditPath).bytes()).digest("hex")};
    fixture.assertHealthy();
  }finally{
    stopping=true;if(child&&child.exitCode===null){child.kill();await child.exited;}if(http)await http.stop(true);
    if(sampler)await sampler.close();await Promise.all([db?.close({timeout:2}),rd?.close({timeout:2})]);await fixture.close();
    const resources=await fixture.resources();
    if(result){result.cleanup=resources;await Bun.write(output,JSON.stringify(result,null,2)+"\n");console.log(JSON.stringify({output,...result.accounting,walPerOffered:result.metrics.walPerOffered,p99:result.metrics.completeDelayMs["0.99"],resources}));}
  }
}
await run();
