# 紧凑资金路径可复现探针

从 super-token-gateway 工作区根目录调用仓库自带的 Bun 和本机 PostgreSQL 17 工具。该程序用 tests/support/native-fixture.ts 创建一套带独立随机数据库目录、回环端口和凭据的 PostgreSQL 物理主备，不读取 .env.local。使用项目现有 scripts/benchmark-metrics.ts 采样进程 CPU，每 500 ms 一次。需允许本机监听端口、获取进程列表，并给临时文件系统留足空间，程序的固定预算为 10 GiB。

```sh
.local/toolchain/bun-1.4.4/bun --no-env-file /private/tmp/stg-compact-money-tariff-20261119/probe.mjs 3010 60 /private/tmp/stg-compact-money-tariff-20261119/reproduced.json
python3 /private/tmp/stg-compact-money-tariff-20261119/verify.py /private/tmp/stg-compact-money-tariff-20261119/reproduced.json
python3 /private/tmp/stg-compact-money-tariff-20261119/analyze.py /private/tmp/stg-compact-money-tariff-20261119/reproduced.json
```

使用新的 JSON 文件名可以保留前一次实验的原始记录。每次正式运行保存指标 JSON、按笔 TSV、逐批耗时 TSV 和备库实际执行计划 JSON，同名文件会覆盖。每笔 TSV 保存 request、attempt、command、两事件的 UUID，以及计划投放、备库见证发权、备库见证终态、外部消费者实际观测回执的时间。完成时间取最后两个值的较晚者。会话先在指定物理备库上读到相应许可，再执行另一事务完成扣款。两端默认 synchronous_commit=remote_apply，fsync 和 full_page_writes 均启用。独立回环 HTTP 消费者取实际租约，核金额和用量，再按事件 ID 回执；其观测时间需要同时满足服务端已在指定备库读到相应回执。两个消费者事件在一个终态事务中生成。1000 个钱包均衡轮转，按两个所有者分流、16 个供应资金单元，最多 128 笔/事务、8192 笔在途、每页最多 512 个事件。

公开短 Chat 基准的固定客户单价为每笔 100 atoms，供应价格为每个普通输入 token 3、缓存输入 1、输出 7。普通输入已扣除缓存，reasoning 是输出的子集。压力负载每笔 7/3/5，计客户 100、供应 59。启动验证单独测试 1/9/2 得客户 100、供应 26。供需均预留 100 的规则仅用于这个有界夹具。重复及冲突的 request、重复结算、并发争用仅余一次授信额度都运行于正式计时前。

该探针复用了原生 PostgreSQL 夹具与进程采样器，SQL 表、资金命令执行器和事件消费者是实验实现。未实现生产 API、Gateway、插件、真实上游、mTLS、逐请求签名、完整买卖方价格与预留规则、信用账户、Redis 限额、恢复和故障转移。CPU 为所采样进程下界。WAL 取实例 LSN 增量，包含两事务、事件租约/回执和数据库后台写入。报告中的 walPerOffered 分母是全部到达；出现拒绝时应另用 walBytes/completed 进行跨版本比较。严格窗口从第一个计划到达起持续 60 秒，单独列示末尾排空。
