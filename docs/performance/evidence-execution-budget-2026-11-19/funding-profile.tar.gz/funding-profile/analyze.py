import json,sys
from collections import defaultdict
from pathlib import Path
from statistics import median
path = Path(sys.argv[1])
data=json.loads(path.read_text())
origin=data['accounting']['measurementStartEpochMs']
traces=json.loads(path.with_suffix('.plans.json').read_text())
timings=defaultdict(lambda:defaultdict(list))
for line in path.with_suffix('.timings.tsv').read_text().splitlines():
    epoch,stage,size,duration=line.split('\t')
    timings[int((float(epoch)-origin)//5000)][stage].append((int(size),float(duration)))
print('interval_5s stage: calls / median rows / median ms / p95 ms / sum ms')
for k,bucket in timings.items():
    print(5*k, {s:[len(rows), median(x for x,y in rows), round(median(y for x,y in rows),2),round(sorted(y for x,y in rows)[int(len(rows)*.95)],2), round(sum(y for x,y in rows))] for s,rows in bucket.items()})
def walk(node):
    if node.get('Node Type') in ['Seq Scan','Index Scan','Index Only Scan','Bitmap Heap Scan'] and node.get('Relation Name') in ['permit','terminal','outbox','posting']:
        yield {k:node.get(k) for k in ['Node Type','Relation Name','Index Name','Actual Rows','Actual Loops','Shared Hit Blocks']}
    for sub in node.get('Plans',[]):
        yield from walk(sub)
for p in traces:
    out=dict(atMs=int(p['atMs']),size=p['size'])
    if 'error' in p:
        out['error']=p['error']
    for name in ['terminal','grant']:
        if name in p:
            plan=p[name]
            if isinstance(plan,str):
                plan=json.loads(plan)
            plan=plan[0]
            out[name]=dict(ms=plan['Execution Time'],buffers=plan['Plan']['Shared Hit Blocks'],scans=list(walk(plan['Plan'])))
    out['stats']={t['relname']:[t['n_live_tup'],t['autoanalyze_count']] for t in p.get('statistics',[])}
    print(json.dumps(out,separators=(',',':')))
