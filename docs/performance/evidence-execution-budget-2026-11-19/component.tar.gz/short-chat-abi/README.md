# 短 Chat 插件与证据组件复现

从生成本次发行产物的项目 checkout 根目录运行。仓库依赖、dist 发行产物和 Bun 1.4.4 应已就绪。脚本会再次验证 Bun 可执行文件与 worker 注册表的绑定、发行包、公开夹具策略、宿主、Worker 及注册表摘要。以实际解压路径替换最后的脚本路径。

```sh
.local/toolchain/bun-1.4.4/bun /path/to/short-chat-abi/probe.ts
```

该命令只读取当前 checkout，将本次运行结果写入脚本旁的 result.json，可在运行前复制原始结果。每次使用归档中相同的 benchmark 请求数据与从真实 mock-provider 应用采集的非流式响应。每笔生成独立尝试与事件 ID，执行真实发行包的 prepare 和 response，检查上游模型映射、公开正文以及用量。插件宿主生成两个独立事实，一个报告用量，一个附带请求和尝试成功状态。每次使用组件内临时产生的 Ed25519 密钥，按应用的证据域和 schema 分别签名与验签。密钥只在内存中存活。每轮同时有八个请求、四个 Worker。计时前先热身六十四笔。CPU 使用 process.cpuUsage 的用户态与内核态之和，覆盖同一进程内的 Worker。

夹具文件 runtime-approval.json 保存 175 RPS 审计记录中的模型与批准的发行版身份。public-fixture-policy.json 与 signed-package.json 是该发行包的已签本地测试发布夹具，策略仅包含公钥。result.json 为本次运行记录。探针范围排除了 HTTP/mTLS、Core 命令、原生上游提交、数据库、持久化与外部 ACK。组件吞吐不能用作公开 API 容量。
