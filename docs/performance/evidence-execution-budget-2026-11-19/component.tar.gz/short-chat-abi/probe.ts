import assert from "node:assert/strict";
import { generateKeyPairSync, sign, verify } from "node:crypto";
import { resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
const directory = fileURLToPath(new URL(".", import.meta.url));
const repo = process.cwd();
const fromCheckout = (path: string) => import(pathToFileURL(resolve(repo, path)).href);
const hostAPI = await fromCheckout("dist/plugin-host/index.js");
const { createMockApp } = await fromCheckout("apps/mock-providers/src/app.ts");
const { requestCharacters } = await fromCheckout("packages/adapters/src/protocol/characters.ts");
const { validChat } = await fromCheckout("scripts/benchmark-lib.ts");
const { coreEvidenceEventV1Schema, coreEvidenceGroupV1Schema, evidenceProofFields, signedCoreEvidenceEventV1Schema } = await fromCheckout("packages/contracts/src/core-execution.ts");
const { canonical } = await fromCheckout("packages/kernel/src/canonical.ts");
const { sha256 } = await fromCheckout("packages/runtime/src/crypto.ts");
const audit = await Bun.file(resolve(directory, "runtime-approval.json")).json();
const model = audit.http.model;
const approval = audit.runtimeApproval;
const workerPath = resolve(repo, "dist/native/builtin-adapters/worker.js");
const registryPath = resolve(repo, "dist/native/builtin-adapters/registry.json");
const code = await Bun.file(workerPath).bytes();
const registryBytes = await Bun.file(registryPath).bytes();
const bunDigest = sha256(await Bun.file(process.execPath).bytes());
const registry = hostAPI.parseBuiltinWorkerArtifact(JSON.parse(Buffer.from(registryBytes).toString()), code, bunDigest);
assert.equal(registry.artifact_digest, approval.execution.artifact_digest);
assert.equal(sha256(code), audit.environment.artifacts["dist/native/builtin-adapters/worker.js"]);
assert.equal(sha256(registryBytes), audit.environment.artifacts["dist/native/builtin-adapters/registry.json"]);
const policyBytes = await Bun.file(resolve(directory, "public-fixture-policy.json")).bytes();
const policy = hostAPI.packageTrust(hostAPI.releasePolicySchema.parse(JSON.parse(Buffer.from(policyBytes).toString())));
const signedBytes = await Bun.file(resolve(directory, "signed-package.json")).bytes();
const releaseHost = await Bun.file(resolve(repo, "dist/plugin-host/index.js")).bytes();
assert.equal(sha256(releaseHost), audit.hostBundleSha256);
assert.equal(sha256(signedBytes), audit.envelopeSha256);
assert.equal(sha256(policyBytes), audit.policySha256);
const pkg = hostAPI.verifyPackage(signedBytes, policy(approval.package_digest));
const original = hostAPI.verifiedPackageRuntime(pkg);
const record = registry.records.find((item) => item.package_digest === original.digest);
assert.equal(original.digest, approval.package_digest);
assert.equal(record.module_hash, hostAPI.pluginModuleInfo(original.module).hash);
assert.equal(record.release_id, original.manifest.id + "-" + original.manifest.version);
assert(policy.isPlatform(pkg) && policy.admits(pkg));
const config = { model_map: { [model]: "synthetic" }, max_output_tokens: 100, max_input_tokens: 4096, auth: "bearer" };
const tenant = crypto.randomUUID();
const identity = { origin_identity: "gateway:short-chat-component", origin_incarnation: crypto.randomUUID(), origin_session_id: crypto.randomUUID() };
const key = generateKeyPairSync("ed25519");
const logicalRequest = { model, messages: [{ role: "user", content: "benchmark input" }], max_completion_tokens: 32, stream: false };
const input = Buffer.from(JSON.stringify(logicalRequest));
const expectedUsage = { input_tokens: "7", output_tokens: "5", reasoning_tokens: "2", cached_input_tokens: "3" };
const prepareMetadata = { protocol: "chat", operation: "chat", model, input_characters: String(requestCharacters("chat", logicalRequest)) };
const responseMetadata = { protocol: "chat", model };
const responseFile = Bun.file(resolve(directory, "upstream.json"));
const upstream = await responseFile.exists() ? await responseFile.bytes() : await createResponse();
async function createResponse() {
const fixture = createMockApp(crypto.randomUUID());
const externalResponse = await fixture.app.request("/openai/v1/chat/completions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ ...logicalRequest, model: "synthetic" }) });
assert.equal(externalResponse.status, 200);
return new Uint8Array(await externalResponse.arrayBuffer());
}
assert(validChat(Buffer.from(upstream).toString(), false, "Hello, 世界 🌍"));
await Bun.write(resolve(directory, "request.json"), input);
if (!(await responseFile.exists())) await Bun.write(responseFile, upstream);
const actualWorker = hostAPI.createBuiltinWorkerExecutor({ code, digest: registry.worker_digest, modules: registry.records.map(item => item.module_hash), maxPending: 512 });
const attempts = hostAPI.createPluginAttempts(actualWorker, { maxAttempts: 512, maxStateBytes: 512 * (256 << 10) });
const totals = () => ({ requests: 0, prepareCalls: 0, responseCalls: 0, prepareWorkerMessages: 0, responseWorkerMessages: 0, signedEvents: 0, verifiedEvents: 0, groups: 0 });
const proof = (body) => Buffer.from(JSON.stringify(evidenceProofFields(body, sha256(canonical(body)))));
const expectedUsageText = canonical(expectedUsage);
async function runOne(count) {
  assert(policy.isPlatform(pkg));
  const attemptId = crypto.randomUUID();
  const attempt = attempts.create(pkg, { tenant, attempt: attemptId, incarnation: identity.origin_incarnation, deadlineAt: Date.now() + 10000, config: hostAPI.validateConfig(original.configSchema, config) });
  try {
    const prep = await attempt.transformJSON("prepare", prepareMetadata, input);
    assert.equal(prep.result.kind, "prepared");
    assert.equal(JSON.parse(Buffer.from(prep.body).toString()).model, "synthetic");
    count.prepareCalls++;
    const afterPrepare = attempt.snapshot().sequence;
    count.prepareWorkerMessages += afterPrepare;
    const bridge = hostAPI.observeAttempt(attempt, { attemptId, permitEpoch: "1", delivery: "terminal-group",
      seal(fact) {
        const event = coreEvidenceEventV1Schema.parse({ ...fact, ...identity });
        const signature = sign(null, proof(event), key.privateKey).toString("base64url");
        count.signedEvents++;
        return signedCoreEvidenceEventV1Schema.parse({ ...event, signature });
      },
      async record(facts) {
        const { events } = coreEvidenceGroupV1Schema.parse({ events: facts });
        assert.equal(events.length, 2);
        assert.notEqual(events[0].event_id, events[1].event_id);
        assert.equal(events[0].source_revision, "1");
        assert.equal(events[1].source_revision, "2");
        assert.equal(events[0].attempt_state, undefined);
        assert.equal(events[1].attempt_state, "SUCCEEDED");
        assert.equal(events[1].request_state, "SUCCEEDED");
        for (const { signature, ...body } of events) {
          assert.equal(body.attempt_id, attemptId);
          assert.equal(body.finality, "FINAL");
          assert.equal(canonical(body.usage), expectedUsageText);
          assert(verify(null, proof(body), key.publicKey, Buffer.from(signature, "base64url")));
          count.verifiedEvents++;
        }
        count.groups++;
      },
    });
    try {
      const result = await bridge.transformJSON("response", responseMetadata, upstream);
      assert.equal(result.result.kind, "output");
      assert(validChat(Buffer.from(result.body).toString(), false, "Hello, 世界 🌍"));
      count.responseCalls++;
      count.responseWorkerMessages += attempt.snapshot().sequence - afterPrepare;
      await bridge.finish({ attempt_state: "SUCCEEDED", request_state: "SUCCEEDED" }, true);
    } finally { bridge.dispose(); }
    count.requests++;
  } finally { attempt.dispose(); }
}
try {
  const lanes = 8;
  const warmup = totals();
  await Promise.all(Array.from({ length: lanes }, async () => { for (let i = 0; i < 8; i++) await runOne(warmup); }));
  const measured = totals();
  const beginCpu = process.cpuUsage();
  const start = performance.now();
  await Promise.all(Array.from({ length: lanes }, async () => { do { await runOne(measured); } while (performance.now() - start < 5000); }));
  const duration = performance.now() - start;
  const cpu = process.cpuUsage(beginCpu);
  assert.equal(measured.signedEvents, measured.requests * 2);
  assert.equal(measured.verifiedEvents, measured.signedEvents);
  assert.equal(measured.groups, measured.requests);
  assert.equal(attempts.snapshot().attempts, 0);
  const result = { scope: "isolated hot bundled OpenAI Chat plugin host and evidence cryptography", bun: Bun.version, bunSha256: bunDigest, lanes, windowMs: duration, warmup, measured, cpuMicros: cpu, processCpuMsPerCompleted: (cpu.user + cpu.system) / 1000 / measured.requests, componentCompletionsPerSecond: measured.requests * 1000 / duration, pluginHostSha256: sha256(releaseHost), packageDigest: pkg.digest, signedFixtureEnvelopeSha256: sha256(signedBytes), publicFixturePolicySha256: sha256(policyBytes), workerSha256: sha256(code), registrySha256: sha256(registryBytes), artifactDigest: registry.artifact_digest, moduleHash: record.module_hash, pluginRuntime: approval.execution.kind, inputSha256: sha256(input), upstreamSha256: sha256(upstream), inputBytes: input.length, upstreamBytes: upstream.length, model, usage: expectedUsage, worker: actualWorker.snapshot(), probeSha256: sha256(await Bun.file(fileURLToPath(import.meta.url)).bytes()), excludes: ["mTLS/H2/command proofs and identity registration", "public gateway HTTP, Core, funding, primary and standby PG, Redis", "upstream send and output generation during measurement", "external consumer and ACK", "cold package, worker and key creation"] };
  await Bun.write(resolve(directory, "result.json"), JSON.stringify(result, null, 2) + "\n");
  console.log(JSON.stringify(result));
} finally { await attempts.close(); }
