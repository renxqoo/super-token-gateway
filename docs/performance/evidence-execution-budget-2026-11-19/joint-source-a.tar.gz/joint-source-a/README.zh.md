# 短 Chat 联合 HTTP 原型

本目录在工程的固定 Bun 1.4.4、真实内置插件产物和隔离 PostgreSQL 17 主备上重放。需要本地仓库对应版本、已构建 dist/plugin-host、dist/native/builtin-adapters、.local/toolchain/pg17 与 redis74 中的测试工具。测试夹具自行建立全新的主库与物理同步备库，检查 remote_apply、fsync、full_page_writes 以及 streaming/sync 状态。无需服务账户凭证。每次运行取新的结果前缀。

```sh
export STG_REPO=/absolute/path/to/super-token-gateway
export PROBE=/absolute/path/to/unpacked/probe
cd "$STG_REPO"
.local/toolchain/bun-1.4.4/bun --no-env-file "$PROBE/public.mjs" 17 2 "$PROBE/replay-smoke"
.local/toolchain/bun-1.4.4/bun --no-env-file "$PROBE/public.mjs" 1001 60 "$PROBE/replay-1001"
.local/toolchain/bun-1.4.4/bun --no-env-file "$PROBE/public.mjs" 3001 60 "$PROBE/replay-3001"
```

启动器使用 4 个进程角色，包括独立固定到达客户端、承载公开 HTTP 和资金逻辑的试验入口、独立 HTTP 模拟供应商、独立事件消费者。试验入口加载 release builtin worker，对请求实际执行 prepare 和 response。上游路径、方法与请求体来自 prepare。每个成功请求在发权事务提交并按 ID 读取指定备库上的 receipt 后才发出一次上游 POST。

客户按成功完成请求收 100。供应商按非缓存输入、缓存输入、输出收 3、1、7 个原子单位。真实插件产生 7、3、5、2 的规范化用量，供应商计 59。定价另用 1、4、2 验证 21 供应商费用，并回滚这一校验事务。原型固定在两层各 100 的测试授权预留，账户包括 1000 钱包和 16 个供应商单元。两个分组写者维持所属单元的授权、消费串行。

试验入口生成每次运行的 Ed25519 密钥对，签署且验证真实插件的两个 evidence event。原文包含每个事件 ID、attempt ID、source revision、metering 和签名。成功终态、客户和供应商的四条分录、两条 outbox 和两份完整签名证据在主库同一事务提交。回复客户端之前，会在指定备库核对 request ID、attempt ID、event ID、两份含签名 JSONB 全文、源公钥、金额和分录。数据库 JSONB 见证比较完整对象，签名使用正式 canonical 内容。消费者实际通过 HTTP 领取事件，按自身固定的源公钥复验两份签名和签名计量，ACK 请求在主备库确认之后返回，外部进程记录收到 ACK 的时刻。

每次运行保存原始 http.tsv、upstream.tsv、ack.tsv 和对齐的 identities.tsv。有效完成要求客户侧收取并校验正确 Chat 输出、独立供应商实际一次接收、指定备库中的资金与签名相符、外部两次 ACK 的 request/attempt/event ID 相符且时序正确。以三者最大的时刻进入窗口，窗口左闭右开。预定到达时刻到完成时间用于时延，HTTP P99 从全体合法 HTTP 响应单独计算。主备清理及三个子进程退出单独列于 cleanup.json。客户端最多 2048 个在途请求，每个入口最多 384 个执行任务，超额蓄积另有界。CPU 来自每 500ms 的进程树采样，单位为近似 CPU 时间。

本目录验证有限的正常成功链路。当前实现采用同机回环明文 HTTP、单一固定路由、模拟上游、单币种费率、合成的发权上限和自签源身份。正式 Gateway 的认证、租户权限、内部 mTLS 和命令签名、Redis 分布式配额、动态定价、混合批准与拒绝、退款、超时、重复提交、故障切换、重放、恢复工作流及在线迁移均需另外验收。
