import assert from "node:assert/strict";
import {generateKeyPairSync,sign,verify} from "node:crypto";
import {resolve} from "node:path";
import {audit,dir,project,repo,wall} from "./common.mjs";
export async function createAdapter(){
  const host=await project("dist/plugin-host/index.js");
  const {coreEvidenceEventV1Schema,coreEvidenceGroupV1Schema,evidenceProofFields,signedCoreEvidenceEventV1Schema}=await project("packages/contracts/src/core-execution.ts");
  const {canonical}=await project("packages/kernel/src/canonical.ts");
  const {requestCharacters}=await project("packages/adapters/src/protocol/characters.ts");
  const {sha256}=await project("packages/runtime/src/crypto.ts");
  const workerPath="dist/native/builtin-adapters/worker.js",registryPath="dist/native/builtin-adapters/registry.json";
  const [code,registryBytes,hostBytes,policyBytes,signedBytes,bunBytes]=await Promise.all([resolve(repo,workerPath),resolve(repo,registryPath),resolve(repo,"dist/plugin-host/index.js"),resolve(dir,"public-fixture-policy.json"),resolve(dir,"signed-package.json"),process.execPath].map(p=>Bun.file(p).bytes()));
  const registry=host.parseBuiltinWorkerArtifact(JSON.parse(Buffer.from(registryBytes)),code,sha256(bunBytes));
  const approval=audit.runtimeApproval;
  assert.equal(registry.artifact_digest,approval.execution.artifact_digest);
  assert.equal(sha256(code),audit.artifacts[workerPath]);assert.equal(sha256(registryBytes),audit.artifacts[registryPath]);
  const policy=host.packageTrust(host.releasePolicySchema.parse(JSON.parse(Buffer.from(policyBytes))));
  const pkg=host.verifyPackage(signedBytes,policy(approval.package_digest));
  const runtime=host.verifiedPackageRuntime(pkg),record=registry.records.find(r=>r.package_digest===runtime.digest);
  assert.equal(runtime.digest,approval.package_digest);assert.equal(record.module_hash,host.pluginModuleInfo(runtime.module).hash);
  assert.equal(record.release_id,runtime.manifest.id+"-"+runtime.manifest.version);assert(policy.isPlatform(pkg)&&policy.admits(pkg));
  const worker=host.createBuiltinWorkerExecutor({code,digest:registry.worker_digest,modules:registry.records.map(item=>item.module_hash),maxPending:512});
  const attempts=host.createPluginAttempts(worker,{maxAttempts:512,maxStateBytes:512*(256<<10)});
  const identity={origin_identity:"gateway:public-short-probe",origin_incarnation:crypto.randomUUID(),origin_session_id:crypto.randomUUID()};
  const tenant=crypto.randomUUID(),key=generateKeyPairSync("ed25519"),publicKey=key.publicKey.export({format:"pem",type:"spki"});
  const proof=b=>Buffer.from(JSON.stringify(evidenceProofFields(b,sha256(canonical(b)))));
  const expected=canonical({input_tokens:"7",cached_input_tokens:"3",output_tokens:"5",reasoning_tokens:"2"});
  const config={model_map:{[audit.model]:"synthetic"},max_output_tokens:100,max_input_tokens:4096,auth:"bearer"};
  const counts={prepare:0,response:0,prepareMessages:0,responseMessages:0,signed:0,verified:0};
  const artifacts={workerSha256:sha256(code),registrySha256:sha256(registryBytes),packageDigest:pkg.digest,artifactDigest:registry.artifact_digest,hostSha256:sha256(hostBytes),bunSha256:sha256(bunBytes),fixturePackageSha256:sha256(signedBytes),policySha256:sha256(policyBytes),moduleHash:record.module_hash,publicKey};
  async function invoke(x,input,upstreamOrigin){
    const body=JSON.parse(Buffer.from(input));assert.equal(body.model,audit.model);
    const one=attempts.create(pkg,{tenant,attempt:x.attempt,incarnation:identity.origin_incarnation,deadlineAt:Date.now()+30000,config:host.validateConfig(runtime.configSchema,config)});
    try{
      const prep=await one.transformJSON("prepare",{protocol:"chat",operation:"chat",model:body.model,input_characters:String(requestCharacters("chat",body))},input);
      assert.equal(prep.result.kind,"prepared");assert.equal(JSON.parse(Buffer.from(prep.body)).model,"synthetic");
      const seq=one.snapshot().sequence;counts.prepare++;counts.prepareMessages+=seq;
      const route=prep.result.request;assert.equal(route.method,"POST");assert.equal(route.path,"/v1/chat/completions");assert(x.granted);
      x.sent=wall();
      const res=await fetch(new URL(route.path,upstreamOrigin),{method:route.method,headers:{...route.headers,authorization:"Bearer fixture","x-probe-id":x.id,"x-probe-attempt":x.attempt},body:prep.body,redirect:"error",signal:AbortSignal.timeout(30000)});
      assert.equal(res.status,200);assert.equal(res.headers.get("x-probe-id"),x.id);
      const upstream=new Uint8Array(await res.arrayBuffer());x.providerDone=wall();
      const bridge=host.observeAttempt(one,{attemptId:x.attempt,permitEpoch:"1",delivery:"terminal-group",
        seal(fact){const e=coreEvidenceEventV1Schema.parse({...fact,...identity});counts.signed++;return signedCoreEvidenceEventV1Schema.parse({...e,signature:sign(null,proof(e),key.privateKey).toString("base64url")});},
        async record(facts){
          const {events}=coreEvidenceGroupV1Schema.parse({events:facts});assert.equal(events.length,2);assert.notEqual(events[0].event_id,events[1].event_id);
          assert.equal(events[0].source_revision,"1");assert.equal(events[1].source_revision,"2");assert.equal(events[0].attempt_state,undefined);
          assert.equal(events[1].attempt_state,"SUCCEEDED");assert.equal(events[1].request_state,"SUCCEEDED");
          for(const {signature,...e} of events){assert.equal(e.attempt_id,x.attempt);assert.equal(e.finality,"FINAL");assert.equal(canonical(e.usage),expected);assert(verify(null,proof(e),key.publicKey,Buffer.from(signature,"base64url")));counts.verified++;}
          x.events=events;x.first=events[0].event_id;x.final=events[1].event_id;
          const u=events[1].usage;x.input=Number(u.input_tokens);x.cached=Number(u.cached_input_tokens);x.output=Number(u.output_tokens);x.reasoning=Number(u.reasoning_tokens);x.verified=wall();
        }});
      try{
        const output=await bridge.transformJSON("response",{protocol:"chat",model:body.model},upstream);
        assert.equal(output.result.kind,"output");counts.response++;counts.responseMessages+=one.snapshot().sequence-seq;
        await bridge.finish({attempt_state:"SUCCEEDED",request_state:"SUCCEEDED"},true);
        return output.body;
      }finally{bridge.dispose();}
    }finally{one.dispose();}
  }
  return {invoke,publicKey,artifacts,counts,snapshot:()=>({worker:worker.snapshot(),attempts:attempts.snapshot()}),close:()=>attempts.close()};
}
