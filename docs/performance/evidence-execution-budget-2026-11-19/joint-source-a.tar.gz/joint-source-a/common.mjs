import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
export const dir=dirname(fileURLToPath(import.meta.url));
export const repo=resolve(process.env.STG_REPO ?? process.cwd());
export const project=path=>import(pathToFileURL(resolve(repo,path)).href);
export const wall=()=>Date.now();
export const audit=await Bun.file(resolve(dir,"artifact-identity.json")).json();
export const logical={model:audit.model,messages:[{role:"user",content:"benchmark input"}],max_completion_tokens:32,stream:false};
export const quant=values=>{values.sort((a,b)=>a-b);return Object.fromEntries([.5,.95,.99,.999,1].map(q=>[q,values.length?+values[Math.ceil(q*values.length)-1].toFixed(3):null]));};
