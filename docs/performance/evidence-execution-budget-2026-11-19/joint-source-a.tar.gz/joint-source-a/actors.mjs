import assert from "node:assert/strict";
import { wall,logical,project } from "./common.mjs";
import { createPublicKey, verify, randomUUID } from "node:crypto";
const [kind,path,portText,rateText,secondsText]=Bun.argv.slice(2);
if(kind==="mock"){
  const {createMockApp}=await project("apps/mock-providers/src/app.ts");
  const app=createMockApp(randomUUID()).app,entries=new Map();let duplicates=0;
  const s=Bun.serve({hostname:"127.0.0.1",port:0,async fetch(req){
    const route=new URL(req.url).pathname;
    if(route==="/stop"&&req.headers.get("authorization")===process.env.MOCK_TOKEN){
      const writer=Bun.file(path+".upstream.tsv").writer();writer.write("request_id\tattempt_id\tupstream_received_epoch_ms\tcalls\n");
      for(const [id,x] of entries)writer.write([id,x.attempt,x.at,x.calls].join("\t")+"\n");
      await writer.end();setTimeout(()=>s.stop(true),100);return Response.json({requests:entries.size,duplicates});
    }
    if(req.method!=="POST"||route!=="/v1/chat/completions")return new Response("",{status:404});
    const id=req.headers.get("x-probe-id"),attempt=req.headers.get("x-probe-attempt");
    if(!id||!attempt)return new Response("",{status:400});const prior=entries.get(id);
    if(prior){prior.calls++;duplicates++;return new Response("",{status:409});}
    entries.set(id,{attempt,at:wall(),calls:1});
    const response=await app.fetch(req);response.headers.set("x-probe-id",id);return response;
  }});
  await Bun.write(path+".mock-ready",String(s.port));
}
if(kind==="load"){
  const {validChat}=await project("scripts/benchmark-lib.ts");
  const url="http://127.0.0.1:"+portText+"/v1/chat/completions",rate=Number(rateText),seconds=Number(secondsText),count=rate*seconds;
  const xs=Array.from({length:count},(_,seq)=>({seq,id:randomUUID(),status:0,valid:false}));const pending=new Set();let peak=0,shed=0;const driverLimit=2048;
  await Bun.write(path+".load-ready","ready");while(!await Bun.file(path+".start").exists())await Bun.sleep(5);
  const start=Number(await Bun.file(path+".start").text()),body=JSON.stringify(logical);
  async function send(x){
    x.dispatched=wall();
    try{
      const res=await fetch(url,{method:"POST",headers:{"content-type":"application/json","x-probe-id":x.id,"x-probe-seq":String(x.seq)},body,redirect:"error",signal:AbortSignal.timeout(30000)});
      x.status=res.status;x.valid=x.status===200&&res.headers.get("x-probe-id")===x.id&&validChat(await res.text(),false,"Hello, 世界 🌍");
    }catch(e){x.error=String(e).replace(/[\t\r\n]/g," ").slice(0,200);}
    x.finish=wall();
  }
  let offered=0;
  while(offered<count){
    const due=Math.min(count,Math.max(0,Math.floor((wall()-start)*rate/1000)+1));
    while(offered<due){
      const x=xs[offered++];x.scheduled=start+x.seq*1000/rate;if(pending.size>=driverLimit){shed++;x.error="client_inflight_limit";x.finish=wall();continue;}const task=send(x);pending.add(task);peak=Math.max(peak,pending.size);void task.finally(()=>pending.delete(task));
    }
    if(offered<count)await Bun.sleep(1);
  }
  await Promise.all(pending);
  const writer=Bun.file(path+".http.tsv").writer();writer.write("seq\trequest_id\tscheduled_epoch_ms\tdispatched_epoch_ms\thttp_validated_epoch_ms\tstatus\tvalid\terror\n");
  for(const x of xs)writer.write([x.seq,x.id,x.scheduled,x.dispatched,x.finish,x.status,Number(x.valid),x.error??""].join("\t")+"\n");
  await writer.end();await Bun.write(path+".load.json",JSON.stringify({start,seconds,rate,count,peak,shed,driverLimit,valid:xs.filter(x=>x.valid).length}));
}
if(kind==="consumer"){
  const {evidenceProofFields,signedCoreEvidenceEventV1Schema}=await project("packages/contracts/src/core-execution.ts");
  const {canonical}=await project("packages/kernel/src/canonical.ts"),{sha256}=await project("packages/runtime/src/crypto.ts");
  const publicKey=createPublicKey(process.env.PINNED_SIGNER);let verified=0;
  async function send(route,body){
    const res=await fetch("http://127.0.0.1:"+portText+route,{method:"POST",headers:{authorization:"Bearer "+process.env.OBSERVER_TOKEN,"content-type":"application/json"},body:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
    assert.equal(res.status,200,route+" "+res.status);return res.json();
  }
  const writer=Bun.file(path+".ack.tsv").writer();writer.write("request_id\tattempt_id\tevent_id\trevision\tack_observed_epoch_ms\n");
  try{
    for(;;){
      const page=await send("/claim",{});if(page.stop)break;
      if(!page.events.length){await Bun.sleep(3);continue;}
      for(const e of page.events){
        assert.equal(e.customer_atoms,100);assert.equal(e.supplier_atoms,59);assert.deepEqual([e.input_tokens,e.cached_tokens,e.output_tokens,e.reasoning_tokens],[7,3,5,2]);assert([1,2].includes(e.revision));
        assert.equal(e.signed_body.event_id,e.event_id);assert.equal(e.signed_body.attempt_id,e.attempt_id);assert.equal(e.signed_body.source_revision,String(e.revision));assert(e.signed_body.signature);
        assert.equal(e.signer,process.env.PINNED_SIGNER);
        const {signature,...body}=signedCoreEvidenceEventV1Schema.parse(e.signed_body);
        assert.equal(body.usage.input_tokens,String(e.input_tokens));assert.equal(body.usage.cached_input_tokens,String(e.cached_tokens));assert.equal(body.usage.output_tokens,String(e.output_tokens));assert.equal(body.usage.reasoning_tokens,String(e.reasoning_tokens));
        assert(verify(null,Buffer.from(JSON.stringify(evidenceProofFields(body,sha256(canonical(body))))),publicKey,Buffer.from(signature,"base64url")));verified++;
      }
      const ids=page.events.map(e=>e.event_id);const ack=await send("/ack",{lease:page.lease,ids});assert.equal(ack.acknowledged,ids.length);const at=wall();
      for(const e of page.events)writer.write([e.request_id,e.attempt_id,e.event_id,e.revision,at].join("\t")+"\n");
      await send("/observed",{at,events:page.events.map(e=>[e.request_id,e.event_id,e.revision])});
    }
  }finally{await writer.end();await Bun.write(path+".consumer.json",JSON.stringify({verified}));}
}
