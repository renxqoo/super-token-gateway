CREATE SCHEMA compact;
SET search_path TO compact,public;
CREATE TABLE wallet (
  id int PRIMARY KEY,
  deposited bigint NOT NULL CHECK (deposited >= 0),
  reserved bigint NOT NULL DEFAULT 0 CHECK (reserved >= 0),
  spent bigint NOT NULL DEFAULT 0 CHECK (spent >= 0),
  CHECK (reserved + spent <= deposited)
);
CREATE TABLE supplier_cell (
  id int PRIMARY KEY,
  deposited bigint NOT NULL CHECK (deposited >= 0),
  reserved bigint NOT NULL DEFAULT 0 CHECK (reserved >= 0),
  spent bigint NOT NULL DEFAULT 0 CHECK (spent >= 0),
  CHECK (reserved + spent <= deposited)
);
CREATE TABLE tariff (
  version int PRIMARY KEY,
  customer_request int NOT NULL,
  supplier_input int NOT NULL, supplier_cached int NOT NULL, supplier_output int NOT NULL
);
INSERT INTO tariff VALUES (1,100,3,1,7);
CREATE TABLE permit (
  request_id uuid PRIMARY KEY,
  attempt_id uuid NOT NULL UNIQUE,
  command_id uuid NOT NULL UNIQUE,
  wallet_id int NOT NULL REFERENCES wallet,
  cell int NOT NULL REFERENCES supplier_cell,
  tariff int NOT NULL REFERENCES tariff(version),
  customer_hold int NOT NULL CHECK (customer_hold >= 0),
  supplier_hold int NOT NULL CHECK (supplier_hold >= 0),
  epoch int NOT NULL CHECK (epoch = 1)
);
CREATE TABLE terminal (
  request_id uuid PRIMARY KEY REFERENCES permit,
  customer_atoms int NOT NULL CHECK (customer_atoms >= 0),
  supplier_atoms int NOT NULL CHECK (supplier_atoms >= 0),
  input_tokens int NOT NULL, cached_tokens int NOT NULL, output_tokens int NOT NULL, reasoning_tokens int NOT NULL,
  first_event uuid NOT NULL, final_event uuid NOT NULL, CHECK (first_event <> final_event), CHECK (input_tokens>=0 AND cached_tokens>=0 AND output_tokens>=reasoning_tokens AND reasoning_tokens>=0)
);
CREATE TABLE posting (
  request_id uuid NOT NULL REFERENCES terminal,
  book smallint NOT NULL CHECK (book IN (1,2)),
  side smallint NOT NULL CHECK (side IN (-1,1)),
  atoms int NOT NULL CHECK (atoms >= 0),
  PRIMARY KEY(request_id,book,side)
);
CREATE TABLE outbox (
  event_id uuid PRIMARY KEY,
  position bigint GENERATED ALWAYS AS IDENTITY UNIQUE,
  request_id uuid NOT NULL REFERENCES terminal,
  revision smallint NOT NULL CHECK (revision IN (1,2)),
  lease uuid, until_at timestamptz, acked boolean NOT NULL DEFAULT false,
  UNIQUE(request_id,revision)
);
CREATE INDEX live_delivery ON outbox(position) WHERE NOT acked;
CREATE FUNCTION grant_batch(rs uuid[], ats uuid[], cs uuid[], ws int[])
RETURNS uuid[] LANGUAGE plpgsql SET search_path=compact,pg_catalog AS $fn$
DECLARE
  ids uuid[]; n_wallets int; n_cells int; applied_wallets int; applied_cells int;
BEGIN
  IF cardinality(rs) NOT BETWEEN 1 AND 128 OR cardinality(ats) <> cardinality(rs) OR cardinality(cs) <> cardinality(rs) OR cardinality(ws) <> cardinality(rs)
    THEN RAISE EXCEPTION 'invalid grant batch'; END IF;
  WITH fresh AS (
    INSERT INTO permit SELECT r,a,c,w,w%16,1,100,100,1 FROM unnest(rs,ats,cs,ws) i(r,a,c,w)
    ON CONFLICT(request_id) DO NOTHING RETURNING request_id,wallet_id,cell
  ), wsum AS (SELECT wallet_id,count(*)*100 amount FROM fresh GROUP BY wallet_id),
  csum AS (SELECT cell,count(*)*100 amount FROM fresh GROUP BY cell),
  wupd AS (UPDATE wallet w SET reserved=w.reserved+d.amount FROM wsum d
    WHERE w.id=d.wallet_id AND w.deposited-w.reserved-w.spent>=d.amount RETURNING w.id),
  cupd AS (UPDATE supplier_cell c SET reserved=c.reserved+d.amount FROM csum d
    WHERE c.id=d.cell AND c.deposited-c.reserved-c.spent>=d.amount RETURNING c.id)
  SELECT coalesce(array_agg(request_id),'{}'::uuid[]),(SELECT count(*) FROM wsum),(SELECT count(*) FROM csum),
         (SELECT count(*) FROM wupd),(SELECT count(*) FROM cupd) INTO ids,n_wallets,n_cells,applied_wallets,applied_cells FROM fresh;
  IF n_wallets <> applied_wallets OR n_cells <> applied_cells THEN RAISE EXCEPTION 'insufficient funds'; END IF;
  IF EXISTS(SELECT 1 FROM unnest(rs,ats,cs,ws) i(r,a,c,w) LEFT JOIN permit p ON p.request_id=i.r
    WHERE (p.attempt_id,p.command_id,p.wallet_id) IS DISTINCT FROM (i.a,i.c,i.w)) THEN RAISE EXCEPTION 'grant identity conflict'; END IF;
  RETURN ids;
END $fn$;
CREATE FUNCTION settle_batch(rs uuid[], ats uuid[], firsts uuid[], finals uuid[], ins int[], cached int[], outs int[], reasoning int[])
RETURNS uuid[] LANGUAGE plpgsql SET search_path=compact,pg_catalog AS $fn$
DECLARE ids uuid[];
BEGIN
  IF cardinality(rs) NOT BETWEEN 1 AND 128 OR cardinality(ats) <> cardinality(rs) OR cardinality(firsts) <> cardinality(rs) OR cardinality(finals) <> cardinality(rs) OR cardinality(ins)<>cardinality(rs) OR cardinality(cached)<>cardinality(rs) OR cardinality(outs)<>cardinality(rs) OR cardinality(reasoning)<>cardinality(rs)
    THEN RAISE EXCEPTION 'invalid settle batch'; END IF;
  IF EXISTS(SELECT 1 FROM unnest(rs,ats) i(r,a) LEFT JOIN permit p ON p.request_id=i.r AND p.attempt_id=i.a WHERE p.request_id IS NULL)
    THEN RAISE EXCEPTION 'unknown permit'; END IF;
  WITH fresh AS (
    INSERT INTO terminal SELECT r,
      t.customer_request,
      incoming*t.supplier_input+cached_in*t.supplier_cached+outgoing*t.supplier_output,
      incoming,cached_in,outgoing,reasoning_out,first_id,final_id
    FROM unnest(rs,firsts,finals,ins,cached,outs,reasoning) i(r,first_id,final_id,incoming,cached_in,outgoing,reasoning_out)
    JOIN permit p ON p.request_id=i.r JOIN tariff t ON t.version=p.tariff
    ON CONFLICT(request_id) DO NOTHING RETURNING *
  ), facts AS (SELECT t.*,p.wallet_id,p.cell,p.customer_hold,p.supplier_hold FROM fresh t JOIN permit p USING(request_id)),
  wsum AS (SELECT wallet_id,sum(customer_hold) held,sum(customer_atoms) cost FROM facts GROUP BY wallet_id),
  csum AS (SELECT cell,sum(supplier_hold) held,sum(supplier_atoms) cost FROM facts GROUP BY cell),
  wupd AS (UPDATE wallet w SET reserved=w.reserved-d.held,spent=w.spent+d.cost FROM wsum d WHERE w.id=d.wallet_id),
  cupd AS (UPDATE supplier_cell c SET reserved=c.reserved-d.held,spent=c.spent+d.cost FROM csum d WHERE c.id=d.cell),
  entries AS (
    INSERT INTO posting SELECT request_id,b,s,CASE b WHEN 1 THEN customer_atoms ELSE supplier_atoms END
    FROM facts CROSS JOIN (VALUES (1,-1),(1,1),(2,-1),(2,1)) v(b,s)
  ), deliveries AS (
    INSERT INTO outbox(event_id,request_id,revision) SELECT CASE rev WHEN 1 THEN first_event ELSE final_event END,request_id,rev
    FROM fresh CROSS JOIN (VALUES (1),(2)) v(rev)
  )
  SELECT coalesce(array_agg(request_id),'{}'::uuid[]) INTO ids FROM fresh;
  IF EXISTS (SELECT 1 FROM unnest(rs,firsts,finals,ins,cached,outs,reasoning) i(r,e1,e2,x,c,y,q) LEFT JOIN terminal t ON t.request_id=i.r
    WHERE (t.first_event,t.final_event,t.input_tokens,t.cached_tokens,t.output_tokens,t.reasoning_tokens) IS DISTINCT FROM (i.e1,i.e2,i.x,i.c,i.y,i.q)) THEN RAISE EXCEPTION 'terminal identity conflict'; END IF;
  RETURN ids;
END $fn$;
INSERT INTO wallet(id,deposited) SELECT i,1000000 FROM generate_series(0,999) i;
INSERT INTO supplier_cell(id,deposited) SELECT i,1000000000 FROM generate_series(0,15) i;
INSERT INTO wallet(id,deposited) VALUES (1000,100),(1001,100),(1002,100);
