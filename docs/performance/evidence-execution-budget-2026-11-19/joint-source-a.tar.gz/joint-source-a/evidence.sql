CREATE TABLE compact.signer (
  public_key text PRIMARY KEY
);
CREATE TABLE compact.evidence (
  event_id uuid PRIMARY KEY REFERENCES compact.outbox,
  signer text NOT NULL REFERENCES compact.signer,
  signed_body jsonb NOT NULL CHECK (
    signed_body ?& ARRAY['event_id','attempt_id','signature','source_revision','usage','origin_identity','origin_incarnation','origin_session_id']
    AND event_id = (signed_body->>'event_id')::uuid
  )
);
