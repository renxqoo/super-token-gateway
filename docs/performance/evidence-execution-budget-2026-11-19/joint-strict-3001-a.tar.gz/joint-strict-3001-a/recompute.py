import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from itertools import zip_longest
from pathlib import Path


def rows(path):
    with path.open(encoding="utf-8", newline="") as file:
        yield from csv.DictReader(file, delimiter="\t")


def digest(path):
    with path.open("rb") as file:
        hasher = hashlib.sha256()
        for chunk in iter(lambda: file.read(1 << 20), b""):
            hasher.update(chunk)
        return hasher.hexdigest()


def nearest(values, percentile):
    return round(sorted(values)[math.ceil(len(values) * percentile) - 1], 3) if values else None


def stamp(value):
    return float(value) if value else 0


def check(condition, detail):
    if not condition:
        raise ValueError(detail)


def recompute(prefix):
    path = lambda suffix: Path(str(prefix) + suffix)
    summary = json.loads(path(".json").read_text())
    account = summary["accounting"]
    rate, seconds = (summary["configuration"][key] for key in ("rate", "seconds"))
    start, end = (account[key] for key in ("startEpochMs", "endEpochMs"))
    check(end - start == 1000 * seconds, "inconsistent fixed window")
    if path(".start").is_file():
        check(float(path(".start").read_text()) == start, "start marker mismatch")
    raw_hashes = {ext: digest(path(ext)) for ext in (".http.tsv", ".upstream.tsv", ".ack.tsv", ".identities.tsv")}
    check(raw_hashes == summary["identitySha256"], "raw TSV hash mismatch")
    calls = {}
    for row in rows(path(".upstream.tsv")):
        key = row["request_id"]
        check(key not in calls, "duplicate upstream row " + key)
        calls[key] = (row["attempt_id"], stamp(row["upstream_received_epoch_ms"]), int(row["calls"]))
    distinct_upstream = len(calls)
    duplicate_sends = sum(max(0, row[2] - 1) for row in calls.values())
    events = {}
    distinct_events = set()
    for row in rows(path(".ack.tsv")):
        key = row["request_id"], int(row["revision"])
        event = row["event_id"]
        check(key[1] in (1, 2) and key not in events, "missing or duplicate ACK revision " + str(key))
        check(event not in distinct_events, "reused outbox event ID " + event)
        distinct_events.add(event)
        events[key] = (row["attempt_id"], event, stamp(row["ack_observed_epoch_ms"]))
    ack_count = len(events)
    seen_requests, seen_commands, seen_attempts = set(), set(), set()
    in_window = 0
    intersection_delays, http_delays = [], []
    status_counts, failed_intersection = Counter(), Counter()
    by_second = [0] * seconds
    per_row_mismatch = 0
    for seq, (client, witness) in enumerate(zip_longest(rows(path(".http.tsv")), rows(path(".identities.tsv")))):
        check(client is not None and witness is not None, "missing client or witness row")
        request = client["request_id"]
        check(int(client["seq"]) == int(witness["seq"]) == seq, "wrong fixed arrival order")
        check(request == witness["request_id"] and request not in seen_requests, "invalid client identity " + request)
        seen_requests.add(request)
        for id_name, ids_used in (("attempt_id", seen_attempts), ("command_id", seen_commands)):
            value = witness[id_name]
            if value:
                check(value not in ids_used, "reused " + id_name)
                ids_used.add(value)
        if witness["wallet"]:
            check(int(witness["wallet"]) == seq % 1000, "wallet distribution mismatch")
        scheduled = stamp(client["scheduled_epoch_ms"])
        check(abs(scheduled - (start + seq * 1000 / rate)) < .001, "wrong scheduled time")
        status_counts[client["status"]] += 1
        valid_http = client["valid"] == "1" and client["status"] == "200"
        validated = stamp(client["http_validated_epoch_ms"])
        if valid_http:
            http_delays.append(validated - scheduled)
        for field in ("scheduled_epoch_ms", "dispatched_epoch_ms", "http_validated_epoch_ms"):
            check(stamp(client[field]) == stamp(witness[field]), "client clock identity mismatch")
        attempt = witness["attempt_id"]
        call = calls.pop(request, None)
        call_ok = call is not None and call[0] == attempt and call[2] == 1
        observed = [events.pop((request, revision), None) for revision in (1, 2)]
        ack_ok = all(observed)
        if ack_ok:
            for event, column, clock in zip(observed, ("first_event", "final_event"), ("ack_first_client_epoch_ms", "ack_final_client_epoch_ms")):
                check(event[0] == attempt and event[1] == witness[column] and event[2] == stamp(witness[clock]), "ACK identity mismatch " + request)
            check(observed[0][1] != observed[1][1], "overlapping ACK identities")
        if call:
            check(call[1] == stamp(witness["upstream_receive_epoch_ms"]), "upstream clock mismatch")
        timeline = [scheduled, stamp(client["dispatched_epoch_ms"]), stamp(witness["public_arrival_epoch_ms"]),
                    stamp(witness["grant_witness_epoch_ms"]), stamp(witness["upstream_send_epoch_ms"]),
                    call[1] if call else 0, stamp(witness["upstream_body_received_epoch_ms"]),
                    stamp(witness["evidence_verified_epoch_ms"]), stamp(witness["terminal_witness_epoch_ms"]),
                    stamp(witness["http_release_epoch_ms"]), validated]
        order_ok = all(math.isfinite(value) and value > 0 for value in timeline) and all(a <= b + .0001 for a, b in zip(timeline, timeline[1:]))
        reasons = [name for name, good in (("valid_http", valid_http), ("unique_send", call_ok), ("two_external_acks", ack_ok), ("witness_order", order_ok)) if not good]
        if reasons:
            failed_intersection.update(reasons)
            completed = 0
        else:
            check(min(observed[0][2], observed[1][2]) >= timeline[7], "ACK before signed evidence " + request)
            completed = max(validated, timeline[8], observed[0][2], observed[1][2])
            intersection_delays.append(completed - scheduled)
            if start <= completed < end:
                in_window += 1
                by_second[int((completed - start) // 1000)] += 1
        per_row_mismatch += completed != stamp(witness["complete_epoch_ms"])
    check(not calls and not events, "orphan provider or consumer identity")
    check(len(seen_requests) == rate * seconds, "missing scheduled client row")
    check(not per_row_mismatch, f"{per_row_mismatch} completion times disagree with gateway DB audit")
    numbers = {"offers": len(seen_requests), "httpValid": len(http_delays), "ackRows": ack_count,
               "complete": len(intersection_delays), "inWindow": in_window}
    for name, value in numbers.items():
        check(account[name] == value, "report total mismatch for " + name)
    check(distinct_upstream == account["provider"]["requests"] and duplicate_sends == account["provider"]["duplicates"], "upstream aggregate mismatch")
    check(by_second == summary["metrics"]["inWindowSeconds"], "per-second closure counts differ")
    p99_http = nearest(http_delays, .99)
    p99_full = nearest(intersection_delays, .99)
    for actual, label in ((p99_http, "httpValidLatencyMs"), (p99_full, "completeLatencyMs")):
        reported = summary["metrics"][label]["0.99"]
        check((actual is None and reported is None) or (actual is not None and abs(actual - reported) < .0011), "p99 mismatch for " + label)
    return {"matchedReportedTotals": True, **numbers, "inWindowRps": in_window / seconds, "p99HttpValidMs": p99_http,
            "p99IntersectionMs": p99_full, "uniqueUpstream": distinct_upstream, "duplicateSends": duplicate_sends,
            "rawStatusCounts": status_counts, "missingIntersectionReasons": failed_intersection, "rawSha256": raw_hashes,
            "evidence": "Independent raw client, upstream and ACK logs. Grant and terminal replica witness timestamps are taken from the probe's identity export; the temporary database was not queried by this verifier."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output_prefix", type=Path)
    args = parser.parse_args()
    print(json.dumps(recompute(args.output_prefix), indent=2, ensure_ascii=False))
