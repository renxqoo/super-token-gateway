import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
import sys

result_file = Path(sys.argv[1])
result = json.loads(result_file.read_text())
data_file = result_file.with_name(result['identityAudit']['file'])
hasher = hashlib.sha256()
with data_file.open('rb') as source:
    for chunk in iter(lambda: source.read(1024*1024), b''):
        hasher.update(chunk)
actual_hash = hasher.hexdigest()
assert actual_hash == result['identityAudit']['sha256']
with data_file.open() as source:
    reader = csv.DictReader(source, delimiter='\t')
    sets = {key: set() for key in ('request_id', 'attempt_id', 'command_id', 'event_id')}
    purse = Counter()
    per_second = Counter()
    latency = []
    last_completion = 0
    offered = completed = observable = 0
    cfg = result['configuration']
    start = result['accounting']['measurementStartEpochMs']
    end = result['accounting']['measurementEndEpochMs']
    for row in reader:
        seq = int(row['seq'])
        assert seq == offered
        wallet = int(row['wallet'])
        assert wallet == seq % 1000
        offered += 1
        for key in ('request_id', 'attempt_id', 'command_id'):
            assert row[key] not in sets[key]
            sets[key].add(row[key])
        for key in ('first_event', 'final_event'):
            assert row[key] not in sets['event_id']
            sets['event_id'].add(row[key])
        scheduled = float(row['scheduled_epoch_ms'])
        assert abs(scheduled-start-(1000*seq/cfg['rate']))<0.001
        if not row['grant_witness_epoch_ms'] or not float(row['ack_observed_epoch_ms']):
            continue
        grant, terminal, ack = map(float, (row['grant_witness_epoch_ms'],row['terminal_witness_epoch_ms'],row['ack_observed_epoch_ms']))
        assert scheduled <= grant <= terminal
        assert grant <= ack
        finish = max(terminal,ack)
        purse[wallet] += 1
        per_second[math.floor((finish-start)/1000)] += 1
        latency.append(finish-scheduled)
        completed += 1
        observable += finish < end
        last_completion = max(last_completion, finish)
a = result['accounting']
assert completed==a['completed'] and offered==a['offers'] and observable==a['byWindow']
assert a['grants']==a['terminals']==completed and a['postings']==4*completed and a['acked']==2*completed
assert a['shed'] + completed == offered
assert a['badWallets']==a['badSupplierCells']==a['duplicateObserved']==0
assert result['cleanup']==dict(processes=[],directories=[],ports=[],timers=0)
latency.sort()
p99 = round(latency[math.ceil(0.99*len(latency))-1],3)
assert abs(result['metrics']['completeDelayMs']['0.99']-p99)<0.001
print(json.dumps(dict(offers=offered,completed=completed,uniqueIds={k:len(v) for k,v in sets.items()},wallets=len(purse),perWalletMin=min(purse.values()),perWalletMax=max(purse.values()),byWindow=observable,completionPer10s=[sum(n for s,n in per_second.items() if s//10==b) for b in range(cfg['seconds']//10)],lastCompletionAfterWindowMs=round(last_completion-end,3),p99=p99,sha256=actual_hash),indent=2))
