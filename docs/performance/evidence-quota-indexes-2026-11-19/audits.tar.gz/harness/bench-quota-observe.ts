import { plugin } from "bun";

function replaceOnce(source: string, before: string, after: string) {
  if (source.split(before).length !== 2) throw new Error("Benchmark observation insertion changed");
  return source.replace(before, () => after);
}

plugin({
  name: "settled-quota-observation",
  setup(builder) {
    builder.onLoad({ filter: /\/scripts\/bench-system\.ts$/ }, async ({ path }) => {
      let source = await Bun.file(path).text();
      source = replaceOnce(
        source,
        "    const pgStatements = summarizeStatements(",
        "    const statementsAfter = await databaseMetrics.snapshot();\n    const pgStatements = summarizeStatements(",
      );
      source = replaceOnce(source, "      await databaseMetrics.snapshot(),", "      statementsAfter,");
      source = replaceOnce(
        source,
        "      pgStatements,",
        `      pgStatements,
      leaseStatements: statementsAfter.rows.filter((row) => row.query.includes("execution_quota_leases")),
      quotaDescriptorBytes: (await db\`SELECT count(*)::int AS rows,avg(pg_column_size(descriptor))::float8 AS mean,max(pg_column_size(descriptor))::int AS max FROM public.execution_quota_leases\`)[0],
      observedRelations: await db\`
        SELECT c.relname name,c.reloptions options,s.n_tup_ins::int inserts,s.n_tup_upd::int updates,
          s.n_tup_hot_upd::int hot_updates,s.n_tup_newpage_upd::int newpage_updates,s.n_tup_del::int deletes,
          pg_relation_size(c.oid)::float8 heap_bytes,pg_indexes_size(c.oid)::float8 index_bytes,
          CASE WHEN c.reltoastrelid=0 THEN 0 ELSE pg_relation_size(c.reltoastrelid)::float8 END toast_heap_bytes,
          CASE WHEN c.reltoastrelid=0 THEN 0 ELSE pg_indexes_size(c.reltoastrelid)::float8 END toast_index_bytes,
          coalesce(t.n_tup_ins,0)::int toast_inserts,coalesce(t.n_tup_upd,0)::int toast_updates,
          coalesce(t.n_tup_del,0)::int toast_deletes
        FROM pg_class c JOIN pg_stat_all_tables s ON s.relid=c.oid
        LEFT JOIN pg_stat_all_tables t ON t.relid=c.reltoastrelid
        WHERE c.relnamespace='public'::regnamespace AND c.relname IN
          ('execution_quota_leases','gateway_requests','attempts','execution_commands','execution_permits',
            'execution_contexts','core_evidence_receipts','usage_events','event_deliveries','billing_holds')
        ORDER BY c.relname
      \`,
`,
      );
      return { contents: source, loader: "ts" };
    });
  },
});
