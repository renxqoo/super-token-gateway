import assert from "node:assert/strict";
import { readdir, rm } from "node:fs/promises";
import { resolve } from "node:path";
import { createEventStore, recordEventConsumer } from "@gateway/storage";
import { UsageProducer, evidenceChannel } from "@gateway/runtime";
import {
  chatReplies,
  eventually,
  settledCharge,
  withGatewayStack,
} from "../../tests/support/gateway-process.ts";

const backupDirectory = resolve(".local/backups");
const prior = new Set(await readdir(backupDirectory).catch(() => []));
await withGatewayStack({ reply: () => chatReplies.json(), supplierCredit: "1000000" }, async (stack) => {
  const { db, f, namespace } = stack;
  const consumer = await db.begin((tx) =>
    recordEventConsumer(tx, `quota-index-backup-${crypto.randomUUID()}`, false),
  );
  const response = await stack.send();
  assert.equal(response.status, 200);
  await response.text();
  assert.equal((await settledCharge(db, response.headers.get("x-request-id")!)).amount, "100");
  const events = createEventStore(db);
  let acknowledged = 0;
  await eventually(async () => {
    const claimed = await events.claim(consumer, 100);
    if (claimed.events.length)
      acknowledged += await events.ack(consumer, claimed.lease_token, claimed.events.map((item) => item.id));
    return acknowledged === 2;
  }, "two external consumer ACKs");
  const queue = new UsageProducer({
    channel: evidenceChannel, url: process.env.QUEUE_REDIS_URL!, namespace, replicas: 0, timeoutMs: 2000,
  });
  try {
    await eventually(async () => Object.values(await queue.stats()).every((count) => count === 0), "drained source queue");
    await eventually(async () => {
      const [leases] = await db`SELECT count(*)::int n FROM execution_quota_leases WHERE state<>'RELEASED' OR release_pending OR live_deadline_ms IS NOT NULL`;
      return leases.n === 0;
    }, "released source quota leases");
    await stack.gateway.stop();
    await stack.worker.stop();
    await f.identity.a.stop();
    await f.identity.b.stop();
    assert(Object.values(await queue.stats()).every((count) => count === 0));
    assert.equal((await db`SELECT count(*)::int n FROM core_evidence_receipts`)[0].n, 2);
    const source = (await db`SELECT current_database() name`)[0].name as string;
    const sourceUrl = new URL(process.env.DATABASE_URL!);
    sourceUrl.pathname = `/${source}`;
    const child = Bun.spawn([process.execPath, "run", "test:backup", "--quiesced"], {
      env: { ...process.env, DATABASE_URL: sourceUrl.href, REDIS_NAMESPACE: namespace, NODE_ENV: "test", MINIMAX_API_KEY: "" },
      stdin: "ignore", stdout: "pipe", stderr: "pipe",
    });
    const [out, errors, exit] = await Promise.all([
      new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited,
    ]);
    assert.equal(exit, 0, errors);
    const report = JSON.parse(out.trim().split("\n").at(-1)!);
    assert.equal(report.backup_restore, "pass");
    const file = resolve(report.file);
    assert(file.startsWith(`${backupDirectory}/gateway-`));
    assert(!prior.has(file.slice(backupDirectory.length + 1)));
    assert.equal(new Bun.CryptoHasher("sha256").update(await Bun.file(file).bytes()).digest("hex"), report.sha256);
    await rm(file);
    console.log(JSON.stringify({
      source, source_requests: 1, receipts: 2, external_acks: acknowledged,
      verifier_exit_code: exit, verifier: report, dump_removed_after_sha_verification: true,
    }));
  } finally {
    queue.close();
  }
});
