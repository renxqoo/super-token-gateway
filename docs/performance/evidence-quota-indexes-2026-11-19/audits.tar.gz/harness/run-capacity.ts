import { plugin, SQL } from "bun";
import { resolve } from "node:path";

plugin({
  name: "isolated-capacity-fixture",
  setup(builder) {
    builder.onLoad({ filter: /\/tests\/support\/native-fixture\.ts$/ }, async ({ path }) => {
      const source = await Bun.file(path).text();
      const contents = source
        .replace("402653184", "6442450944")
        .replace("384 MiB disk budget", "6 GiB disk budget")
        .replace("shared_buffers = '32MB'", "shared_buffers = '256MB'")
        .replace("max_connections = 64", "max_connections = 200")
        .replace("max_wal_size = '64MB'", "max_wal_size = '1GB'")
        .replace(
          "fsync = on",
          "shared_preload_libraries = 'pg_stat_statements'\\npg_stat_statements.max = 30000\\npg_stat_statements.track = 'all'\\nfsync = on",
        )
        .replace("maxmemory 64mb", "maxmemory 256mb");
      if (!contents.includes("pg_stat_statements.max = 30000") || !contents.includes("6442450944"))
        throw new Error("Capacity fixture configuration did not apply");
      return { contents, loader: "ts" };
    });
  },
});

const [label, ...targets] = Bun.argv.slice(2);
const verifyArtifacts = targets.length === 1 && targets[0] === "artifact-backup";
if (!label || !targets.length || (!verifyArtifacts && !targets.every((value) => /^\d+$/.test(value))))
  throw new Error("Usage: run-capacity.ts label target [target ...], or label artifact-backup");
const { createNativeFixture } = await import("../../tests/support/native-fixture.ts");
const fixture = await createNativeFixture();
const diagnostics = resolve(import.meta.dir, "bench-quota-observe.ts");
let child: ReturnType<typeof Bun.spawn> | undefined;
let interrupted = false;
const interrupt = () => {
  interrupted = true;
  child?.kill();
};
process.once("SIGINT", interrupt);
process.once("SIGTERM", interrupt);
try {
  const pg = await fixture.startPostgres();
  const db = new SQL(pg.url, { max: 1 });
  try {
    await db`CREATE EXTENSION pg_stat_statements`;
  } finally {
    await db.close();
  }
  const admission = await fixture.startRedis("admission");
  const queue = await fixture.startRedis("queue");
  const replica = await fixture.startRedis("replica", queue);
  await admission.command("CONFIG", "SET", "appendfsync", "everysec");
  await fixture.waitFor(async () =>
    (await replica.command("INFO", "replication")).includes("master_link_status:up"),
  );
  console.log(JSON.stringify({ label, fixture: fixture.directory, pg: pg.pid, queue: queue.pid, replica: replica.pid }));
  const env = {
    ...process.env,
    DATABASE_URL: pg.url,
    REDIS_URL: admission.url,
    QUEUE_REDIS_URL: queue.url,
    QUEUE_REQUIRED_REPLICAS: "1",
  };
  if (verifyArtifacts) {
    const checks = [
      ["artifact", ["run", "test:artifact"]],
      ["backup", ["--env-file=.env.local", resolve(import.meta.dir, "funded-backup.ts")]],
    ] as const;
    for (const [check, args] of checks) {
      if (interrupted) throw new Error("Verification interrupted");
      fixture.assertHealthy();
      child = Bun.spawn([process.execPath, ...args], { env, stdout: "pipe", stderr: "pipe" });
      const [out, errors, exit] = await Promise.all([
        new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited,
      ]);
      child = undefined;
      await Bun.write(resolve(import.meta.dir, `${label}-${check}.log`), out + errors);
      console.log(JSON.stringify({ check, exit }));
      if (exit !== 0) process.exitCode = 1;
    }
  }
  for (const [index, target] of (verifyArtifacts ? [] : targets).entries()) {
    if (interrupted) throw new Error("Capacity comparison interrupted");
    fixture.assertHealthy();
    const rate = String(Number(target) + 1);
    child = Bun.spawn(
      [
        process.execPath,
        "--no-env-file",
        "--preload",
        diagnostics,
        "scripts/bench-system.ts",
        "--seconds", "60",
        "--online-capacity",
        "--target-rps", target,
        "--rate", rate,
        "--wallets", "1000",
        "--instances", "1",
        "--concurrency", "256",
        "--warmup-concurrency", "16",
        "--worker-concurrency", "8",
        "--supplier-accounts", "1",
        "--observe",
        "--drain-seconds", "120",
      ],
      {
        env,
        stdout: "pipe",
        stderr: "pipe",
      },
    );
    const [out, errors, exit] = await Promise.all([
      new Response(child.stdout).text(),
      new Response(child.stderr).text(),
      child.exited,
    ]);
    child = undefined;
    await Bun.write(resolve(import.meta.dir, `${label}-${index + 1}-${target}.stdout`), out);
    await Bun.write(resolve(import.meta.dir, `${label}-${index + 1}-${target}.stderr`), errors);
    if (!out.trim()) throw new Error(`Capacity run ${target} produced no audit (exit ${exit})`);
    const result = JSON.parse(out.trim());
    console.log(JSON.stringify({ label, target, exit, directory: result.directory, passed: result.capacityPassed, failures: result.failures }));
  }
} finally {
  process.removeListener("SIGINT", interrupt);
  process.removeListener("SIGTERM", interrupt);
  await fixture.close();
  console.log(JSON.stringify({ label, afterCleanup: await fixture.resources() }));
}
