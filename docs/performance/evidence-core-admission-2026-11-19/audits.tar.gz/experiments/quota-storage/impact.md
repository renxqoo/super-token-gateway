# 租约差量存储迁移影响

2026-11-19 主工作树。按 `packages/storage/src/migrations/manifest.json` 顺序核对了 56 个迁移、83 个 SQL 输入的 SHA-256，终点为 2026111906。下表列出这个版本最后生效的定义。未连接生产数据库，未检查历史实物，未执行迁移。文中的 SQL 路径相对 `packages/storage/src/`。

| 路径 | 最终函数、源码和行号 | 迁移动作 |
|---|---|---|
| Core 预检、续租、重试 | `public.core_preflight_v1(jsonb,uuid,uuid)`，1818，`sql/core-begin-quota-commit.sql:36` | 所有状态的 `leases[].descriptor` 在返回 RPC 前还原。保留按请求过滤和按租约排序。|
| 激活、续租、释放 | `public.core_quota_v1(jsonb,uuid,text,jsonb)`，1817，`sql/core-quota-activation.sql:17` | 行锁下先还原，再按现有排除字段与 Redis 完整输入比较。第 24、28 行的单行与成组写入都经过编码。|
| 释放恢复 | `public.core_quota_recovery_v1(jsonb,jsonb)`，1902，`migrations/0016_quota-pending-release.sql:25`、第 34 行 | 限量有序扫描 pending 索引后还原输出，回写前还原旧值参加校验。保留第 35 行的语义，PG 行修订号可小于 Redis 修订号。|
| 准入、分段 BEGIN | `core_funding.execution_item_v1(jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb)`，1906，`sql/core-chat-stream-grant.sql:243` | 在既有行锁下还原 ADOPTION_PENDING 比较。第 138 行直接读 tokens，第 187 行比较两份完整输入，均可保留。第 195、249 行写完整输入，由编码入口处理。|
| 批量准入 | `core_funding.flush_admit_v1(jsonb)`，1904，`sql/core-short-chat-commit.sql:318`、第 327 行 | 先插入命令，再插入完整租约。集中写触发器可覆盖这一路径。|
| 结算、关闭、异常恢复、过期 | `core_funding.evidence_group_v1` 1817，`sql/core-shared-wallet-settlement.sql:596`、第 606 行；`public.core_quota_close_v1` 1206，`sql/core-execution.sql:489`；`public.core_abort_recovery_v1` 1804，`sql/core-funding-execution.sql:287`、第 292 行；`public.core_quota_expire_v1` 1901，`migrations/0015_quota-live-deadline.sql:48` | 四个函数只改租约行状态。沿用 1902 的 `public.core_quota_guard_v1()`，第 12 行仍可直接读保留的 deadline_ms。状态变动无须查命令。|

## 编码、兼容和发布

1. 追加新 manifest 迁移。对前四个函数保留签名、owner、授权、固定 search_path 和原有锁顺序，发布可同时读两种表示的版本。在表上加入显式格式号，旧行默认 0，完整 JSON 原样返回。用专用 `BEFORE INSERT OR UPDATE OF descriptor` 触发器接收现有写者的完整输入。编码选择与读取权限须由数据库控制，现有 Core 角色只有受限函数权限。内部助手撤销 PUBLIC EXECUTE，只授权所需函数所有者。生产表直接 SELECT descriptor 的运维和审计消费者须核实并改用完整投影；仓库内直接读取完整 JSON 的现有升级断言位于 `tests/integration/core-execution-upgrade.test.ts:312`。
2. 仅当 `(原文减八字段 || 从行及命令重建的八字段) IS NOT DISTINCT FROM 原文` 且源值为 JSON 对象时使用格式 1。租约行供 lease_id、scope_kind、scope_id；`execution_commands.id = lease.command_id` 定位命令，从命令的 **command_id**、kind、caller_identity、body_digest、owner_session_id 取其余五项。外键见 `migrations/0004_financial_admission.sql:50`，命令不可变触发器见 `sql/internal-identity.sql:42`。用格式 0 逐字义保留历史差异、缺字段、显式 null、不同类型及非规范 UUID 大小写。新写的业务拒绝/接受条件沿用现有函数，编码资格不得改变回执。原型中的 23514 是差量编码失败，产品写入口应回退完整表示。lease 状态、Redis revision、remaining_ms、attempt_id、permit_epoch、tokens、分片及所有未知扩展字段保存在原描述符中。重放依旧向 Redis 取实时凭据。
3. 同批提供构建产物中的 manifest、SQL、迁移工具及匹配 schema 版本的 worker。先在主库事务内发布读兼容和显式格式，确认同步备库回放，同步相关权限后才打开新增租约编码。旧 worker 重启会因 schema 严格相等校验退出，应在该窗口部署对应 worker/维护工具。网关和 Redis RPC 可沿用原契约。见 `scripts/build.ts:36`、`packages/storage/src/database.ts:28`、`apps/core-worker/src/main.ts:11`、`packages/storage/src/maintenance.ts:25`。
4. 首次发布可只编码符合条件的新行。普通更新遇到旧格式 0 继续写完整 JSON，格式 1 的描述符更新重新验证身份；仅变更状态的语句跳过编码。若需收回旧数据占用，后续按小批主键、行锁、精确往返相等检查转换，遇到差异保留原文，避开单次迁移事务内全表重写。撤回先关闭新编码并保留双读。恢复旧 SQL 前须将**所有格式 1** 在相同行锁下还原成完整格式 0，核对主库格式 1 条数为零、同步备库已回放，再以前进迁移恢复旧函数；回填必须绕过该事务中的重新编码，写闸门不得可由运行身份任意切换。数据库版本号和 manifest 历史继续前进。

## 核验与门槛

在目标库只读查询现行 schema、直接访问该表的函数及相关触发器。第一条结果为 1906 时，本矩阵预期第二条命中九个函数，另有 `core_quota_guard_v1` 通过触发器挂在表上。检查实际安装的源码和权限后再做迁移。SQL 可从同一只读会话执行。

```sql
SELECT max(version) FROM public.schema_migrations;
SELECT p.oid::regprocedure, pg_get_userbyid(p.proowner) AS owner, p.prosecdef, p.proacl
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname IN ('public','core_funding')
  AND p.prosrc ILIKE '%execution_quota_leases%'
ORDER BY 1;
SELECT pg_get_triggerdef(oid) FROM pg_trigger
WHERE tgrelid='public.execution_quota_leases'::regclass AND NOT tgisinternal;
```

在待迁移数据库的恢复副本上可只读统计各状态必须保留完整表示的历史行数。未执行此查询。

```sql
WITH audit AS (
  SELECT l.state,l.descriptor,
    jsonb_build_object('lease_id',l.lease_id,'scope_kind',l.scope_kind,'scope_id',l.scope_id,
      'command_id',c.command_id,'kind',c.kind,'caller',c.caller_identity,
      'body_digest',c.body_digest,'owner_session_id',c.owner_session_id) AS shared,
    c.id IS NOT NULL AS has_command
  FROM public.execution_quota_leases l LEFT JOIN public.execution_commands c ON c.id=l.command_id
)
SELECT state,count(*) AS rows,count(*) FILTER (WHERE CASE WHEN has_command AND jsonb_typeof(descriptor)='object'
  THEN ((descriptor-ARRAY['lease_id','scope_kind','scope_id','command_id','kind','caller','body_digest','owner_session_id'])||shared) IS DISTINCT FROM descriptor
  ELSE true END) AS keep_full
FROM audit GROUP BY state ORDER BY state;
```

历史兼容验收须覆盖升级前 ACTIVE、RELEASE_PENDING、RELEASED、EXPIRED、DRAFT 空绑定、缺字段、额外字段和旧命令/行身份不一致。比较迁移前后完整 JSONB 的 `IS DISTINCT FROM` 计数，验证待释放扫描行数及缓冲页上限、拒绝重放、备用库读回、恢复及钱包守恒。优先复用 `tests/integration/core-execution-upgrade.test.ts:294`、`tests/integration/core-quota-scaling.test.ts:5` 和 `tests/integration/core-terminal-replication.test.ts`。

八字段方案的最小真实尝试仍涉及四个最终读者、集中编码、跨命令查找和完整格式回退。已有样本给出租约三个阶段 WAL 降幅 23.60%，仅覆盖独立夹具；生产候选另行测量主库 CPU、请求 WAL、备库重放及公开 300 档有效吞吐。本轮保留为独立后续迁移。
