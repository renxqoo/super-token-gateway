await (async function probe() {
  const { SQL } = await import("bun");
  const assert = (await import("node:assert/strict")).default;
  const path = await import("node:path");
  const { pathToFileURL, fileURLToPath } = await import("node:url");
  const project = process.cwd();
  const out =
    process.argv[2] ?? path.join(path.dirname(fileURLToPath(import.meta.url)), "result.json");
  const load = (p) => import(pathToFileURL(path.join(project, p)).href);
  const { createNativeFixture } = await load("tests/support/native-fixture.ts");
  const { createQuotaLeases } = await load("packages/runtime/src/quota-leases.ts");
  const hash = (s) => new Bun.CryptoHasher("sha256").update(s).digest("hex");
  const manifest = async (p) => hash(await Bun.file(path.join(project, p)).arrayBuffer());
  const config = {
    postgresToolsDirectory: path.join(project, ".local/toolchain/pg17/bin"),
    redisServer: path.join(project, ".local/toolchain/redis74/bin/redis-server"),
  };
  const f = await createNativeFixture(config);
  let db, standby, quota, result;
  const fields = [
    "lease_id",
    "scope_kind",
    "scope_id",
    "command_id",
    "kind",
    "caller",
    "body_digest",
    "owner_session_id",
  ];
  const requestCount = 192;
  const nowUtc = new Date().toISOString();
  try {
    const primary = await f.startPostgres();
    const redis = await f.startRedis("delta-quota");
    db = new SQL(primary.url, { max: 1, connectionTimeout: 2, idleTimeout: 0 });
    quota = createQuotaLeases({
      urls: [redis.url],
      namespace: "compact-probe-20261119",
      generation: "generation1",
      timeoutMs: 1000,
    });
    const owner = crypto.randomUUID(),
      caller = "gateway:gatewayA",
      kind = "execution_admit_v1",
      channel = crypto.randomUUID();
    const sample = [],
      commands = [];
    const limit = { rpm: 100000, tpm: 20000000, concurrency: 10000 };
    for (let i = 0; i < requestCount; i++) {
      const id = crypto.randomUUID(),
        request = crypto.randomUUID(),
        attempt = crypto.randomUUID(),
        command = crypto.randomUUID(),
        deadline = Date.now() + 120000,
        body = hash("body:" + id);
      commands.push({
        id,
        command_id: command,
        kind,
        caller_identity: caller,
        owner_session_id: owner,
        body_digest: body,
        request_id: request,
        attempt_id: attempt,
      });
      for (const scope of [
        { kind: "project", id: crypto.randomUUID() },
        { kind: "key", id: crypto.randomUUID() },
        { kind: "channel", id: channel },
      ]) {
        const draft = (
          await quota.acquire({
            scope: { ...scope, ...limit },
            caller,
            kind,
            command_id: command,
            body_digest: body,
            owner_session_id: owner,
            deadline_ms: deadline,
            tokens: scope.kind === "channel" ? 90 : 270,
          })
        ).descriptor;
        const adopted = (await quota.adopt(draft, attempt, "1", hash("adopt:" + draft.lease_id)))
          .descriptor;
        let latest = adopted,
          renewed = null,
          reconciled = null;
        if (i === 0) {
          renewed = (await quota.renew(adopted, attempt, "1", hash("renew:" + draft.lease_id)))
            .descriptor;
          reconciled = (await quota.reconcile(renewed, attempt, "1", 27)).descriptor;
          latest = reconciled;
        }
        const released = (
          await quota.release(latest, {
            state: "RELEASE_PENDING",
            attempt_id: attempt,
            permit_epoch: "1",
          })
        ).descriptor;
        sample.push({
          command_fk: id,
          request_id: request,
          attempt_id: attempt,
          scope_kind: scope.kind,
          scope_id: scope.id,
          lease_id: draft.lease_id,
          draft,
          adopted,
          renewed,
          reconciled,
          released,
        });
      }
    }
    const controlCommand = crypto.randomUUID();
    const draftOnly = (
      await quota.acquire({
        scope: { kind: "key", id: crypto.randomUUID(), ...limit },
        caller,
        kind,
        command_id: controlCommand,
        body_digest: hash("draft-only"),
        owner_session_id: owner,
        deadline_ms: Date.now() + 120000,
        tokens: 55,
      })
    ).descriptor;
    const rejected = (
      await quota.release(draftOnly, {
        state: "REJECTED",
        command_id: controlCommand,
        body_digest: draftOnly.body_digest,
      })
    ).descriptor;
    assert.equal(rejected.attempt_id, null);
    await db.unsafe(`
      CREATE TABLE commands(id uuid PRIMARY KEY, command_id uuid NOT NULL, kind text NOT NULL, caller_identity text NOT NULL,owner_session_id uuid NOT NULL,body_digest text NOT NULL,request_id uuid NOT NULL UNIQUE,attempt_id uuid NOT NULL UNIQUE);
      CREATE TEMP TABLE samples(command_fk uuid, request_id uuid,attempt_id uuid,scope_kind text,scope_id text,lease_id text,draft jsonb,adopted jsonb,renewed jsonb,reconciled jsonb,released jsonb);
      CREATE FUNCTION shared_fields(l text, sk text, si text, c commands) RETURNS jsonb LANGUAGE sql IMMUTABLE STRICT AS $$
        SELECT jsonb_build_object('lease_id',l,'scope_kind',sk,'scope_id',si,'command_id',c.command_id,'kind',c.kind,'caller',c.caller_identity,'body_digest',c.body_digest,'owner_session_id',c.owner_session_id)
      $$;
      CREATE FUNCTION pack(d jsonb, shared jsonb) RETURNS jsonb LANGUAGE plpgsql IMMUTABLE STRICT AS $$
      DECLARE small jsonb;
      BEGIN
        small=d-ARRAY['lease_id','scope_kind','scope_id','command_id','kind','caller','body_digest','owner_session_id'];
        IF (small || shared) IS DISTINCT FROM d THEN RAISE EXCEPTION 'lease_identity_mismatch' USING ERRCODE='23514'; END IF;
        RETURN small;
      END $$;
    `);
    const appendCommand = async (rows) =>
      db`INSERT INTO commands SELECT * FROM jsonb_populate_recordset(NULL::commands,${rows}::jsonb)`;
    await appendCommand(commands);
    for (let i = 0; i < sample.length; i += 48)
      await db`INSERT INTO samples SELECT * FROM jsonb_populate_recordset(NULL::samples,${sample.slice(i, i + 48)}::jsonb)`;
    const [semantic] = await db`
      WITH cases AS (
        SELECT s.*, phase, d, shared_fields(s.lease_id,s.scope_kind,s.scope_id,c) AS props
        FROM samples s JOIN commands c ON c.id=s.command_fk CROSS JOIN LATERAL
          (VALUES ('draft',s.draft),('adopted',s.adopted),('release_pending',s.adopted),('expired_draft',s.draft),
            ('renewed',s.renewed),('reconciled',s.reconciled),('released',s.released)) v(phase,d) WHERE d IS NOT NULL
      )
      SELECT count(*)::int samples,count(*) FILTER (WHERE ((pack(d,props)||props) IS DISTINCT FROM d))::int mismatches,
        count(*) FILTER(WHERE phase IN ('draft','expired_draft') AND d->'attempt_id'='null'::jsonb AND d->'permit_epoch'='null'::jsonb)::int null_binding_cases,
        count(*) FILTER(WHERE phase='release_pending' AND d->>'state'='ADOPTED')::int pending_adopted,
        count(*) FILTER(WHERE phase='released' AND d->>'revision'='2')::int release_revision_2,
        count(*) FILTER(WHERE phase='reconciled' AND (d->>'tokens')::int=27)::int reconciled_target
      FROM cases`;
    assert.equal(semantic.mismatches, 0);
    assert.equal(semantic.null_binding_cases, 2 * sample.length);
    assert.equal(semantic.pending_adopted, sample.length);
    assert.equal(semantic.release_revision_2, 3);
    assert.equal(semantic.reconciled_target, 3);
    const [portion] = await db`SELECT round(avg(pg_column_size(s.adopted)),2)::float8 full_bytes,
      round(avg(pg_column_size(pack(s.adopted,shared_fields(s.lease_id,s.scope_kind,s.scope_id,c)))),2)::float8 compact_bytes FROM samples s JOIN commands c ON c.id=s.command_fk`;
    const [extra] = await db`SELECT pack(${rejected}::jsonb,props)||props AS hydrated FROM
      (SELECT jsonb_build_object('lease_id',${rejected.lease_id}::text,'scope_kind','key','scope_id',${draftOnly.scope_id}::text,
        'command_id',${controlCommand}::uuid,'kind',${kind}::text,'caller',${caller}::text,'body_digest',${draftOnly.body_digest}::text,'owner_session_id',${owner}::uuid) props) x`;
    assert.deepEqual(extra.hydrated, rejected);
    const retryRejected = (
      await quota.release(extra.hydrated, {
        state: "REJECTED",
        command_id: controlCommand,
        body_digest: draftOnly.body_digest,
      })
    ).descriptor;
    assert.deepEqual(retryRejected, rejected);
    let rejectedMismatches = 0;
    for (const replacement of [
      "'{}'::jsonb",
      "jsonb_build_object('body_digest',null)",
      "jsonb_build_object('command_id',s.command_fk::text)",
    ]) {
      const wrong =
        replacement === "'{}'::jsonb" ? "s.adopted-'kind'" : `s.adopted||${replacement}`;
      try {
        await db.unsafe(
          `SELECT pack(${wrong},shared_fields(s.lease_id,s.scope_kind,s.scope_id,c)) FROM samples s JOIN commands c ON c.id=s.command_fk LIMIT 1`,
        );
      } catch (error) {
        if (error.errno !== "23514") throw error;
        rejectedMismatches++;
      }
    }
    assert.equal(rejectedMismatches, 3);
    const guardFile = await Bun.file(
      path.join(project, "packages/storage/src/migrations/0016_quota-pending-release.sql"),
    ).text();
    const guard = guardFile.match(
      /CREATE OR REPLACE FUNCTION public\.core_quota_guard_v1\(\)[\s\S]+?END \$\$;/,
    );
    assert.ok(guard);
    await db.unsafe(guard[0]);
    const runs = [];
    for (const [index, codec] of ["full", "delta", "delta", "full"].entries()) {
      const table = "leases_" + index;
      await db.unsafe(`
        CREATE TABLE ${table}(
          lease_id text PRIMARY KEY,attempt_id uuid NOT NULL REFERENCES commands(attempt_id),
          command_id uuid NOT NULL REFERENCES commands(id),request_id uuid NOT NULL REFERENCES commands(request_id),
          scope_kind text NOT NULL,scope_id text NOT NULL,state text NOT NULL,revision numeric(38,0) NOT NULL,
          descriptor jsonb NOT NULL,live_deadline_ms bigint,release_pending boolean NOT NULL DEFAULT false,
          UNIQUE(attempt_id,scope_kind,scope_id),
          CHECK(state IN ('ADOPTION_PENDING','ACTIVE','RELEASE_PENDING','RELEASED','EXPIRED'))
        ) WITH(fillfactor=70);
        CREATE INDEX ON ${table}(request_id);
        CREATE INDEX ON ${table}(live_deadline_ms,request_id,lease_id) WHERE live_deadline_ms IS NOT NULL;
        CREATE INDEX ON ${table}(lease_id) WHERE release_pending;
        CREATE UNIQUE INDEX ON ${table}(request_id,scope_kind,scope_id) WHERE scope_kind<>'channel';
        CREATE TRIGGER core_quota_guard BEFORE INSERT OR UPDATE OR DELETE ON ${table} FOR EACH ROW EXECUTE FUNCTION public.core_quota_guard_v1()
      `);
      await db.unsafe("CHECKPOINT");
      const phase = async (label, sql) => {
        const [{ lsn }] = await db`SELECT pg_current_wal_insert_lsn()::text AS lsn`;
        const [explain] = await db.unsafe("EXPLAIN (ANALYZE, WAL, FORMAT JSON) " + sql);
        const [after] =
          await db`SELECT pg_wal_lsn_diff(pg_current_wal_insert_lsn(),${lsn}::pg_lsn)::int AS bytes`;
        const node = explain["QUERY PLAN"][0].Plan;
        return {
          label,
          statement_wal_bytes: node["WAL Bytes"],
          statement_wal_records: node["WAL Records"],
          statement_wal_fpi: node["WAL FPI"],
          cluster_wal_bytes: after.bytes,
        };
      };
      const source = (s) =>
        codec === "full"
          ? `s.${s}`
          : `pack(s.${s},shared_fields(s.lease_id,s.scope_kind,s.scope_id,c))`;
      const commandJoin = codec === "delta" ? " JOIN commands c ON c.id=s.command_fk " : " ";
      const phases = [];
      phases.push(
        await phase(
          "insert_active",
          `INSERT INTO ${table}(lease_id,attempt_id,command_id,request_id,scope_kind,scope_id,state,revision,descriptor)
        SELECT s.lease_id,s.attempt_id,s.command_fk,s.request_id,s.scope_kind,s.scope_id,'ACTIVE',1,${source("adopted")} FROM samples s ${commandJoin} ORDER BY s.lease_id`,
        ),
      );
      phases.push(
        await phase(
          "release_pending",
          `UPDATE ${table} SET state='RELEASE_PENDING' WHERE state='ACTIVE'`,
        ),
      );
      phases.push(
        await phase(
          "released",
          `UPDATE ${table} l SET state='RELEASED',descriptor=${source("released")} FROM samples s ${commandJoin} WHERE l.lease_id=s.lease_id AND l.state='RELEASE_PENDING'`,
        ),
      );
      const [end] =
        await db.unsafe(`SELECT count(*)::int AS rows, count(*) FILTER(WHERE l.state IS DISTINCT FROM 'RELEASED' OR l.release_pending OR l.live_deadline_ms IS NOT NULL OR
        (${codec === "full" ? "l.descriptor" : "l.descriptor||shared_fields(l.lease_id,l.scope_kind,l.scope_id,c)"} IS DISTINCT FROM s.released))::int AS mismatch, round(avg(pg_column_size(l.descriptor)),2)::float8 descriptor_bytes
        FROM ${table} l JOIN samples s ON s.lease_id=l.lease_id JOIN commands c ON c.id=l.command_id`);
      assert.equal(end.rows, sample.length);
      assert.equal(end.mismatch, 0);
      let reopenRejected = false;
      try {
        await db.unsafe(
          `UPDATE ${table} SET state='ACTIVE' WHERE lease_id=(SELECT min(lease_id) FROM samples)`,
        );
      } catch (error) {
        if (error.errno !== "P0403") throw error;
        reopenRejected = true;
      }
      assert.equal(reopenRejected, true);
      const [footprint] =
        await db`SELECT pg_relation_size(${table}::regclass)::int heap_bytes,pg_indexes_size(${table}::regclass)::int index_bytes`;
      runs.push({
        codec,
        phases,
        footprint,
        end,
        reopenRejected,
        cluster_wal_bytes: phases.reduce((n, x) => n + x.cluster_wal_bytes, 0),
      });
    }
    const [settings] =
      await db`SELECT current_setting('server_version') pg,current_setting('fsync') fsync,current_setting('synchronous_commit') synchronous_commit,current_setting('full_page_writes') full_page_writes,current_setting('wal_compression') wal_compression`;
    const ids = await db`SELECT DISTINCT s.scope_kind FROM samples s ORDER BY 1`;
    await db.unsafe("ALTER SYSTEM SET checkpoint_completion_target = '0'");
    await db.unsafe("SELECT pg_reload_conf()");
    await db.unsafe("CHECKPOINT");
    const replica = await f.startPostgresStandby(primary);
    standby = new SQL(replica.url, { max: 1, connectionTimeout: 2, idleTimeout: 0 });
    await db.unsafe("SET synchronous_commit='remote_apply'");
    await db.unsafe(`
      CREATE TABLE state_cases (LIKE leases_1 INCLUDING ALL);
      CREATE TRIGGER core_quota_guard BEFORE INSERT OR UPDATE OR DELETE ON state_cases FOR EACH ROW EXECUTE FUNCTION public.core_quota_guard_v1()
    `);
    const states = [
      {
        i: 1,
        initial: "ADOPTION_PENDING",
        before: "draft",
        next: "EXPIRED",
        after: "draft",
        rev: "0",
      },
      {
        i: 2,
        initial: "ADOPTION_PENDING",
        before: "draft",
        next: "RELEASE_PENDING",
        after: "draft",
        rev: "0",
      },
      {
        i: 3,
        initial: "ACTIVE",
        before: "adopted",
        next: "RELEASE_PENDING",
        after: "adopted",
        rev: "1",
      },
      {
        i: 0,
        initial: "RELEASE_PENDING",
        before: "adopted",
        next: "RELEASED",
        after: "released",
        rev: "1",
      },
    ];
    const stateObservations = [];
    for (const state of states) {
      const s = sample[state.i];
      const rowValues =
        await db`INSERT INTO state_cases(lease_id,attempt_id,command_id,request_id,scope_kind,scope_id,state,revision,descriptor)
        SELECT s.lease_id,s.attempt_id,s.command_fk,s.request_id,s.scope_kind,s.scope_id,${state.initial},${state.rev},pack(${s[state.before]}::jsonb,shared_fields(s.lease_id,s.scope_kind,s.scope_id,c))
        FROM samples s JOIN commands c ON c.id=s.command_fk WHERE s.lease_id=${s.lease_id} RETURNING lease_id`;
      assert.equal(rowValues.length, 1);
      await db`UPDATE state_cases l SET state=${state.next},descriptor=pack(${s[state.after]}::jsonb,shared_fields(l.lease_id,l.scope_kind,l.scope_id,c))
        FROM commands c WHERE c.id=l.command_id AND l.lease_id=${s.lease_id}`;
      const [seen] =
        await standby`SELECT pg_is_in_recovery() AS recovery,l.state,l.revision::text AS revision,l.attempt_id::text AS attempt,
        l.live_deadline_ms::text AS deadline,l.release_pending,l.descriptor||shared_fields(l.lease_id,l.scope_kind,l.scope_id,c) AS descriptor
        FROM state_cases l JOIN commands c ON c.id=l.command_id WHERE l.lease_id=${s.lease_id}`;
      assert.equal(seen.recovery, true);
      assert.equal(seen.state, state.next);
      assert.equal(seen.revision, state.rev);
      assert.equal(seen.attempt, s.attempt_id);
      assert.equal(seen.release_pending, state.next === "RELEASE_PENDING");
      assert.equal(seen.deadline, seen.release_pending ? String(s[state.after].deadline_ms) : null);
      assert.deepEqual(seen.descriptor, s[state.after]);
      const observation = {
        pg_state: seen.state,
        redis_state: seen.descriptor.state,
        pg_revision: seen.revision,
        redis_revision: seen.descriptor.revision,
        attempt_binding: seen.descriptor.attempt_id === null ? "null" : "bound",
      };
      if (seen.state === "RELEASE_PENDING" && seen.descriptor.state === "ADOPTED") {
        const replay = (
          await quota.release(seen.descriptor, {
            state: "RELEASE_PENDING",
            attempt_id: seen.attempt,
            permit_epoch: "1",
          })
        ).descriptor;
        assert.deepEqual(replay, s.released);
        observation.redis_replay = "RELEASED";
      }
      stateObservations.push(observation);
    }
    const [replication] =
      await db`SELECT current_setting('synchronous_commit') AS commit,sync_state,state FROM pg_stat_replication`;
    assert.equal(replication.commit, "remote_apply");
    assert.equal(replication.sync_state, "sync");
    result = {
      nowUtc,
      bun: Bun.version,
      requestCount,
      scopes: ids.map((r) => r.scope_kind),
      rowsPerArm: sample.length,
      fields,
      settings,
      source: {
        quota_sha256: await manifest("packages/runtime/src/quota-leases.ts"),
        guard_1902_sha256: await manifest(
          "packages/storage/src/migrations/0016_quota-pending-release.sql",
        ),
      },
      semantic,
      portion,
      draftReleasedNull: retryRejected.attempt_id === null,
      identityAnomaliesRejected: rejectedMismatches,
      runs,
      replication: { ...replication, states: stateObservations },
      limitations: [
        "Synthetic fresh Redis leases, no historical database, gateway, or wallet execution. Private synchronous standby validated the four state checks after the separate primary-only footprint measurements.",
        "Single-transaction per lifecycle phase over 576 rows, mirrored index/guard/foreign-key shape using a shared fixture command table as FK parent; no per-request throughput measurement.",
      ],
    };
  } finally {
    quota?.close();
    try {
      await Promise.all([db?.close({ timeout: 1 }), standby?.close({ timeout: 1 })]);
    } finally {
      await f.close();
    }
  }
  result.cleanup = await f.resources();
  assert.equal(result.cleanup.processes.length, 0);
  assert.equal(result.cleanup.directories.length, 0);
  await Bun.write(out, JSON.stringify(result, null, 2) + "\n");
  console.log(
    JSON.stringify({
      out,
      rows: result.rowsPerArm,
      semantic: result.semantic,
      bytes: result.portion,
      runs: result.runs.map((x) => ({
        codec: x.codec,
        wal: x.cluster_wal_bytes,
        heap: x.footprint.heap_bytes,
        index: x.footprint.index_bytes,
      })),
      cleanup: result.cleanup,
    }),
  );
})();
