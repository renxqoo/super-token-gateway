import assert from "node:assert/strict";
import { randomUUID as uid } from "node:crypto";
import { join, resolve } from "node:path";
import { cpus } from "node:os";
import {SQL} from "bun";
import {wall,quant,dir,repo,project,audit} from "./common.mjs";
import {createAdapter} from "./adapter.mjs";
import {createPool} from "./pool.mjs";
const [rateText,secondsText,outputText,mode="fast",poolText="0",transportText]=Bun.argv.slice(2);
const rate=Number(rateText),seconds=Number(secondsText),count=rate*seconds,output=resolve(outputText);
assert(Number.isInteger(rate)&&rate>0&&rate<=3010&&Number.isInteger(seconds)&&seconds>0&&seconds<=60);
assert(["fast","paced","burst"].includes(mode));const poolSize=Number(poolText);assert(Number.isInteger(poolSize)&&poolSize>=0&&poolSize<=4);const transportLimit=transportText?Number(transportText):null;assert(transportLimit===null||[256,384].includes(transportLimit));
for(const ext of [".json",".start",".mock-ready",".load-ready"])assert(!await Bun.file(output+ext).exists(),"choose a new output prefix");
const {createNativeFixture}=await project("tests/support/native-fixture.ts"),{startProcessSampler}=await project("scripts/benchmark-metrics.ts");
const fixture=await createNativeFixture({postgresToolsDirectory:join(repo,".local/toolchain/pg17/bin"),redisServer:join(repo,".local/toolchain/redis74/bin/redis-server"),diskBudgetBytes:6*1024**3,truncateProcessOutput:true});
let primary,standby,db,rd,sampler,http,control,adapter,consumerProc,mockProc,loadProc,stopping=false,result;
const children=[],token=uid(),mockToken=uid(),callCount={grant:0,progress:0,settle:0,claim:0,ack:0},batches={grant:[],progress:[],settle:[]},index=new Map(),errors=[];
let duplicateObs=0,active=0,peak=0,invalidAuth=0;
let acquired=0;const permits=[],executionLimit=384;
async function enter(){if(acquired<executionLimit){acquired++;return;}await new Promise(resolve=>permits.push(resolve));}
function leave(){if(permits.length)permits.shift()();else acquired--;}
function failure(e){if(errors.length<10)errors.push(String(e?.stack??e).slice(0,1800));}
function startActor(kind,args,extra={}){
 const proc=Bun.spawn([process.execPath,"--no-env-file",join(dir,"actors.mjs"),kind,output,...args.map(String)],{env:{PATH:process.env.PATH,STG_REPO:repo,...extra},stdout:"ignore",stderr:Bun.file(output+"."+kind+".log")});
 children.push(proc);return proc;
}
async function ready(proc,path){const deadline=wall()+20000;while(!await Bun.file(path).exists()){if(proc.exitCode!==null||wall()>deadline)throw Error("actor startup "+path);await Bun.sleep(10);}}
  async function grant(batch) {
    return (await db`SELECT compact.grant_batch(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.command)}::uuid[],${batch.map(x=>x.wallet)}::int[])::text[] ids`)[0].ids;
  }
  async function settleMoney(db,batch) {
    return (await db`SELECT compact.settle_batch(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.first)}::uuid[],${batch.map(x=>x.final)}::uuid[],${batch.map(x=>x.input)}::int[],${batch.map(x=>x.cached)}::int[],${batch.map(x=>x.output)}::int[],${batch.map(x=>x.reasoning)}::int[])::text[] ids`)[0].ids;
  }
  async function grantWitness(batch,conn=rd) {
    const rows=await conn`
      SELECT p.request_id FROM unnest(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.command)}::uuid[],${batch.map(x=>x.wallet)}::int[]) i(id,attempt,command,wallet_id)
      JOIN LATERAL (SELECT * FROM compact.permit pp WHERE pp.request_id=i.id LIMIT 1) p ON
        (p.attempt_id,p.command_id,p.wallet_id)=(i.attempt,i.command,i.wallet_id)
      WHERE pg_is_in_recovery() AND p.epoch=1 AND p.tariff=1 AND p.customer_hold=100 AND p.supplier_hold=100 AND p.cell=i.wallet_id%16`;
    assert.equal(rows.length,batch.length);
  }
  async function terminalWitness(batch,conn=rd) {
    const rows=await conn`
      SELECT t.request_id FROM unnest(${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.first)}::uuid[],${batch.map(x=>x.final)}::uuid[],${batch.map(x=>JSON.stringify(x.events[0]))}::text[],${batch.map(x=>JSON.stringify(x.events.at(-1)))}::text[]) i(id,attempt,e1,e2,b1,b2)
      JOIN LATERAL (SELECT p1.attempt_id FROM compact.permit p1 WHERE p1.request_id=i.id LIMIT 1) p ON p.attempt_id=i.attempt
      JOIN LATERAL (SELECT * FROM compact.terminal t1 WHERE t1.request_id=i.id LIMIT 1) t ON t.first_event=i.e1 AND t.final_event=i.e2
      JOIN LATERAL (SELECT o.request_id,o.revision FROM compact.outbox o WHERE o.event_id=i.e1 LIMIT 1) o1 ON o1.request_id=i.id AND o1.revision=1
      JOIN LATERAL (SELECT o.request_id,o.revision FROM compact.outbox o WHERE o.event_id=i.e2 LIMIT 1) o2 ON o2.request_id=i.id AND o2.revision=(i.b2::jsonb->>'source_revision')::smallint
      JOIN LATERAL (SELECT v.signer,v.signed_body FROM compact.evidence v WHERE v.event_id=i.e1 LIMIT 1) v1 ON v1.signer=${adapter.publicKey} AND v1.signed_body=i.b1::jsonb
      JOIN LATERAL (SELECT v.signer,v.signed_body FROM compact.evidence v WHERE v.event_id=i.e2 LIMIT 1) v2 ON v2.signer=${adapter.publicKey} AND v2.signed_body=i.b2::jsonb
      JOIN compact.signer source ON source.public_key=v1.signer AND source.public_key=v2.signer
      WHERE pg_is_in_recovery() AND t.customer_atoms=100 AND t.supplier_atoms=59 AND t.input_tokens=7 AND t.cached_tokens=3 AND t.output_tokens=5 AND t.reasoning_tokens=2
        AND (SELECT count(*)=4 AND sum(side*atoms) FILTER(WHERE book=1)=0 AND sum(side*atoms) FILTER(WHERE book=2)=0 AND bool_and(atoms=CASE book WHEN 1 THEN 100 ELSE 59 END) FROM compact.posting WHERE request_id=i.id)`;
    assert.equal(rows.length,batch.length);
  }
async function insertFacts(tx,es){
 const written=await tx`INSERT INTO compact.evidence(event_id,attempt_id,revision,signer,signed_body)
  SELECT i.id,i.attempt,i.rev,${adapter.publicKey},i.body::jsonb FROM unnest(${es.map(e=>e.event_id)}::uuid[],${es.map(e=>e.attempt_id)}::uuid[],${es.map(e=>Number(e.source_revision))}::smallint[],${es.map(e=>JSON.stringify(e))}::text[]) i(id,attempt,rev,body) RETURNING event_id`;
 assert.equal(written.length,es.length);
}
async function witnessProgress(es){
 const seen=await rd`SELECT i.id FROM unnest(${es.map(e=>e.event_id)}::uuid[],${es.map(e=>JSON.stringify(e))}::text[]) i(id,body)
 JOIN LATERAL (SELECT e.* FROM compact.evidence e WHERE e.event_id=i.id LIMIT 1) v ON v.signed_body=i.body::jsonb AND v.signer=${adapter.publicKey}
 WHERE pg_is_in_recovery()`;
 assert.equal(seen.length,es.length);
}
async function settle(batch){
 const es=batch.flatMap(x=>x.events.map(e=>[x.id,e]));
 const [written]=await db`SELECT compact.settle_with_evidence(
   ${batch.map(x=>x.id)}::uuid[],${batch.map(x=>x.attempt)}::uuid[],${batch.map(x=>x.first)}::uuid[],${batch.map(x=>x.final)}::uuid[],
   ${batch.map(x=>x.input)}::int[],${batch.map(x=>x.cached)}::int[],${batch.map(x=>x.output)}::int[],${batch.map(x=>x.reasoning)}::int[],
   ${adapter.publicKey}::text,${batch.map(x=>Number(x.events.at(-1).source_revision))}::smallint[],${batch.map(x=>JSON.stringify(x.events.at(-1)))}::text[],
   ${es.map(([,e])=>e.event_id)}::uuid[],${es.map(([id])=>id)}::uuid[],${es.map(([,e])=>Number(e.source_revision))}::smallint[]
 ) AS requests`;
 assert.equal(written.requests,batch.length);
}
const batchMax=128,collectionMs=8,stages=2;
function shard(){
 const pending={grant:[],progress:[],settle:[]};let busy=false,timer;
 async function flush(){
   timer=undefined;if(busy)return;busy=true;
   try{
    for(;;){
     const group=Object.entries(pending).filter(([,xs])=>xs.length).sort((a,b)=>a[1][0].at-b[1][0].at)[0];if(!group)break;
     const [kind,xs]=group;if(xs.length<batchMax&&wall()-xs[0].at<collectionMs){timer=setTimeout(flush,Math.max(1,collectionMs-(wall()-xs[0].at)));break;}
     const work=xs.splice(0,batchMax),batch=work.map(w=>w.x);
     try{
       if(kind==="grant"){const fresh=await grant(batch);assert.equal(fresh.length,batch.length);await grantWitness(batch);}
       else if(kind==="progress"){const es=batch.map(x=>x.events.at(-1));await insertFacts(db,es);await witnessProgress(es);}
       else{await settle(batch);await terminalWitness(batch);}
       callCount[kind]++;batches[kind].push(batch.length);
       for(const w of work){if(kind!=="progress")w.x[kind==="grant"?"granted":"terminal"]=wall();w.resolve();}
     }catch(e){failure(e);for(const w of work)w.reject(e);}
    }
   }finally{busy=false;}
 }
 return(kind,x)=>new Promise((resolve,reject)=>{pending[kind].push({x,at:wall(),resolve,reject});if(!busy&&!timer)timer=setTimeout(flush,1);});
}
const shards=Array.from({length:stages},shard);
try{
 adapter=poolSize?await createPool(poolSize):await createAdapter();
    primary=await fixture.startPostgres(true);
    standby=await fixture.startPostgresStandby(primary);
    const config = new SQL(primary.url,{max:1});
    try {
      const name=(await config`SELECT current_database() name`)[0].name;
      assert(/^[a-zA-Z0-9_]+$/.test(name));
      await config.unsafe('ALTER DATABASE "'+name+'" SET synchronous_commit=remote_apply');
      await config.unsafe('ALTER DATABASE "'+name+'" SET statement_timeout=15000');
    } finally {await config.close();}
    db=new SQL(primary.url,{max:10});rd=new SQL(standby.url,{max:10});
    await db.unsafe(await Bun.file(join(dir,"model.sql")).text());
    await db.unsafe(await Bun.file(join(dir,"evidence.sql")).text());
    await db`INSERT INTO compact.signer VALUES (${adapter.publicKey})`;
    if(mode==="paced"){
      const connection=await db.reserve();
      try{await connection.unsafe(await Bun.file(join(dir,"check-settle-atomic.sql")).text());}
      finally{await connection.release();}
    }
    const settings=async conn=>(await conn`SELECT version(),current_setting('synchronous_commit') commit,
      current_setting('fsync') fsync,current_setting('full_page_writes') fpw,pg_is_in_recovery() recovery`)[0];
    const primarySettings=await settings(db),standbySettings=await settings(rd);
    assert(!primarySettings.recovery);assert(standbySettings.recovery);
    for(const s of [primarySettings,standbySettings]){assert.equal(s.commit,"remote_apply");assert.equal(s.fsync,"on");assert.equal(s.fpw,"on");}
    const replication=(await db`SELECT application_name,sync_state,state FROM pg_stat_replication`)[0];
    assert.equal(replication.sync_state,"sync");assert.equal(replication.state,"streaming");

 const rolled=Error("rollback pricing calibration");
 await assert.rejects(db.begin(async tx=>{
   const x={id:uid(),attempt:uid(),command:uid(),wallet:1002,first:uid(),final:uid(),input:1,cached:4,output:2,reasoning:0};
   await tx`SELECT compact.grant_batch(ARRAY[${x.id}::uuid],ARRAY[${x.attempt}::uuid],ARRAY[${x.command}::uuid],ARRAY[1002])`;
   await settleMoney(tx,[x]);const [v]=await tx`SELECT customer_atoms,supplier_atoms FROM compact.terminal WHERE request_id=${x.id}::uuid`;assert.deepEqual([v.customer_atoms,v.supplier_atoms],[100,21]);
   throw rolled;
 }),e=>e===rolled);
 mockProc=startActor("mock",[],{MOCK_TOKEN:mockToken,SSE_MODE:mode});
 await ready(mockProc,output+".mock-ready");
 const upstreamOrigin="http://127.0.0.1:"+await Bun.file(output+".mock-ready").text();
 http=Bun.serve({hostname:"127.0.0.1",port:0,maxRequestBodySize:65536,idleTimeout:45,async fetch(req){
   if(req.method!=="POST"||new URL(req.url).pathname!=="/v1/chat/completions")return new Response("",{status:404});
   const id=req.headers.get("x-probe-id"),seq=Number(req.headers.get("x-probe-seq"));
   if(typeof id!=="string"||!Number.isInteger(seq)||seq<0||seq>=count||index.has(id))return new Response("",{status:400});
   const x={id,seq,wallet:seq%1000,attempt:uid(),command:uid(),arrived:wall(),seen:new Set(),events:[],trace:[],acked:0};index.set(id,x);
   if(active>=8192)return new Response("",{status:503});
   active++;peak=Math.max(peak,active);
   await enter();let freed=false;const release=()=>{if(!freed){freed=true;leave();active--;}};
   try{
     const input=new Uint8Array(await req.arrayBuffer()),owner=shards[x.wallet%stages];
     await owner("grant",x);
     return await adapter.invoke(x,input,upstreamOrigin,{progress:a=>owner("progress",a),settle:a=>owner("settle",a),signal:req.signal,release,failure});
   }catch(e){failure(e);release();return new Response("request failed",{status:500});}
 }});
 control=Bun.serve({hostname:"127.0.0.1",port:0,maxRequestBodySize:1024*1024,idleTimeout:30,async fetch(req){
   if(req.headers.get("authorization")!=="Bearer "+token){invalidAuth++;return new Response("",{status:403});}
   const route=new URL(req.url).pathname;
   try{const body=await req.json();
          if(route==="/claim"){
            if(stopping)return Response.json({stop:true});
            const lease=uid();
            const es=await db`WITH picked AS (
              SELECT o.event_id FROM compact.outbox o WHERE NOT acked AND (until_at IS NULL OR until_at<clock_timestamp())
              ORDER BY position LIMIT 512 FOR UPDATE SKIP LOCKED
            ), claimed AS (
              UPDATE compact.outbox o SET lease=${lease}::uuid,until_at=clock_timestamp()+interval '10 seconds'
              FROM picked k WHERE k.event_id=o.event_id RETURNING o.event_id,o.request_id,o.revision
            ) SELECT c.*,p.attempt_id,t.customer_atoms,t.supplier_atoms,t.input_tokens,t.cached_tokens,t.output_tokens,t.reasoning_tokens,v.signed_body,v.signer
              FROM claimed c
              JOIN LATERAL (SELECT e.signed_body,e.signer FROM compact.evidence e WHERE e.event_id=c.event_id LIMIT 1) v ON true
              JOIN LATERAL (SELECT t0.customer_atoms,t0.supplier_atoms,t0.input_tokens,t0.cached_tokens,t0.output_tokens,t0.reasoning_tokens FROM compact.terminal t0 WHERE t0.request_id=c.request_id LIMIT 1) t ON true
              JOIN LATERAL (SELECT p0.attempt_id FROM compact.permit p0 WHERE p0.request_id=c.request_id LIMIT 1) p ON true`;
            callCount.claim++;return Response.json({lease,events:es});
          }
          if(route==="/ack"){
            const {lease,ids}=body;assert(Array.isArray(ids)&&ids.length>0&&ids.length<=512);
            const es=await db`UPDATE compact.outbox SET acked=true,lease=NULL,until_at=NULL
              WHERE lease=${lease}::uuid AND NOT acked AND until_at>=clock_timestamp() AND event_id=ANY(${ids}::uuid[]) RETURNING event_id`;
            assert.equal(es.length,ids.length);
            const evidence=await rd`SELECT count(*)::int n FROM compact.outbox WHERE pg_is_in_recovery() AND acked AND event_id=ANY(${ids}::uuid[])`;
            assert.equal(evidence[0].n,es.length);callCount.ack++;return Response.json({acknowledged:es.length});
          }
          if(route==="/observed"){
            for(const [id,e,rev] of body.events){
              const x=index.get(id);assert(x && e===x.events[rev-1]?.event_id);
              if(x.seen.has(rev))duplicateObs++;x.seen.add(rev);x.acked=Math.max(x.acked,body.at);
            }
            return Response.json({ok:true});
          }

   return new Response("",{status:404});}catch(e){failure(e);return new Response("observer failed",{status:500});}
 }});
 consumerProc=startActor("consumer",[control.port],{OBSERVER_TOKEN:token,PINNED_SIGNER:adapter.publicKey});
 loadProc=startActor("load",[http.port,rate,seconds],{SSE_MODE:mode,...(transportLimit?{BUN_CONFIG_MAX_HTTP_REQUESTS:String(transportLimit)}:{})});await ready(loadProc,output+".load-ready");
 const sizes=async()=> (await db`SELECT pg_current_wal_insert_lsn()::text lsn,pg_database_size(current_database())::text db_bytes,
   (SELECT sum(pg_total_relation_size(oid)) FROM pg_class WHERE relnamespace='compact'::regnamespace AND relkind='r')::text model_bytes`)[0];
 const before=await sizes();
 sampler=startProcessSampler(async()=>({primary:[primary.pid],standby:[standby.pid],consumer:[consumerProc.pid],mock:[mockProc.pid],load:[loadProc.pid],gateway:[process.pid]}),500);
 await sampler.start();const start=wall()+200,end=start+seconds*1000;
 await Bun.write(output+".start",String(start));console.log(JSON.stringify({phase:"measure",rate,seconds,publicPort:http.port,startEpochMs:start}));
 assert.equal(await loadProc.exited,0,"load exit");const load=await Bun.file(output+".load.json").json();
 const deadline=end+30000;
 while((active||[...index.values()].some(x=>x.terminal&&x.seen.size!==x.events.length))&&wall()<deadline&&consumerProc.exitCode===null)await Bun.sleep(5);
 const drained=wall();const pm=await sampler.stop(count);sampler=undefined;
 stopping=true;assert.equal(await consumerProc.exited,0,"consumer exit");
 const stop=await fetch(upstreamOrigin+"/stop",{method:"POST",headers:{authorization:mockToken}});assert.equal(stop.status,200);const provider=await stop.json();assert.equal(await mockProc.exited,0);
 const consumer=await Bun.file(output+".consumer.json").json();
 const after=await sizes(),wal=Number((await db`SELECT pg_wal_lsn_diff(${after.lsn}::pg_lsn,${before.lsn}::pg_lsn)::text n`)[0].n);
 if(poolSize)await adapter.collect();
 const financial=await rd`WITH ledger AS (SELECT request_id,count(*) n,bool_and(CASE book WHEN 1 THEN atoms=100 ELSE atoms=59 END) amounts,
       sum(side*atoms) FILTER(WHERE book=1) buyer,sum(side*atoms) FILTER(WHERE book=2) supplier FROM compact.posting GROUP BY request_id),
     deliveries AS (SELECT o.request_id,count(*) n,bool_and(o.acked AND e.signer=${adapter.publicKey} AND e.event_id=o.event_id AND e.signed_body->>'source_revision'=o.revision::text) acked
       FROM compact.outbox o LEFT JOIN compact.evidence e USING(event_id) GROUP BY o.request_id)
   SELECT p.request_id,p.attempt_id,p.command_id,p.wallet_id,p.cell,t.first_event,t.final_event,(l.n=4 AND l.amounts AND l.buyer=0 AND l.supplier=0) ledger,
    (d.n>=2 AND d.acked) acked,d.n::int deliveries,t.customer_atoms,t.supplier_atoms,t.input_tokens,t.cached_tokens,t.output_tokens,t.reasoning_tokens
    FROM compact.permit p LEFT JOIN compact.terminal t USING(request_id) LEFT JOIN ledger l USING(request_id) LEFT JOIN deliveries d USING(request_id) WHERE pg_is_in_recovery()`;
 const money=new Map(financial.map(f=>[f.request_id,f]));
 const read=async ext=>(await Bun.file(output+ext).text()).trimEnd().split("\n").slice(1).map(s=>s.split("\t"));
 const providerCalls=new Map((await read(".upstream.tsv")).map(([id,attempt,time,calls,done,eof])=>[id,{attempt,time:+time,calls:+calls,done:+done,eof:+eof}]));
 const observed=new Map();let ackRows=0;
 for(const [id,attempt,event,rev,at] of await read(".ack.tsv")){
  let e=observed.get(id);if(!e)observed.set(id,e={});if(e[rev])duplicateObs++;e[rev]={attempt,event,at:+at};ackRows++;
 }
 const xs=[],walletCounts=new Uint32Array(1000),cellCounts=new Uint32Array(16);
 let missing=0,orderFailures=0,dbMatched=0,doubleAck=0,early=0,eventCount=0,minLead=null,barriers=0;
 const stagesFile=Bun.file(output+".stages.tsv").writer();stagesFile.write("request_id\tupstream_headers_ms\tstream_opened_ms\tfirst_feed_started_ms\tlast_feed_finished_ms\tpublic_headers_ready_ms\n");
 const writer=Bun.file(output+".identities.tsv").writer(),ew=Bun.file(output+".events.tsv").writer();
 writer.write("seq\trequest_id\tattempt_id\tcommand_id\twallet\tfirst_event\tfinal_event\tscheduled_epoch_ms\tdispatched_epoch_ms\tpublic_arrival_epoch_ms\tgrant_witness_epoch_ms\tupstream_send_epoch_ms\tupstream_receive_epoch_ms\tprovider_terminal_epoch_ms\tprovider_eof_epoch_ms\tgateway_eof_epoch_ms\tevidence_verified_epoch_ms\tterminal_witness_epoch_ms\tdone_release_epoch_ms\tclient_first_content_epoch_ms\tclient_done_epoch_ms\thttp_validated_epoch_ms\tlast_ack_observed_epoch_ms\tcomplete_epoch_ms\tdb_matched\n");
 ew.write("request_id\tattempt_id\tevent_id\trevision\tfinality\thook\toutcome\tsigned_epoch_ms\tdurable_witness_epoch_ms\tnext_ordinary_output_epoch_ms\tack_observed_epoch_ms\n");
 function ordered(vs){return vs.every((t,i)=>Number.isFinite(t)&&t>0&&(i===0||t>=vs[i-1]-.0001));}
 for(const [seq,id,sched,dispatched,at,status,valid,,headers,byte,frame,content,done] of await read(".http.tsv")){
   const x=index.get(id)??{},f=money.get(id),p=providerCalls.get(id),acks=observed.get(id)??{};
   if(p)stagesFile.write([id,x.upHeaders,x.opened,x.feedStart,x.feedEnd,x.headers].join("\t")+"\n");
   const dbOk=f&&f.wallet_id===Number(seq)%1000&&f.cell===f.wallet_id%16&&f.attempt_id===x.attempt&&f.command_id===x.command&&f.first_event===x.first&&f.final_event===x.final&&f.ledger&&f.acked&&f.deliveries===x.events?.length&&f.customer_atoms===100&&f.supplier_atoms===59&&f.input_tokens===7&&f.cached_tokens===3&&f.output_tokens===5&&f.reasoning_tokens===2;
   if(dbOk){dbMatched++;walletCounts[f.wallet_id]++;cellCounts[f.cell]++;}
   const es=x.events??[];eventCount+=es.length;
   let lastAck=0,prev=0;
   const ackOk=es.length>=2&&es.every((e,i)=>{const a=acks[i+1],t=x.trace[i];if(!a)return false;lastAck=Math.max(lastAck,a.at);
    const ok=Number(e.source_revision)===i+1&&e.attempt_id===x.attempt&&e.event_id===a.event&&a.attempt===x.attempt&&x.seen.has(i+1)&&
      ordered([t.signed,t.durable,...(t.ordinaryReleased?[t.ordinaryReleased]:[]),x.released])&&(!i||prev<=t.signed)&&ordered([t.signed,a.at]);
    prev=t.durable;return ok;})&&x.acked===lastAck&&Object.keys(acks).length===es.length;
   for(const [i,e] of es.entries()){const t=x.trace[i];ew.write([id,x.attempt,e.event_id,e.source_revision,e.finality,t.hook,e.attempt_state,t.signed,t.durable,t.ordinaryReleased,acks[i+1]?.at].join("\t")+"\n");}
   if(ackOk)doubleAck++;
   const base=[+sched,+dispatched,x.arrived,x.granted,x.sent,p?.time],timeline=[...base,p?.done,p?.eof,x.providerDone,x.verified,x.terminal,x.released,+done,+at];
   const order=ordered(timeline)&&ordered([...base,x.headers,+headers,+byte,+frame,+content,+done,+at]);if(!order)orderFailures++;
   if(es[0]?.finality==="PARTIAL"&&x.trace[0].ordinaryReleased&&ordered([x.trace[0].signed,x.trace[0].durable,x.trace[0].ordinaryReleased,+content]))barriers++;
   const lead=p?.done-Number(content);if(content&&lead>0){early++;minLead=minLead===null?lead:Math.min(minLead,lead);}
   const complete=valid==="1"&&status==="200"&&p?.calls===1&&p.attempt===x.attempt&&dbOk&&ackOk&&order?Math.max(Number(at),x.terminal,lastAck):0;
   if(!complete)missing++;
   xs.push({seq:+seq,sched:+sched,dispatched:+dispatched,at:+at,status:+status,valid:valid==="1",complete,granted:x.granted,verified:x.verified,terminal:x.terminal,ack:lastAck,arrived:x.arrived,sent:x.sent,providerDone:x.providerDone,firstContent:+content});
   writer.write([seq,id,x.attempt,x.command,x.wallet,x.first,x.final,...base,p?.done,p?.eof,x.providerDone,x.verified,x.terminal,x.released,content,done,at,lastAck||"",complete||"",Number(!!dbOk)].join("\t")+"\n");
 }
 await Promise.all([writer.end(),ew.end(),stagesFile.end()]);
 const wallets=await rd`SELECT id,spent,reserved,deposited FROM compact.wallet WHERE id<1000`,cells=await rd`SELECT id,spent,reserved,deposited FROM compact.supplier_cell`;
 const badWallets=wallets.filter(w=>Number(w.spent)!==100*walletCounts[w.id]||Number(w.reserved)!==0||Number(w.deposited)!==1000000).length;
 const badCells=cells.filter(w=>Number(w.spent)!==59*cellCounts[w.id]||Number(w.reserved)!==0||Number(w.deposited)!==1000000000).length;
 const byWindow=xs.filter(x=>x.complete>0&&x.complete<end).length,complete=xs.filter(x=>x.complete);
 const honest=(mode!=="paced"||(early===count&&adapter.counts.partial>=count&&barriers===count))&&(mode!=="burst"||adapter.counts.stream_drain>=count)&&missing===0&&orderFailures===0&&errors.length===0&&xs.length===count&&index.size===count&&financial.length===count&&provider.duplicates===0&&provider.requests===count&&ackRows===eventCount&&!duplicateObs&&!badWallets&&!badCells&&load.valid===count&&load.shed===0&&active===0&&wallets.length===1000&&cells.length===16&&adapter.counts.verified===eventCount&&adapter.counts.signed===eventCount&&consumer.verified===eventCount;
 const segment=(a,b)=>quant(complete.map(x=>x[b]-x[a]));
 const hash=async f=>new Bun.CryptoHasher("sha256").update(await Bun.file(f).bytes()).digest("hex");
 const files=[".stages.tsv",".identities.tsv",".events.tsv",".http.tsv",".upstream.tsv",".ack.tsv"];
 const target=rate===301?300:rate===1001?1000:(rate===3001||rate===3010)?3000:null;
 const sourceFiles=["pool.mjs","lane.mjs","model.sql","evidence.sql","public.mjs","adapter.mjs","common.mjs","actors.mjs","artifact-identity.json","signed-release.json","public-fixture-policy.json","provenance/host-progress-complete.patch","provenance/adapter-1.9.2-source.patch","check-settle-atomic.sql"];
 result={scope:"isolated loopback progressive Chat SSE prototype; distinct from the deployed gateway",createdAt:new Date().toISOString(),hardware:{cpus:cpus().length,model:cpus()[0]?.model,bun:Bun.version},configuration:{poolSize,transportLimit,mode,rate,seconds,count,driverLimit:load.driverLimit,inflightLimit:8192,executionLimit,pluginMaxAttempts:512,collectionMs,batchMax,stages,wallets:1000,supplierCells:16,clientClock:"same-host Date.now() in milliseconds",primarySettings,standbySettings,replication},artifacts:adapter.artifacts,
  accounting:{partialWitnessBeforeFirstContent:barriers,earlyFirstContentBeforeProviderDone:early,minPositiveLeadMs:minLead,eventCount,startEpochMs:start,endEpochMs:end,offers:count,arrived:index.size,httpValid:load.valid,provider,dbRows:financial.length,dbMatched,doubleAck,ackRows,complete:complete.length,inWindow:byWindow,completeRps:byWindow/seconds,includingDrainRps:complete.length*1000/Math.max(drained-start,seconds*1000),deadlineMissesVs5s:complete.filter(x=>x.complete-x.sched>5000).length,targetRps:target,withinTarget:target!==null&&honest&&byWindow>=seconds*target&&segment("sched","complete")[0.99]<=1500,loadShed:load.shed,loadPeak:load.peak,serverPeak:peak,drainMs:Math.max(0,drained-end),badWallets,badCells,orderFailures,duplicateObs,invalidAuth,accounted:honest},
  plugin:{...adapter.counts,independentConsumerVerified:consumer.verified,snapshot:adapter.snapshot()},pricingCalibration:{uncached:1,cached:4,output:2,customer:100,supplier:21,rolledBack:true},
  metrics:{firstContentMs:segment("sched","firstContent"),httpRpsByWindow:xs.filter(x=>x.valid&&x.at<end).length/seconds,inWindowSeconds:Array.from({length:seconds},(_,i)=>complete.filter(x=>x.complete>=start+i*1000&&x.complete<start+(i+1)*1000).length),dispatchLagMs:segment("sched","dispatched"),ingressToGrantMs:segment("arrived","granted"),grantToSendMs:segment("granted","sent"),upstreamMs:segment("sent","providerDone"),responseAndEvidenceMs:segment("providerDone","verified"),verifiedToTerminalMs:segment("verified","terminal"),httpValidLatencyMs:quant(xs.filter(x=>x.valid).map(x=>x.at-x.sched)),statusCounts:xs.reduce((acc,x)=>{acc[x.status]=(acc[x.status]??0)+1;return acc;},{}),fullIntersectionHttpLatencyMs:segment("sched","at"),completeLatencyMs:segment("sched","complete"),walBytes:wal,walPerOffered:wal/count,modelBytesDelta:Number(after.model_bytes)-Number(before.model_bytes),calls:callCount,batchSizes:Object.fromEntries(Object.entries(batches).map(([k,vs])=>[k,{mean:vs.reduce((a,b)=>a+b,0)/vs.length,quantiles:quant(vs)}])),cpu:pm.processes,cpuSampleErrors:pm.errors,cpuLimit:pm.limitation},
  sourceSha256:Object.fromEntries(await Promise.all(sourceFiles.map(async f=>[f,await hash(join(dir,f))]))),identitySha256:Object.fromEntries(await Promise.all(files.map(async f=>[f,await hash(output+f)]))),
  errors,limitations:["Single loopback HTTP prototype. No production Gateway auth, tenant isolation, mTLS, internal RPC command proof or distributed rate-limit and Redis quota lifecycle. Upstream is the repository HTTP mock, with one fixed route and synthetic credentials.","Single fixed request-completion customer tariff and intrinsic uncached/cached/output supplier prices, single currency, 100-atom synthetic grant hold and 16 pre-funded supplier cells. No production ceiling reservation, cancellation/refund, retry, dispute, multidimensional prices or writer fencing.","Each usage revision from the progressive observer commits to the primary and is witnessed on the standby before that hook releases bytes. The separate SUCCEEDED revision commits with money and the outbox for all events before DONE. Independent consumer verifies all signatures against pinned SPKI. Fixed successful streams only. Recovery, cancellation and Redis AOF delivery are outside the probe."]};
 fixture.assertHealthy();
}finally{
 stopping=true;
 for(const c of children){if(c.exitCode===null){c.kill();await c.exited;}}
 await Promise.all([http?.stop(true),control?.stop(true)]);await sampler?.close();await adapter?.close();
 await Promise.all([db?.close({timeout:2}),rd?.close({timeout:2})]);await fixture.close();
 const cleanup=await fixture.resources();await Bun.write(output+".cleanup.json",JSON.stringify({fixture:cleanup,childrenExitCodes:children.map(c=>c.exitCode),active},null,2)+"\n");
 if(result){result.cleanup=cleanup;await Bun.write(output+".json",JSON.stringify(result,null,2)+"\n");console.log(JSON.stringify(result.accounting));if(!result.accounting.accounted)process.exitCode=1;}
}
