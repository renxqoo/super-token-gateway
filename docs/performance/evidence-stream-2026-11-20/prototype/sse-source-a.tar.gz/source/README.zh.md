# Chat SSE 渐进联合原型

从当前项目根目录运行。需要 Bun 1.4.4、已构建的 dist/plugin-host/index.js 和 dist/native/builtin-adapters，以及 .local/toolchain 下的 pg17 和 redis74 工具。程序在系统临时目录初始化 PostgreSQL 17 主库及物理同步备库，只使用回环地址，退出时验证资源回收。每次选用新的输出前缀。P 为解压后源目录的绝对路径，R 为可写结果目录。本版本在入口的 JS 执行上下文调用发行插件。

~~~sh
export STG_REPO="$PWD"
P=/absolute/path/to/source
R=/absolute/path/to/results
mkdir -p "$R"
.local/toolchain/bun-1.4.4/bun --no-env-file "$P/public.mjs" 4 3 "$R/paced" paced
.local/toolchain/bun-1.4.4/bun --no-env-file "$P/public.mjs" 2 2 "$R/burst" burst
.local/toolchain/bun-1.4.4/bun --no-env-file "$P/public.mjs" 3010 60 "$R/high" fast
python3 "$P/recompute.py" "$R/high"
python3 "$P/profile.py" "$R/high"
~~~

原型单独启动固定到达客户端、HTTP 模拟供应商、公开 Chat SSE 试验入口和事件消费者。入口用发行包 prepare 的 URL、方法、请求体执行一次上游请求。接口的流式正文通过真实发行版 stream_open、stream_feed、需要时的 stream_drain 和 stream_finish 产生。网关按下游拉取读取，不聚合整条流；每次最多向宿主送 64 KiB，已产出的当前 hook 输出受宿主配额约束。普通内容按块发出，终止标记由插件持有，等终态资金和签名的身份见证完成后才给客户端。发生错误的请求不进入联合完成集合。

fast 使用仓库 mock 提供的默认短流和末尾用量。paced 在仓库 mock 上设为重复四段内容、120 字节分块和每块延迟 50ms。该模式模拟供应商在首条内容同时报告累计 10 个输入 token（含 3 个缓存）和 1 个输出 token。该上游 HTTP fixture 逐帧添加此字段，之后仍发送原 mock 的实际终值 10/3/5/2。客户端独立检查每个内容增量、完整 Unicode 文本、唯一 stop 和唯一的最终 [DONE]。上游服务独立记录发送终止帧与生成 EOF 的时刻，可以将客户端首内容同它相比较。burst 让同一 HTTP 请求发送四十段短文本，用来验证积压帧触发 stream_drain。

每个独立签名都使用真实 observer 的递增 revision、事件 ID、attempt ID、运行期公钥、规范化计量和状态。progressive 模式等待每次有变化的用量事实提交到主库并在备库读取同一事件签名全文，之后该 hook 才能向客户端交付字节。正常完成的最后 SUCCEEDED 事实、财务终态、两方各两条分录以及此前全部 revision 的 outbox 在一个事务提交。指定同步备库按 ID 见证终态、完整首尾签名、计量、收费和分录，再发 [DONE]。独立消费者复验每个签名和计量的阶段/终值，领取全部事件并获取外部 HTTP ACK，并在服务器从指定备库核对每个 ACK 后记时。

每次成功完成按 100 原子单位向客户收费。供应商按 7 个非缓存输入、3 个缓存输入、5 个输出分别乘以 3/1/7，计 59 原子单位。reasoning 为输出内的 2 个 token。写者按 wallet 所属组分批更新固定 1000 钱包和 16 个已预付供应商单元。运行前另取不同计量校准供应商应收 21 并回滚。

http.tsv 由客户端写出，upstream.tsv 由供应商写出，ack.tsv 由消费者写出，events.tsv 与 identities.tsv 由入口写出。所有角色在单机使用毫秒时钟。联合完成要同时满足有效 SSE、同身份上游接收恰好一次、资金与逐份签名和外部 ACK 齐全，并验证发生顺序。完成时刻取客户验证和最后外部 ACK 的最大值。在左闭右开的 60 秒窗口内计数，端到端时延从固定预定到达时刻算起。未从客户端发出的过载也保留在 http.tsv。原始密钥仅存于进程内存，每次运行为消费者固定公钥，数据库临时签名原件与资金行在对账后随夹具清理。归档可离线重算时序与身份交集；重新执行夹具可复验每份签名和资金。

实验范围为单一路由的正常成功链路。生产 API Key/租户授权、mTLS 会话和命令证明、Redis 跨节点速率与额度、生产 Redis AOF 队列、重试、取消退款、故障转移和多机恢复不在此原型中。进度证据的持久化介质为同机同步备库的 PG 追加表。CPU 是进程树采样，gateway 的 PID 已包含同进程的 JS worker 线程。
