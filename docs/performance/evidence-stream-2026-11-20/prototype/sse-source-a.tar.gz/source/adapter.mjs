import assert from "node:assert/strict";
import {generateKeyPairSync,sign,verify} from "node:crypto";
import {resolve} from "node:path";
import {audit,dir,project,repo,wall} from "./common.mjs";
export async function createAdapter(){
  const host=await project("dist/plugin-host/index.js");
  const {coreEvidenceEventV1Schema,coreEvidenceGroupV1Schema,evidenceProofFields,signedCoreEvidenceEventV1Schema}=await project("packages/contracts/src/core-execution.ts");
  const {canonical}=await project("packages/kernel/src/canonical.ts");
  const {requestCharacters}=await project("packages/adapters/src/protocol/characters.ts");
  const {sha256}=await project("packages/runtime/src/crypto.ts");
  const workerPath="dist/native/builtin-adapters/worker.js",registryPath="dist/native/builtin-adapters/registry.json";
  const [code,registryBytes,hostBytes,policyBytes,signedBytes,bunBytes]=await Promise.all([resolve(repo,workerPath),resolve(repo,registryPath),resolve(repo,"dist/plugin-host/index.js"),resolve(dir,"public-fixture-policy.json"),resolve(dir,"signed-package.json"),process.execPath].map(p=>Bun.file(p).bytes()));
  const registry=host.parseBuiltinWorkerArtifact(JSON.parse(Buffer.from(registryBytes)),code,sha256(bunBytes));
  const approval=audit.runtimeApproval;
  assert.equal(registry.artifact_digest,approval.execution.artifact_digest);
  assert.equal(sha256(code),audit.artifacts[workerPath]);assert.equal(sha256(registryBytes),audit.artifacts[registryPath]);
  const policy=host.packageTrust(host.releasePolicySchema.parse(JSON.parse(Buffer.from(policyBytes))));
  const pkg=host.verifyPackage(signedBytes,policy(approval.package_digest));
  const runtime=host.verifiedPackageRuntime(pkg),record=registry.records.find(r=>r.package_digest===runtime.digest);
  assert.equal(runtime.digest,approval.package_digest);assert.equal(record.module_hash,host.pluginModuleInfo(runtime.module).hash);
  assert.equal(record.release_id,runtime.manifest.id+"-"+runtime.manifest.version);assert(policy.isPlatform(pkg)&&policy.admits(pkg));
  const worker=host.createBuiltinWorkerExecutor({code,digest:registry.worker_digest,modules:registry.records.map(item=>item.module_hash),maxPending:512});
  const attempts=host.createPluginAttempts(worker,{maxAttempts:512,maxStateBytes:512*(256<<10)});
  const identity={origin_identity:"gateway:public-short-probe",origin_incarnation:crypto.randomUUID(),origin_session_id:crypto.randomUUID()};
  const tenant=crypto.randomUUID(),key=generateKeyPairSync("ed25519"),publicKey=key.publicKey.export({format:"pem",type:"spki"});
  const proof=b=>Buffer.from(JSON.stringify(evidenceProofFields(b,sha256(canonical(b)))));
  const expected=canonical({input_tokens:"7",cached_input_tokens:"3",output_tokens:"5",reasoning_tokens:"2"});
  const config={model_map:{[audit.model]:"synthetic"},max_output_tokens:100,max_input_tokens:4096,auth:"bearer"};
  const counts={prepare:0,prepareMessages:0,stream_open:0,stream_feed:0,stream_drain:0,stream_finish:0,signed:0,verified:0,partial:0,final:0};
  const artifacts={workerSha256:sha256(code),registrySha256:sha256(registryBytes),packageDigest:pkg.digest,artifactDigest:registry.artifact_digest,hostSha256:sha256(hostBytes),bunSha256:sha256(bunBytes),fixturePackageSha256:sha256(signedBytes),policySha256:sha256(policyBytes),moduleHash:record.module_hash,publicKey};
  const {stallGuard}=await project("apps/gateway/src/stream-deadlines.ts");
  async function invoke(x,input,upstreamOrigin,{progress,settle,release,failure,signal}){
    const body=JSON.parse(Buffer.from(input));assert.equal(body.model,audit.model);assert.equal(body.stream,true);
    const clock=AbortSignal.timeout(30000),stop=new AbortController(),cancel=AbortSignal.any([signal,clock,stop.signal]);
    const one=attempts.create(pkg,{tenant,attempt:x.attempt,incarnation:identity.origin_incarnation,deadlineAt:wall()+30000,config:host.validateConfig(runtime.configSchema,config)});
    let reader,bridge,clean=false;
    const finish=async()=>{if(clean)return;clean=true;stop.abort();await reader?.cancel().catch(()=>undefined);bridge?.dispose();one.dispose();release();};
    try{
      const prep=await one.transformJSON("prepare",{protocol:"chat",operation:"chat",model:body.model,input_characters:String(requestCharacters("chat",body))},input,cancel);
      assert.equal(prep.result.kind,"prepared");const reqBody=JSON.parse(Buffer.from(prep.body));assert.equal(reqBody.model,"synthetic");assert.equal(reqBody.stream,true);
      counts.prepare++;counts.prepareMessages+=one.snapshot().sequence;
      const route=prep.result.request;assert.equal(route.method,"POST");assert.equal(route.path,"/v1/chat/completions");assert(x.granted);
      x.sent=wall();
      const res=await fetch(new URL(route.path,upstreamOrigin),{method:route.method,headers:{...route.headers,authorization:"Bearer fixture","x-probe-id":x.id,"x-probe-attempt":x.attempt},body:prep.body,redirect:"error",signal:cancel});
      assert.equal(res.status,200);assert.equal(res.headers.get("x-probe-id"),x.id);assert(res.headers.get("content-type").includes("text/event-stream"));
      reader=res.body.getReader();
      bridge=host.observeAttempt(one,{attemptId:x.attempt,permitEpoch:"1",delivery:"progressive",
        seal(fact){const e=coreEvidenceEventV1Schema.parse({...fact,...identity});counts.signed++;return signedCoreEvidenceEventV1Schema.parse({...e,signature:sign(null,proof(e),key.privateKey).toString("base64url")});},
        async record(facts){
          assert.equal(facts.length,1);const [event]=facts,{signature,...e}=event;assert.equal(e.attempt_id,x.attempt);assert.equal(Number(e.source_revision),x.events.length+1);
          assert(["FINAL","PARTIAL"].includes(e.finality));if(e.finality==="PARTIAL"&&e.usage.output_tokens==="1")assert.equal(canonical(e.usage),canonical({input_tokens:"7",cached_input_tokens:"3",output_tokens:"1"}));else assert.equal(canonical(e.usage),expected);assert(verify(null,proof(e),key.publicKey,Buffer.from(signature,"base64url")));counts.verified++;counts[e.finality==="PARTIAL"?"partial":"final"]++;
          x.events.push(event);const point={signed:wall(),durable:0,hook:x.hook};x.trace.push(point);x.first??=e.event_id;
          if(e.attempt_state){assert.equal(e.attempt_state,"SUCCEEDED");assert.equal(e.request_state,"SUCCEEDED");assert.equal(e.finality,"FINAL");assert.equal(x.events.at(-2)?.finality,"FINAL");
            x.final=e.event_id;const u=e.usage;x.input=Number(u.input_tokens);x.cached=Number(u.cached_input_tokens);x.output=Number(u.output_tokens);x.reasoning=Number(u.reasoning_tokens);x.verified=wall();await settle(x);
          }else{await progress(x);}
          point.durable=wall();
        }});
      async function call(hook,payload){counts[hook]++;x.hook=hook;return bridge.invoke(hook,payload,cancel);}
      async function* frames(){
        let terminal;
        function* emit(result){
          assert.equal(result.kind,"output");for(const base64 of result.chunks){const bytes=Buffer.from(base64,"base64");if(!bytes.length)continue;
            if(x.trace.length){const point=x.trace.at(-1);assert(point.durable>0);point.ordinaryReleased??=wall();}yield bytes;
          }
          if(result.output_id)one.releaseOutput(result.output_id);
          if(result.terminal)terminal=result.terminal;
          return result.needs_input||Boolean(terminal);
        }
        try{
          const opened=await call("stream_open",new TextEncoder().encode(JSON.stringify({model:body.model,protocol:"chat"})));assert.equal(opened.kind,"output");
          for(;;){const next=await reader.read();if(next.done){cancel.throwIfAborted();x.providerDone=wall();break;}
            for(let offset=0;offset<next.value.length&&!terminal;){const fed=await call("stream_feed",next.value.subarray(offset,offset+(64<<10)));let waiting=yield* emit(fed);
              while(!waiting){waiting=yield* emit(await call("stream_drain"));}assert(fed.consumed>0);offset+=fed.consumed;}
          }
          yield* emit(await call("stream_finish"));assert.equal(terminal?.kind,"complete");x.hook="outcome";await bridge.finish({attempt_state:"SUCCEEDED",request_state:"SUCCEEDED"},true);
          const done=Buffer.from(terminal.bytes,"base64");assert(done.length>0);assert(x.terminal>0);x.released=wall();yield done;
        }catch(e){failure(e);throw e;}finally{await finish();}
      }
      const iter=frames(),first=await iter.next();assert(!first.done);x.headers=wall();
      return new Response(stallGuard(iter,first.value,30000,()=>stop.abort()),{headers:{"content-type":"text/event-stream","cache-control":"no-cache","x-probe-id":x.id}});
    }catch(e){await finish();throw e;}
  }
  return {invoke,publicKey,artifacts,counts,snapshot:()=>({worker:worker.snapshot(),attempts:attempts.snapshot()}),close:()=>attempts.close()};
}
