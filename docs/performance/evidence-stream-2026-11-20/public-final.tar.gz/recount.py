from datetime import datetime
from math import ceil
from pathlib import Path
import json
import sys

def identities(path):
    result = {}
    for line in path.read_text().splitlines():
        identity, at = line.split('\t')
        if identity in result:
            raise ValueError(f'duplicate identity in {path.name}')
        result[identity] = int(at)
    return result

base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
for run in sorted(base.iterdir()):
    if not run.is_dir() or not (run/'http.json').is_file():
        continue
    h = json.loads((run/'http.json').read_text())
    a = json.loads((run/'audit.json').read_text())
    valid = identities(run/'http.json.identities.tsv')
    acked = identities(run/'ack.identities.tsv')
    starts = identities(run/'http.json.dispatch.tsv')
    if starts.keys() != valid.keys():
        raise ValueError('unmatched dispatch identities')
    matched = {k:max(t,acked[k]) for k,t in valid.items() if k in acked}
    start = round(datetime.fromisoformat(h['measurement_started_at'].replace('Z','+00:00')).timestamp()*1000)
    seconds = a['seconds']
    count = sum(start <= t < start+seconds*1000 for t in matched.values())
    latencies = sorted(t-starts[k] for k,t in matched.items())
    assert count == a['onlineCapacity']['fullyCompletedByWindow']
    print(run.name, json.dumps({'rps': count/seconds, 'complete': count, 'matched':len(matched),
        'p99Ms': latencies[ceil(len(latencies)*.99)-1] if latencies else None}))
