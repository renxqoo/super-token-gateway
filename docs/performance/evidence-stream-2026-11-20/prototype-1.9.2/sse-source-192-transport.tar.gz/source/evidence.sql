CREATE TABLE compact.signer (public_key text PRIMARY KEY);
CREATE TABLE compact.evidence (
 event_id uuid PRIMARY KEY,
 attempt_id uuid NOT NULL REFERENCES compact.permit(attempt_id),
 revision smallint NOT NULL CHECK(revision BETWEEN 1 AND 16),
 signer text NOT NULL REFERENCES compact.signer,
 signed_body jsonb NOT NULL CHECK (
   signed_body ?& ARRAY['event_id','attempt_id','signature','source_revision','usage','origin_identity','origin_incarnation','origin_session_id']
   AND event_id=(signed_body->>'event_id')::uuid AND attempt_id=(signed_body->>'attempt_id')::uuid AND revision=(signed_body->>'source_revision')::smallint
 ), UNIQUE(attempt_id,revision)
);
ALTER TABLE compact.outbox ADD FOREIGN KEY(event_id) REFERENCES compact.evidence(event_id);
