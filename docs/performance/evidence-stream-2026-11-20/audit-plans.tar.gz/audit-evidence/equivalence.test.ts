import { expect, test } from "bun:test";
import { createSettlementStore } from "@gateway/storage/settlement";
import { createEventStore, recordEventConsumer } from "@gateway/storage";
import {
  confirmedStreamRequests,
  verifiedStreamProgress,
} from "../scripts/capacity-stream-completion.ts";
import { committed, event, granted } from "../tests/support/core-settlement.ts";
import { withFinancial } from "../tests/support/financial-execution.ts";

import { confirmedStreamRequests as baseline } from "./baseline.ts";

test("an ACKed stream snapshot cannot count before authenticated terminal evidence, exact settlement and all external ACKs", () =>
  withFinancial(async (f, db) => {
    const setup = await f.bootstrap("USD", "100000");
    const client = f.client();
    await client.startup();
    const { prepared, owner } = await granted(db, setup, client, { stream: true });
    const consumer = await db.begin((tx) => recordEventConsumer(tx, "stream-capacity", false));
    const store = createSettlementStore(db);
    const delivery = createEventStore(db);
    const usage = { input_tokens: "6", output_tokens: "3" };
    const prices = { charge: "100", cost: "3", usage };
    const subjects = [prepared.requestId];
    const complete = () => confirmedStreamRequests(db, subjects, consumer, true, prices);
    const send = async (fields: Parameters<typeof event>[2]) => {
      committed((await store.persist([{ events: [event(owner, prepared.attemptId, fields)] }]))[0]);
      return delivery.claim(consumer, 10);
    };
    const partial = await send({
      source_revision: "1",
      usage: { input_tokens: "3" },
      finality: "PARTIAL",
    });
    expect(partial.events).toHaveLength(1);
    expect(await verifiedStreamProgress(db, partial.events)).toEqual(
      new Set([partial.events[0]!.id]),
    );
    expect(
      await verifiedStreamProgress(db, [{ ...partial.events[0]!, usage: { input_tokens: "99" } }]),
    ).toEqual(new Set());
    expect(
      await delivery.ack(
        consumer,
        partial.lease_token,
        partial.events.map((e) => e.id),
      ),
    ).toBe(1);
    expect(await complete()).toEqual([]);
    const meter = await send({
      source_revision: "2",
      finality: "FINAL",
      usage,
      final_dimensions: ["input_tokens", "output_tokens"],
    });
    expect(
      await delivery.ack(
        consumer,
        meter.lease_token,
        meter.events.map((e) => e.id),
      ),
    ).toBe(1);
    expect(await complete()).toEqual([]);
    const terminal = await send({
      source_revision: "3",
      finality: "FINAL",
      usage,
      final_dimensions: ["input_tokens", "output_tokens"],
      attempt_state: "SUCCEEDED",
      request_state: "SUCCEEDED",
    });
    expect(await confirmedStreamRequests(db, subjects, consumer, false, prices)).toEqual([
      { request_id: prepared.requestId },
    ]);
    expect(await complete()).toEqual([]);
    expect(
      await delivery.ack(
        consumer,
        terminal.lease_token,
        terminal.events.map((e) => e.id),
      ),
    ).toBe(1);
    expect(await complete()).toEqual([{ request_id: prepared.requestId }]);
    const foreign = "00000000-0000-4000-a000-000000000001";
    await db.begin(async (tx) => {
      const correlate = async (name: string, accept: boolean) => {
        for (const query of [baseline, confirmedStreamRequests]) {
          const rows = await query(tx, [foreign, ...subjects, ...subjects], consumer, true, prices);
          expect(
            rows.map((row) => row.request_id),
            name,
          ).toEqual(accept ? subjects : []);
        }
        console.log("matched plans", name, accept ? "accepted" : "rejected");
      };
      const mask = async (name: string, table: string, change: string) => {
        await tx.unsafe(`CREATE TEMP VIEW ${table} AS SELECT v.* FROM public.${table} r
          CROSS JOIN LATERAL jsonb_populate_record(r,${change}) v`);
        try {
          await correlate(name, false);
        } finally {
          await tx.unsafe(`DROP VIEW pg_temp.${table}`);
        }
      };
      await correlate("duplicate, missing, and valid request", true);
      await mask(
        "incorrect wallet",
        "money_journal",
        `jsonb_build_object('wallet_id','${foreign}'::text)`,
      );
      await mask(
        "incorrect reference",
        "money_journal",
        "jsonb_build_object('reference','another:'||r.id)",
      );
      await mask(
        "incorrect currency",
        "money_journal",
        "jsonb_build_object('currency','EUR'::text)",
      );
      await mask("incorrect kind", "money_journal", "jsonb_build_object('kind','HOLD'::text)");
      await mask(
        "unbalanced customer lines",
        "money_journal",
        `jsonb_build_object('lines','[{"account":"system:revenue","atoms":"100"},{"account":"customer:test","atoms":"-99"}]'::jsonb)`,
      );
      await mask(
        "negative customer revenue, balanced",
        "money_journal",
        `jsonb_build_object('lines','[{"account":"system:revenue","atoms":"-100"},{"account":"customer:test","atoms":"100"}]'::jsonb)`,
      );
      await mask(
        "buyer canonical ID belongs to neither ledger nor attempt",
        "billing_charges",
        `jsonb_build_object('evidence_id','${foreign}'::text)`,
      );
      await mask(
        "supplier canonical ID belongs to neither ledger nor attempt",
        "upstream_costs",
        `jsonb_build_object('evidence_id','${foreign}'::text)`,
      );
      await mask(
        "unverified terminal receipt",
        "core_evidence_receipts",
        "jsonb_build_object('authentication_disposition','UNVERIFIED'::text)",
      );
      await mask(
        "all supplier journal net/prices invalid",
        "upstream_entries",
        "jsonb_build_object('atoms',101)",
      );
      await tx`INSERT INTO public.money_journal (id,wallet_id,reference,kind,currency,lines,created_at)
        SELECT gen_random_uuid(),wallet_id,'archived-audit:'||${prepared.requestId}::text,kind,currency,lines,'2000-01-01 00:00:00 UTC'::timestamptz
        FROM public.money_journal WHERE reference='settle:'||${prepared.requestId}::text`;
      const shard = await tx`SELECT p.tableoid::regclass::text AS shard FROM public.money_entries m
        JOIN public.journal_payloads p ON (m.id,m.created_at)=(p.id,p.created_at)
        WHERE reference='archived-audit:'||${prepared.requestId}::text`;
      expect(shard[0].shard).toBe("journal_payloads_default");
      await tx`CREATE TEMP VIEW money_journal AS
        SELECT id,wallet_id,replace(reference,'archived-audit:','settle:') AS reference,kind,currency,lines,created_at
        FROM public.money_journal WHERE reference LIKE 'archived-audit:%'`;
      await correlate(
        "authenticated request reads historical fallback payload using remapped test reference",
        true,
      );
      await tx`DROP VIEW pg_temp.money_journal`;
    });
    await db.begin(async (tx) => {
      await tx`CREATE TEMP VIEW core_evidence_receipts AS
        SELECT * FROM public.core_evidence_receipts WHERE request_state IS DISTINCT FROM 'SUCCEEDED'`;
      expect(await confirmedStreamRequests(tx, subjects, consumer, true, prices)).toEqual([]);
    });
    expect(
      await confirmedStreamRequests(db, subjects, consumer, true, { ...prices, cost: "2" }),
    ).toEqual([]);
  }));
