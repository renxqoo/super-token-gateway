import { test, expect } from "bun:test";
import { SQL } from "bun";
import { createEventStore, recordEventConsumer } from "@gateway/storage";
import { createSettlementStore } from "@gateway/storage/settlement";
import { granted, committed, event } from "../tests/support/core-settlement.ts";
import { withFinancial } from "../tests/support/financial-execution.ts";
import { confirmedStreamRequests as baseline } from "./baseline.ts";
import { confirmedStreamRequests as candidate } from "../scripts/capacity-stream-completion.ts";
import { resolve } from "node:path";

const run = process.env.AUDIT_RUN ?? "before";
test("profile actual acknowledged ledger identities using the strict capacity observer", () =>
  withFinancial(async (f, db) => {
    const setup = await f.bootstrap("USD", "1000000"),
      client = f.client();
    await client.startup();
    const consumer = await db.begin((tx) => recordEventConsumer(tx, "audit-plan", false));
    const delivery = createEventStore(db),
      store = createSettlementStore(db);
    const ids: string[] = [],
      usage = { input_tokens: "6", output_tokens: "3" },
      prices = { charge: "100", cost: "3", usage };
    for (let n = 0; n < Number(process.env.AUDIT_SUBJECTS ?? 32); n++) {
      const { prepared, owner } = await granted(db, setup, client, { stream: true });
      const common = {
        finality: "FINAL" as const,
        usage,
        final_dimensions: ["input_tokens", "output_tokens"],
      };
      const r = await store.persist([
        {
          events: [
            event(owner, prepared.attemptId, { ...common, source_revision: "1" }),
            event(owner, prepared.attemptId, {
              ...common,
              source_revision: "2",
              attempt_state: "SUCCEEDED",
              request_state: "SUCCEEDED",
            }),
          ],
        },
      ]);
      committed(r[0]);
      ids.push(prepared.requestId);
    }
    for (;;) {
      const page = await delivery.claim(consumer, 128);
      if (!page.events.length) break;
      expect(
        await delivery.ack(
          consumer,
          page.lease_token,
          page.events.map((e) => e.id),
        ),
      ).toBe(page.events.length);
    }
    expect(
      (await baseline(db, ids, consumer, true, prices)).map((r) => r.request_id).sort(),
    ).toEqual([...ids].sort());
    const connection = await db.reserve();
    try {
      const native =
        await connection`SELECT current_setting('jit') jit,current_setting('join_collapse_limit') join_collapse_limit,current_database() db`;
      const pgRows =
        await connection`SELECT relname,pg_total_relation_size(relid)::text bytes,n_live_tup::text approx FROM pg_stat_user_tables WHERE relname IN ('usage_event_index','upstream_journals','upstream_entries','core_evidence_receipts','money_entries','attempts') ORDER BY relname`;
      const files = [];
      await connection.unsafe(
        "CREATE TEMP TABLE audit_extra_ids AS SELECT gs,gen_random_uuid() journal FROM generate_series(1,8000) gs",
      );
      await connection.unsafe("BEGIN");
      await connection.unsafe(
        "INSERT INTO upstream_journals(id,account_id,channel_id,attempt_id,operation_id,currency,kind,reference) SELECT x.journal,j.account_id,j.channel_id,NULL,j.operation_id,j.currency,j.kind,'audit-history:'||x.journal FROM audit_extra_ids x CROSS JOIN LATERAL (SELECT * FROM upstream_journals WHERE attempt_id IS NULL LIMIT 1) j",
      );
      await connection.unsafe(
        "INSERT INTO upstream_entries(journal_id,ordinal,currency,account,atoms) SELECT x.journal,e.ordinal,e.currency,e.account,e.atoms FROM audit_extra_ids x CROSS JOIN LATERAL (SELECT e.* FROM upstream_entries e WHERE e.journal_id=(SELECT id FROM upstream_journals WHERE reference NOT LIKE 'audit-history:%' AND attempt_id IS NULL LIMIT 1)) e",
      );

      await connection.unsafe(
        "CREATE TEMP TABLE audit_money_seed AS SELECT * FROM money_journal WHERE kind='SETTLE' LIMIT 1",
      );
      await connection.unsafe(
        "WITH n AS (INSERT INTO money_entries(id,wallet_id,reference,kind,currency,created_at) SELECT x.journal,m.wallet_id,'settle:'||x.journal,m.kind,m.currency,m.created_at FROM audit_extra_ids x CROSS JOIN audit_money_seed m RETURNING id,created_at) INSERT INTO journal_payloads(id,created_at,lines) SELECT n.id,n.created_at,m.lines FROM n CROSS JOIN audit_money_seed m",
      );
      await connection.unsafe("COMMIT");
      const history =
        await connection`SELECT (SELECT count(*) FROM upstream_journals WHERE reference LIKE 'audit-history:%') j,(SELECT count(*) FROM upstream_entries e JOIN audit_extra_ids x ON e.journal_id=x.journal) e`;
      expect(+history[0].j).toBe(8000);
      expect(+history[0].e).toBeGreaterThan(0);
      if (process.env.AUDIT_ANALYZE === "1") await connection.unsafe("ANALYZE");
      const missing = crypto.randomUUID();
      for (const [label, fn] of Object.entries(
        run.startsWith("before") ? { baseline } : { baseline, candidate },
      )) {
        for (const mode of ["force_generic_plan", "force_custom_plan"]) {
          await connection.unsafe("SET plan_cache_mode=" + mode);
          for (const [key, subset] of Object.entries({
            missing: [missing],
            one: ids.slice(0, 1),
            batch: ids.slice(0, 16),
          })) {
            const joined = await fn(connection as any, subset, consumer, true, prices);
            expect(joined.map((r) => r.request_id).sort()).toEqual(
              subset.filter((id) => id !== missing).sort(),
            );
            const tagged = (arr: TemplateStringsArray, ...values: unknown[]) => {
              const head = "EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) ";
              const parts = [...arr];
              parts[0] = head + parts[0];
              Object.defineProperty(parts, "raw", {
                value: [head + arr.raw[0], ...arr.raw.slice(1)],
              });
              return (connection as any)(parts, ...values);
            };
            const raw = (await fn(tagged as any, subset, consumer, true, prices)) as any;
            const path = resolve(
              ".diagnostic",
              run + "-" + label + "-" + mode + "-" + key + ".json",
            );
            await Bun.write(path, JSON.stringify(raw[0]["QUERY PLAN"], null, 1));
            files.push(path);
          }
        }
      }
      await Bun.write(
        resolve(".diagnostic", run + "-summary.json"),
        JSON.stringify(
          {
            subjects: ids.length,
            history,
            pgRows,
            settings: native.map(({ jit, join_collapse_limit }) => ({ jit, join_collapse_limit })),
            files: files.map((p) => p.split("/").at(-1)),
          },
          null,
          2,
        ),
      );
    } finally {
      connection.release();
    }
  }));
