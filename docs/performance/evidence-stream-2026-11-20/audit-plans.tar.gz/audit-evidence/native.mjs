import { resolve } from "node:path";
import { createNativeFixture } from "../tests/support/native-fixture.ts";
const root = process.cwd(),
  dir = resolve(root, ".diagnostic");
const f = await createNativeFixture({
  postgresToolsDirectory: resolve(root, ".local/toolchain/pg17/bin"),
  redisServer: resolve(root, ".local/toolchain/redis74/bin/redis-server"),
  diskBudgetBytes: 2 * 1024 ** 3,
  truncateProcessOutput: true,
});
try {
  const pg = await f.startPostgres(),
    redis = await f.startRedis("redis-audit");
  const child = Bun.spawn(
    [
      process.execPath,
      "--no-env-file",
      "test",
      process.argv[2] ?? ".diagnostic/ledger.test.ts",
      "--timeout",
      "120000",
    ],
    {
      env: { ...process.env, DATABASE_URL: pg.url, REDIS_URL: redis.url, MINIMAX_API_KEY: "" },
      stdout: "inherit",
      stderr: "inherit",
      cwd: root,
    },
  );
  process.exitCode = await child.exited;
} finally {
  await f.close();
  console.log("fixture cleanup", JSON.stringify(await f.resources()));
}
