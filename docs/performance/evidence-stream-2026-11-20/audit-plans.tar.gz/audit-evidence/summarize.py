import json
from pathlib import Path

base = Path(__file__).resolve().parent

def relations(node, relation):
    if node.get("Relation Name") == relation:
        yield node
    for child in node.get("Plans", []):
        yield from relations(child, relation)

print("statistics\tvariant\tplan_setting\tinput\tplanner_ms\texecutor_ms\tshared_hit\tmoney_plan(rows*loops)")
for name in ["funded", "mature"]:
    for mode in ["force_generic_plan", "force_custom_plan"]:
        for size in ["missing", "one", "batch"]:
            for revision in ["baseline", "candidate"]:
                source = base / f"{name}-{revision}-{mode}-{size}.json"
                profile = json.loads(source.read_text())[0]
                plan = profile["Plan"]
                reads = [
                    f"{node['Node Type']}({node['Actual Rows']}*{node['Actual Loops']})"
                    for node in relations(plan, "money_entries")
                ]
                print(name, revision, mode, size, profile["Planning Time"],
                      profile["Execution Time"], plan["Shared Hit Blocks"], ",".join(reads), sep="\t")
