# 流式容量审计的客户结算流水查找

正式 v4 快流台架每秒计划 151 笔，持续 60 秒，目标 150 笔/秒，使用 1,000 个钱包。HTTP 在窗口内完成 9,045 笔，其中 6,907 笔在同一窗口得到可验证外部确认，每秒 115.12 笔。PostgreSQL 记录严格核算 SQL 执行 2,434 次，总执行时间 52,014.918 ms，平均 21.37 ms。查询语句以完整资金、用量、认证证据和消费者投递事实共同判定；bench 的消费者在外部 ACK 前后均读取它。正式数据节录及原始 audit 的 SHA-256 在 official-v4-excerpt.json。

## 修改及成立条件

补丁只修改 scripts/capacity-stream-completion.ts 和现有 tests/integration/capacity-stream-completion.test.ts。将请求、买方持有、收费、钱包以及该笔客户资金流水组成独立的物化子查询，由输入的去重请求 ID 与实际钱包定位唯一的 settle 引用。原有每一项请求状态、收费金额、资金来源、退款、债务、币种、客户收入与行平衡判定均保留。

packages/storage/src/migrations/0000_enterprise.sql 第 411 行定义 money_entries 的 UNIQUE(wallet_id,reference)，第 388 行定义分区载荷的 PRIMARY KEY(id,created_at)，第 908 行的 money_journal 视图以完整主键关联。上述字段均必填，因此查询在该视图中按钱包及精确引用查找至多返回一行；LIMIT 1 不会排除另一份有待验证的载荷。查询继续使用公共视图，现行月份分区及默认分区均可读取。

buyer/supplier canonical 证据关联、已验签成功终态、精确用量及上游价格、该请求所有尝试的非 RAW 投递、目标消费者匹配、每笔供应商流水归属和借贷平衡与最终总成本均继续校验。本次未改消费者 ACK 和计时时点、发起上游、签名或流式输出。回归覆盖相同 ID 重复出现时只计一次，孤立或不存在的 ID 无法冒领。供应商同一尝试可以有多本日志，查询依旧遍历其全部相关账本。

## 计划实测

隔离 PG17、Redis 与原生 Core 的 8 个流式授权实际结算，逐笔有 2 条已签名并持久化的证据，消费者成功 claim、ACK。该小夹具的客户额为 100、上游额为 3、用量为 6 输入和 3 输出；正式 v4 工作负载上游额为 59。额外 8,000 条同钱包平衡的客户结算和对应分区载荷、8,000 本供应商历史及 16,000 条分录由隔离 SQL 构造。它们用于改变查询数据量，未计入 8 个请求。这里没有发送公开 HTTP 或测量整机容量。

每个数据状态内使用同一 PG 连接及同批实际身份先跑基线、再跑候选，真实查询结果与预期身份集合一致。funded 记录插入历史后立即查询，mature 在独立相同装置内显式 ANALYZE 后执行。每个状态各保留 12 份 EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)。plan_cache_mode 分别设置为 force_generic_plan 和 force_custom_plan，每种输入每种设置记录一次计划。未对原正式访问历史逐条回放；运行时延迟随缓存和统计状态变化。

| 状态，generic 设置 | 输入 | 基线执行 ms | 候选执行 ms | 基线共享缓冲命中 | 候选共享缓冲命中 |
| --- | --- | ---: | ---: | ---: | ---: |
| 历史插入后 | 单笔 | 4.937 | 0.487 | 24,347 | 203 |
| 历史插入后 | 8 笔 | 37.703 | 0.571 | 193,680 | 520 |
| ANALYZE 后 | 单笔 | 2.561 | 0.449 | 527 | 193 |
| ANALYZE 后 | 8 笔 | 2.762 | 0.598 | 727 | 418 |

立即读历史时基线对 8 个候选发起 8 次顺序扫描，每次返回 8,008 个钱包流水；候选按请求与钱包键做 8 次索引访问，每次返回 1 行。显式 ANALYZE 后，基线仍扫 8,008 行一次；候选仍按 8 个请求取 8 行。不存在的 ID 在立即读历史时两版均未查到钱包流水，显式 ANALYZE 后候选会做一次空索引探测，7 次缓存命中，基线 3 次。全套计划的规划耗时约 4–6 ms，每次 EXPLAIN 单独列出，未混入执行耗时。正式台架所记录的 pg_stat_statements.total_exec_time 也只计执行时间。执行成本改进不能单独推导整机吞吐。

## 红绿与等价性

- 原生代码回归在 4,096 条同钱包其他历史存在时，对包含一个实际 ID、其重复项与无效 ID 的批次核算，准确返回唯一目标，并以事务自身 PostgreSQL 表统计限制该审计对 money_entries 的读行数。基线实读 4,099，超过 64 行预算。候选 1 通过、17 个断言。掩去正确引用后，其他钱包流水不能冒领。
- 独立协议校准对真实认证、真实金额已结算的同一笔请求，在可回收库的只读临时视图注入错误。两版均拒绝错钱包、错引用、错币种、错种类、分录不平、借贷合计为零但收入为负、错买方 canonical ID、错供应方 canonical ID、未认证终态和供应商分录失衡。混合重复与未知输入时两版均精确计一笔。实际写到 journal_payloads_default 的 2000 年平衡载荷经只读视图映射其引用后，仍正确识别。此项验证历史分区读值，未进行旧版本数据库升级演练。
- 两组计划各 1 通过、24 个断言。独立协议校准 1 通过、39 个断言。每次原生夹具都记录零进程、零目录、零端口、零计时器。候选 TypeScript 检查覆盖隔离树 371 个文件，修改的 2 个文件通过格式和 oxlint 检查。全仓 CI 与正式端到端性能由主区另行验收。

## 复现

在历史实验目录外可直接用 Python 从归档的原始计划重新生成汇总。以下 shell 命令从解压本目录执行。

```sh
shasum -a 256 -c SHA256SUMS
python3 summarize.py > /tmp/confirmed-stream-plans.tsv
diff -u plans.tsv /tmp/confirmed-stream-plans.tsv
```

重做原生实测需有该项目本次开发态对应源码、workspace 依赖、仓库指定 Bun 1.4.4、原生插件发行包及构建产物、PG17、Redis 7.4。隔离原生代码快照的 Git 血统为 5ce3f3573aebae910bfede96b6adf8aef79132a0，包含本次正在开发的正式流式/Core 修改；原始审计文件及完整增量在本包中。请在此类准备完毕的独立检出执行，放入归档时使用的脚本與源，避免覆盖日常源码。原生工具由测试创建一次性数据库和端口，使用本仓库的 tests/support/native-fixture；无需提供真实凭据或连接工作库。

```sh
evidence=/path/to/unpacked/audit-evidence
mkdir -p .diagnostic
cp "$evidence"/baseline.ts "$evidence"/ledger.test.ts "$evidence"/native.mjs "$evidence"/equivalence.test.ts .diagnostic/
cp "$evidence"/candidate.ts scripts/capacity-stream-completion.ts
cp "$evidence"/candidate.test.txt tests/integration/capacity-stream-completion.test.ts
bun_path=.local/toolchain/bun-1.4.4/bun
AUDIT_SUBJECTS=8 AUDIT_RUN=funded "$bun_path" --no-env-file .diagnostic/native.mjs ./.diagnostic/ledger.test.ts
AUDIT_SUBJECTS=8 AUDIT_RUN=mature AUDIT_ANALYZE=1 "$bun_path" --no-env-file .diagnostic/native.mjs ./.diagnostic/ledger.test.ts
"$bun_path" --no-env-file .diagnostic/native.mjs ./.diagnostic/equivalence.test.ts
"$bun_path" --no-env-file .diagnostic/native.mjs ./tests/integration/capacity-stream-completion.test.ts
```

若要在该独立检出复现改动前失败，可临时将包内 baseline.ts 放在 scripts/capacity-stream-completion.ts，运行最后一行，此时现有测试应在读取预算失败。用 candidate.ts 还原后再跑最后一行。测试读取真实 PostgreSQL 事务统计，需要默认开启 track_counts。新机器上的绝对时间、自动分析时机和随机 ID 会改变，原始计划、实际访问量、金钱和证据对应关系可分别核对。

本包只列入脚本、代码、脱敏计划、日志、摘要与补丁。没有打包本地环境、数据库、证书或私钥。
