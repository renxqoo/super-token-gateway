CREATE TABLE compact.signer (public_key text PRIMARY KEY);
CREATE TABLE compact.evidence (
 event_id uuid PRIMARY KEY,
 attempt_id uuid NOT NULL REFERENCES compact.permit(attempt_id),
 revision smallint NOT NULL CHECK(revision BETWEEN 1 AND 16),
 signer text NOT NULL REFERENCES compact.signer,
 signed_body jsonb NOT NULL CHECK (
   signed_body ?& ARRAY['event_id','attempt_id','signature','source_revision','usage','origin_identity','origin_incarnation','origin_session_id']
   AND event_id=(signed_body->>'event_id')::uuid AND attempt_id=(signed_body->>'attempt_id')::uuid AND revision=(signed_body->>'source_revision')::smallint
 ), UNIQUE(attempt_id,revision)
);
ALTER TABLE compact.outbox ADD FOREIGN KEY(event_id) REFERENCES compact.evidence(event_id);

CREATE FUNCTION compact.settle_with_evidence(
  rs uuid[], ats uuid[], firsts uuid[], finals uuid[], ins int[], cached int[], outs int[], reasoning int[],
  signer_key text, final_revisions smallint[], final_bodies text[], event_ids uuid[], event_requests uuid[], event_revisions smallint[]
) RETURNS int LANGUAGE plpgsql SET search_path=pg_catalog,compact AS $fn$
DECLARE n integer;
BEGIN
  IF cardinality(rs) IS DISTINCT FROM cardinality(final_revisions) OR cardinality(rs) IS DISTINCT FROM cardinality(final_bodies)
    OR cardinality(event_ids) IS DISTINCT FROM cardinality(event_requests)
    OR cardinality(event_ids) IS DISTINCT FROM cardinality(event_revisions)
    THEN RAISE EXCEPTION 'invalid evidence batch'; END IF;
  n := cardinality(compact.settle_batch(rs,ats,firsts,finals,ins,cached,outs,reasoning));
  IF n IS DISTINCT FROM cardinality(rs) THEN RAISE EXCEPTION 'terminal identity already applied'; END IF;
  INSERT INTO compact.evidence(event_id,attempt_id,revision,signer,signed_body)
    SELECT i.id,i.attempt,i.rev,signer_key,i.body::jsonb
      FROM unnest(finals,ats,final_revisions,final_bodies) i(id,attempt,rev,body);
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n IS DISTINCT FROM cardinality(rs) THEN RAISE EXCEPTION 'incomplete terminal evidence'; END IF;
  INSERT INTO compact.outbox(event_id,request_id,revision)
    SELECT i.id,i.request,i.rev FROM unnest(event_ids,event_requests,event_revisions) i(id,request,rev);
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n IS DISTINCT FROM cardinality(event_ids) THEN RAISE EXCEPTION 'incomplete terminal outbox'; END IF;
  RETURN cardinality(rs);
END $fn$;
