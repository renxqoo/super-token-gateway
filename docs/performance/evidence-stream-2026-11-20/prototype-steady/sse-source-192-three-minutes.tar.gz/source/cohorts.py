import csv
import json
import math
import sys
from contextlib import ExitStack
from pathlib import Path

from recompute import recompute


def calculate(prefix, seconds):
    def path(ext):
        return Path(str(prefix) + ext)

    data = json.loads(path(".json").read_text())
    cfg, ac, hooks = data["configuration"], data["accounting"], data["plugin"]
    assert seconds > 0 and cfg["seconds"] % seconds == 0
    start = ac["startEpochMs"]
    size = cfg["rate"] * seconds
    raw = recompute(prefix)
    cleanup = json.loads(path(".cleanup.json").read_text())
    groups = [dict(offers=0, sent=0, shed=0, http=0, withUpstreamReceipt=0, db=0,
                   revisions=0, ackedRevisions=0, ackedRequests=0, complete=0,
                   ownInWindow=0, finishedLater=0, olderCompletionsInWindow=0,
                   earlierCohortsUnfinishedAtStart=0, fromThisCohortPendingAtEnd=0,
                   maxCompletion=0, latencies=[], firstContent=[], deadlineMisses=0)
              for _ in range(cfg["seconds"] // seconds)]
    marks = [start + i * seconds * 1000 for i in range(len(groups)+1)]
    with ExitStack() as stack:
        def reader(ext):
            return csv.DictReader(stack.enter_context(path(ext).open()), delimiter="\t")

        events = reader(".events.tsv")
        r = next(events, None)
        for seq, (x, h) in enumerate(zip(reader(".identities.tsv"), reader(".http.tsv"))):
            assert int(x["seq"]) == int(h["seq"]) == seq
            uid = x["request_id"]
            assert uid == h["request_id"]
            n = seq // size
            g = groups[n]
            scheduled = float(h["scheduled_epoch_ms"])
            assert marks[n] <= scheduled < marks[n+1]
            g["offers"] += 1
            g["sent"] += bool(h["dispatched_epoch_ms"])
            g["shed"] += h["error"] == "client_inflight_limit"
            g["http"] += h["status"] == "200" and h["valid"] == "1"
            g["db"] += x["db_matched"] == "1"
            g["withUpstreamReceipt"] += int(x["upstream_receive_epoch_ms"] or 0)>0
            count, acked = 0, 0
            while r and r["request_id"] == uid:
                count += 1
                assert r["attempt_id"] == x["attempt_id"] and int(r["revision"]) == count
                acked += bool(r["ack_observed_epoch_ms"])
                r = next(events, None)
            g["revisions"] += count
            g["ackedRevisions"] += acked
            g["ackedRequests"] += count >= 2 and count == acked
            completion = int(x["complete_epoch_ms"] or 0)
            if not completion:
                continue
            g["complete"] += 1
            g["maxCompletion"] = max(g["maxCompletion"],completion)
            latency = completion - scheduled
            g["latencies"].append(latency)
            g["firstContent"].append(int(h["first_content_epoch_ms"]) - scheduled)
            g["deadlineMisses"] += latency > 5000
            if completion < marks[n+1]:
                g["ownInWindow"] += 1
            else:
                g["finishedLater"] += 1
                g["fromThisCohortPendingAtEnd"] += 1
                actual = (completion - start) // (seconds*1000)
                if actual < len(groups):
                    groups[actual]["olderCompletionsInWindow"] += 1
                for transition in range(n+1,min(actual+1,len(groups))):
                    groups[transition]["earlierCohortsUnfinishedAtStart"] += 1
        assert r is None
    observed = ac["complete"]
    all_ok = (ac["offers"] == cfg["count"] == raw["offers"]
              and cfg["count"]-ac["loadShed"] == ac["arrived"] == ac["httpValid"] == observed
              and ac["provider"] == {"requests":observed,"duplicates":0}
              and ac["dbRows"] == ac["dbMatched"] == ac["doubleAck"] == observed
              and ac["eventCount"] == ac["ackRows"] == hooks["signed"] == hooks["verified"] == hooks["independentConsumerVerified"]
              and ac["orderFailures"] == ac["loadShed"] and not data["errors"]
              and all(ac[k]==0 for k in ("badWallets","badCells","invalidAuth","duplicateObs"))
              and cleanup == {"fixture":{"processes":[],"directories":[],"ports":[],"timers":0},"childrenExitCodes":[0,0,0],"active":0})
    def percentile(values):
        return sorted(values)[math.ceil(.99*len(values))-1] if values else None
    for n,g in enumerate(groups):
        g["kind"] = "warmup" if cfg["seconds"] == 180 and n == 0 else "measurement"
        g["startEpochMs"],g["endEpochMs"] = marks[n:n+2]
        g["completeRps"] = g["ownInWindow"]/seconds
        end = max(g["endEpochMs"],g["maxCompletion"])
        if n+1 == len(groups):
            end = max(end,marks[-1]+ac["drainMs"])
        g["elapsedIncludingDrainMs"] = end - marks[n]
        g["effectiveRpsIncludingDrain"] = 1000*g["complete"]/g["elapsedIncludingDrainMs"]
        p99 = percentile(g.pop("latencies"))
        first = percentile(g.pop("firstContent"))
        g["p99Ms"], g["firstContentP99Ms"] = (round(p99,3) if p99 is not None else None),(round(first,3) if first is not None else None)
        g["strictPass"] = (all_ok and g["offers"]==g["sent"]==g["http"]==g["withUpstreamReceipt"]==g["db"]==g["ackedRequests"]==g["complete"]==size
                           and g["revisions"]==g["ackedRevisions"] and g["shed"]==g["deadlineMisses"]==0
                           and g["ownInWindow"]>=seconds*3000 and 1000*g["complete"]>=3000*g["elapsedIncludingDrainMs"]
                           and p99 is not None and p99<=1500)
    assert sum(g["offers"] for g in groups)==raw["offers"]
    assert sum(g["revisions"] for g in groups)==raw["allEvidence"]
    assert sum(g["complete"] for g in groups)==raw["intersection"]
    assert sum(g["ownInWindow"]+g["olderCompletionsInWindow"] for g in groups)==raw["within"]
    return {"sourceSeconds":cfg["seconds"],"windowSeconds":seconds,"allDispatchedMatchedAndClean":all_ok,
            "twoContinuousWarmWindowsPass":(cfg["seconds"]==180 and seconds==60 and all(g["strictPass"] for g in groups[1:])),
            "cohorts":groups}


if __name__=="__main__":
    report = calculate(Path(sys.argv[1]),int(sys.argv[2]))
    print(json.dumps(report,indent=2))
    if "--require-warm" in sys.argv and not report["twoContinuousWarmWindowsPass"]:
        sys.exit(1)
