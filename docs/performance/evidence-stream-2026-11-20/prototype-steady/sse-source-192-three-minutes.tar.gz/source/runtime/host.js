// @bun
var __defProp = Object.defineProperty;
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/classic/iso.js
var exports_iso = {};
__export(exports_iso, {
  ZodISODate: () => ZodISODate,
  ZodISODateTime: () => ZodISODateTime,
  ZodISODuration: () => ZodISODuration,
  ZodISOTime: () => ZodISOTime,
  date: () => date2,
  datetime: () => datetime2,
  duration: () => duration2,
  time: () => time2
});

// packages/plugin-host/src/supervisor.ts
import { spawn } from "child_process";
import { isAbsolute } from "path";

// packages/plugin-host/src/executable.ts
import {
  closeSync,
  constants,
  fstatSync,
  lstatSync,
  openSync,
  readSync,
  realpathSync
} from "fs";
import { chmod, link, mkdir, open, unlink } from "fs/promises";
import { basename, dirname, join } from "path";
function bytes(path) {
  const descriptor = openSync(path, constants.O_RDONLY | constants.O_NONBLOCK);
  try {
    const state = fstatSync(descriptor);
    if (!state.isFile() || state.size < 1 || state.size > 64 << 20)
      throw new Error("PLUGIN_EXECUTABLE_INVALID");
    const result = new Uint8Array(state.size);
    let at = 0;
    while (at < result.length) {
      const count = readSync(descriptor, result, at, result.length - at, at);
      if (count === 0)
        throw new Error("PLUGIN_EXECUTABLE_CHANGED");
      at += count;
    }
    if (readSync(descriptor, new Uint8Array(1), 0, 1, at) !== 0)
      throw new Error("PLUGIN_EXECUTABLE_CHANGED");
    return result;
  } finally {
    closeSync(descriptor);
  }
}
function pluginExecutableDigest(path) {
  return new Bun.CryptoHasher("sha256").update(bytes(path)).digest("hex");
}
function published(path, digest) {
  const actual = join(realpathSync(dirname(path)), basename(path));
  const state = lstatSync(actual);
  if (basename(actual) !== "plugin-host" || basename(dirname(actual)) !== digest || !state.isFile() || (state.mode & 146) !== 0 || pluginExecutableDigest(actual) !== digest)
    throw new Error("PLUGIN_EXECUTABLE_CHANGED");
  return { executable: actual, digest };
}
function declaredExecutable(path) {
  const digest = basename(dirname(path));
  if (basename(path) === "plugin-host" && /^[a-f0-9]{64}$/.test(digest))
    return published(path, digest);
}
function resolvePluginExecutable(source) {
  const declared = declaredExecutable(source);
  if (declared)
    return declared;
  const actual = realpathSync(source);
  const canonical = declaredExecutable(actual);
  if (canonical)
    return canonical;
  const digest = pluginExecutableDigest(actual);
  const path = join(dirname(actual), "executables", digest, "plugin-host");
  return published(path, digest);
}
async function publishPluginExecutable(source) {
  const declared = declaredExecutable(source);
  if (declared)
    return declared;
  const actual = realpathSync(source);
  const canonical = declaredExecutable(actual);
  if (canonical)
    return canonical;
  const data = bytes(actual);
  const digest = new Bun.CryptoHasher("sha256").update(data).digest("hex");
  const directory = join(dirname(actual), "executables", digest);
  await mkdir(directory, { recursive: true, mode: 493 });
  const target = join(directory, "plugin-host");
  try {
    return published(target, digest);
  } catch (error) {
    if (error.code !== "ENOENT")
      throw error;
  }
  const temporary = join(directory, `staging-${process.pid}-${crypto.randomUUID()}`);
  const file = await open(temporary, "wx", 320);
  try {
    try {
      await file.writeFile(data);
      await file.sync();
    } finally {
      await file.close();
    }
    await chmod(temporary, 365);
    try {
      await link(temporary, target);
    } catch (error) {
      if (error.code !== "EEXIST")
        throw error;
    }
    return published(target, digest);
  } finally {
    await unlink(temporary);
  }
}

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/util.js
function getEnumValues(entries) {
  const numericValues = Object.values(entries).filter((v) => typeof v === "number");
  const values = Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
  return values;
}
function joinValues(array, separator = "|") {
  return array.map((val) => stringifyPrimitive(val)).join(separator);
}
function jsonStringifyReplacer(_, value) {
  if (typeof value === "bigint")
    return value.toString();
  return value;
}

class Cached {
  constructor(getter) {
    this._getter = getter;
    this._value = undefined;
  }
  get value() {
    const getter = this._getter;
    if (getter !== undefined) {
      this._value = getter();
      this._getter = undefined;
    }
    return this._value;
  }
}
function cached(getter) {
  return new Cached(getter);
}
function nullish(input) {
  return input === null || input === undefined;
}
function cleanRegex(source) {
  const start = source.startsWith("^") ? 1 : 0;
  const end = source.endsWith("$") ? source.length - 1 : source.length;
  return source.slice(start, end);
}
function floatSafeRemainder(val, step) {
  const ratio = val / step;
  const roundedRatio = Math.round(ratio);
  const tolerance = 4 * Number.EPSILON * Math.max(Math.abs(ratio), 1);
  if (Math.abs(ratio - roundedRatio) < tolerance)
    return 0;
  return ratio - roundedRatio;
}
function assignProp(target, prop, value) {
  Object.defineProperty(target, prop, {
    value,
    writable: true,
    enumerable: true,
    configurable: true
  });
}
function rawShape(def) {
  const desc = Object.getOwnPropertyDescriptor(def, "shape");
  return desc?.get ? desc.get.raw : desc?.value;
}
function sourceShape(schema) {
  return rawShape(schema._zod.def) ?? schema._zod.def.shape;
}
function deferProp(target, key, getter) {
  Object.defineProperty(target, key, {
    get() {
      const value = getter();
      assignProp(this, key, value);
      return value;
    },
    enumerable: true,
    configurable: true
  });
}
function putProp(target, key, value) {
  if (key in target)
    assignProp(target, key, value);
  else
    target[key] = value;
}
function mirrorShape(target, source, keys, wrap) {
  const raw = sourceShape(source);
  for (const key of keys) {
    const desc = Object.getOwnPropertyDescriptor(raw, key);
    if (!desc.enumerable)
      continue;
    if (desc.get) {
      deferProp(target, key, () => {
        const value = source._zod.def.shape[key];
        return wrap ? wrap(value, key) : value;
      });
    } else
      putProp(target, key, wrap ? wrap(desc.value, key) : desc.value);
  }
}
function mirrorProps(target, source) {
  for (const key of Reflect.ownKeys(source)) {
    const desc = Object.getOwnPropertyDescriptor(source, key);
    if (!desc.enumerable)
      continue;
    if (desc.get)
      deferProp(target, key, () => source[key]);
    else
      putProp(target, key, desc.value);
  }
}
function mergeDefs(...defs) {
  const mergedDescriptors = {};
  for (const def of defs) {
    const descriptors = Object.getOwnPropertyDescriptors(def);
    Object.assign(mergedDescriptors, descriptors);
  }
  return Object.defineProperties({}, mergedDescriptors);
}
function esc(str) {
  return JSON.stringify(str);
}
function slugify(input) {
  return input.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
function isObject(data) {
  return typeof data === "object" && data !== null && !Array.isArray(data);
}
var allowsEval = /* @__PURE__ */ cached(() => {
  if (globalConfig.jitless) {
    return false;
  }
  if (typeof navigator !== "undefined" && navigator?.userAgent?.includes("Cloudflare")) {
    return false;
  }
  try {
    const F = Function;
    new F("");
    return true;
  } catch (_) {
    return false;
  }
});
function isPlainObject(o) {
  if (isObject(o) === false)
    return false;
  const ctor = o.constructor;
  if (ctor === undefined)
    return true;
  if (typeof ctor !== "function")
    return true;
  const prot = ctor.prototype;
  if (isObject(prot) === false)
    return false;
  if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) {
    return false;
  }
  return true;
}
function shallowClone(o) {
  if (isPlainObject(o))
    return { ...o };
  if (Array.isArray(o))
    return [...o];
  if (o instanceof Map)
    return new Map(o);
  if (o instanceof Set)
    return new Set(o);
  return o;
}
var propertyKeyTypes = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone(inst, def, params) {
  const cl = new inst._zod.constr(def ?? inst._zod.def);
  if (!def || params?.parent)
    cl._zod.parent = inst;
  return cl;
}
function normalizeParams(_params) {
  const params = _params;
  if (!params)
    return {};
  if (typeof params === "string")
    return { error: () => params };
  if (params?.message !== undefined) {
    if (params?.error !== undefined)
      throw new Error("Cannot specify both `message` and `error` params");
    params.error = params.message;
  }
  delete params.message;
  if (typeof params.error === "string")
    return { ...params, error: () => params.error };
  return params;
}
function stringifyPrimitive(value) {
  if (typeof value === "bigint")
    return value.toString() + "n";
  if (typeof value === "string")
    return `"${value}"`;
  return `${value}`;
}
function optionalKeys(shape) {
  return Object.keys(shape).filter((k) => {
    return shape[k]._zod.optin !== undefined && shape[k]._zod.optout === "optional";
  });
}
var NUMBER_FORMAT_RANGES = /* @__PURE__ */ (() => ({
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-340282346638528860000000000000000000000, 340282346638528860000000000000000000000],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}))();
var BIGINT_FORMAT_RANGES = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function pick(schema, mask) {
  const currDef = schema._zod.def;
  const checks = currDef.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  }
  const newShape = {};
  mirrorShape(newShape, schema, maskedKeys(schema, mask));
  return clone(schema, mergeDefs(currDef, { shape: newShape, checks: [] }));
}
function maskedKeys(schema, mask) {
  const raw = sourceShape(schema);
  const keys = [];
  for (const key of Reflect.ownKeys(mask)) {
    if (!Object.getOwnPropertyDescriptor(raw, key)?.enumerable) {
      throw new Error(`Unrecognized key: "${String(key)}"`);
    }
    if (mask[key])
      keys.push(key);
  }
  return keys;
}
function omit(schema, mask) {
  const currDef = schema._zod.def;
  const checks = currDef.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  }
  const omitted = new Set(maskedKeys(schema, mask));
  const newShape = {};
  mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)).filter((key) => !omitted.has(key)));
  return clone(schema, mergeDefs(currDef, { shape: newShape, checks: [] }));
}
function extend(schema, shape) {
  if (!isPlainObject(shape)) {
    throw new Error("Invalid input to extend: expected a plain object");
  }
  const checks = schema._zod.def.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    const existingShape = sourceShape(schema);
    for (const key of Reflect.ownKeys(shape)) {
      if (Object.getOwnPropertyDescriptor(existingShape, key) !== undefined) {
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
      }
    }
  }
  return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
}
function extended(schema, shape) {
  const newShape = {};
  mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)));
  mirrorProps(newShape, shape);
  return newShape;
}
function safeExtend(schema, shape) {
  if (!isPlainObject(shape)) {
    throw new Error("Invalid input to safeExtend: expected a plain object");
  }
  return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
}
function merge(a, b) {
  if (!b?._zod?.def) {
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  }
  if (a._zod.def.checks?.length) {
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  }
  const newShape = {};
  mirrorShape(newShape, a, Reflect.ownKeys(sourceShape(a)));
  mirrorShape(newShape, b, Reflect.ownKeys(sourceShape(b)));
  const def = mergeDefs(a._zod.def, {
    shape: newShape,
    get catchall() {
      return b._zod.def.catchall;
    },
    checks: b._zod.def.checks ?? []
  });
  return clone(a, def);
}
function partial(Class, schema, mask, name = "partial") {
  const currDef = schema._zod.def;
  const checks = currDef.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    throw new Error(`.${name}() cannot be used on object schemas containing refinements`);
  }
  const selected = mask ? new Set(maskedKeys(schema, mask)) : undefined;
  const newShape = {};
  mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), Class && ((value, key) => selected && !selected.has(key) ? value : new Class({ type: "optional", innerType: value })));
  return clone(schema, mergeDefs(schema._zod.def, { shape: newShape, checks: [] }));
}
function required(Class, schema, mask) {
  const selected = mask ? new Set(maskedKeys(schema, mask)) : undefined;
  const newShape = {};
  mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), (value, key) => selected && !selected.has(key) ? value : new Class({ type: "nonoptional", innerType: value }));
  return clone(schema, mergeDefs(schema._zod.def, { shape: newShape }));
}
function aborted(x, startIndex = 0) {
  if (x.aborted === true)
    return true;
  for (let i = startIndex;i < x.issues.length; i++) {
    if (x.issues[i]?.continue !== true) {
      return true;
    }
  }
  return false;
}
function explicitlyAborted(x, startIndex = 0) {
  if (x.aborted === true)
    return true;
  for (let i = startIndex;i < x.issues.length; i++) {
    if (x.issues[i]?.continue === false) {
      return true;
    }
  }
  return false;
}
function prefixIssues(path, issues) {
  return issues.map((iss) => {
    var _a;
    (_a = iss).path ?? (_a.path = []);
    iss.path.unshift(path);
    return iss;
  });
}
function unwrapMessage(message) {
  return typeof message === "string" ? message : message?.message;
}
function sizeCaps(defChecks) {
  const caps = [];
  for (const ch of defChecks ?? []) {
    const d = ch._zod.def;
    if (!/_(length|size)$|_equals$/.test(d.check))
      break;
    const max = d.maximum ?? d.length ?? d.size;
    if (max >= 0)
      caps.push([max, ch]);
  }
  return caps;
}
function attachSchema(issues, start, inst) {
  var _a;
  for (let i = start;i < issues.length; i++) {
    (_a = issues[i]).schema ?? (_a.schema = inst);
  }
}
function finalizeIssue(iss, ctx, config) {
  var _a;
  const traits = iss.inst?._zod?.traits;
  if (traits?.has("$ZodType")) {
    if (traits.has("$ZodCheck"))
      (_a = iss).schema ?? (_a.schema = iss.inst);
    else
      iss.schema = iss.inst;
  }
  const schemaError = iss.schema !== iss.inst ? iss.schema?._zod.def?.error : undefined;
  const message = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(schemaError?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
  const full = {};
  for (const k of Object.keys(iss)) {
    if (k === "inst" || k === "schema" || k === "continue" || k === "input" || k === "__proto__")
      continue;
    full[k] = iss[k];
  }
  full.path ?? (full.path = []);
  full.message = message;
  if (ctx?.reportInput) {
    full.input = iss.input;
  }
  return full;
}
var highSurrogate = /[\uD800-\uDBFF]/;
function codePointLength(str) {
  const units = str.length;
  if (!highSurrogate.test(str))
    return units;
  let count = units;
  for (let i = 0;i < units - 1; i++) {
    if ((str.charCodeAt(i) & 64512) === 55296 && (str.charCodeAt(i + 1) & 64512) === 56320) {
      count--;
      i++;
    }
  }
  return count;
}
function getLengthableOrigin(input) {
  if (Array.isArray(input))
    return "array";
  if (typeof input === "string")
    return "string";
  return "unknown";
}
function parsedType(data) {
  const t = typeof data;
  switch (t) {
    case "number": {
      return Number.isNaN(data) ? "nan" : "number";
    }
    case "object": {
      if (data === null) {
        return "null";
      }
      if (Array.isArray(data)) {
        return "array";
      }
      const obj = data;
      if (obj && Object.getPrototypeOf(obj) !== Object.prototype && "constructor" in obj && obj.constructor) {
        return obj.constructor.name;
      }
    }
  }
  return t;
}
function issue(...args) {
  const [iss, input, inst] = args;
  if (typeof iss === "string") {
    return {
      message: iss,
      code: "custom",
      input,
      inst
    };
  }
  return { ...iss };
}
function members(proto, table) {
  for (const key in table) {
    const desc = Object.getOwnPropertyDescriptor(table, key);
    if (desc.get)
      Object.defineProperty(proto, key, { ...desc, enumerable: false });
    else
      defineBound(proto, key, desc.value);
  }
}
function own(inst, key, value, enumerable = true) {
  Object.defineProperty(inst, key, { configurable: true, writable: true, enumerable, value });
  return value;
}
function hide(inst, key, value) {
  return own(inst, key, value, false);
}
function derived(computes, table) {
  for (const key in computes) {
    const compute = computes[key];
    Object.defineProperty(table, key, {
      configurable: true,
      enumerable: true,
      get() {
        return own(this, key, compute(this));
      },
      set(value) {
        own(this, key, value);
      }
    });
  }
  return table;
}
function defineBound(proto, key, fn) {
  Object.defineProperty(proto, key, {
    configurable: true,
    get() {
      return this == null ? fn : own(this, key, fn.bind(this));
    },
    set(value) {
      own(this, key, value);
    }
  });
}
function claim(inst, sentinel) {
  const proto = Object.getPrototypeOf(inst);
  return sentinel in proto ? undefined : proto;
}
var installing;
var broke = false;
var breaker = {
  configurable: true,
  get() {
    broke = true;
    return;
  }
};
function defineLazyInternal(inst, key, compute) {
  const proto = Object.getPrototypeOf(inst._zod);
  if (key in proto && installing !== inst._zod) {
    installing = undefined;
    return;
  }
  installing = inst._zod;
  Object.defineProperty(proto, key, {
    configurable: true,
    get() {
      Object.defineProperty(this, key, breaker);
      const outer = broke;
      broke = false;
      try {
        const value = compute(this);
        if (broke)
          delete this[key];
        else
          Object.defineProperty(this, key, { configurable: true, writable: true, value });
        broke = broke || outer;
        return value;
      } catch (err) {
        delete this[key];
        broke = broke || outer;
        throw err;
      }
    },
    set(value) {
      Object.defineProperty(this, key, { configurable: true, writable: true, value });
    }
  });
}
function installLazyProp(inst, key, make, enumerable) {
  const proto = claim(inst, key);
  if (!proto)
    return;
  Object.defineProperty(proto, key, {
    configurable: true,
    get() {
      const desc = { configurable: true, writable: true, enumerable, value: undefined };
      Object.defineProperty(this, key, desc);
      desc.value = make(this);
      Object.defineProperty(this, key, desc);
      return desc.value;
    },
    set(value) {
      Object.defineProperty(this, key, { configurable: true, writable: true, enumerable, value });
    }
  });
}
var CONSTANT_CATCH = "~constantCatch";
function constantCatch(value) {
  const fn = () => value;
  fn[CONSTANT_CATCH] = true;
  return fn;
}

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/core.js
var _a;
var NEVER = /* @__PURE__ */ Object.freeze({
  status: "aborted"
});
var _zodDesc = { value: undefined, enumerable: false };
var _E = "captureStackTrace" in Error ? Error : null;
function newError(Definition) {
  const E = _E;
  if (E) {
    const saved = E.stackTraceLimit;
    if (typeof saved === "number") {
      try {
        E.stackTraceLimit = 0;
      } catch {
        _E = null;
        return new Definition;
      }
      try {
        return new Definition;
      } finally {
        E.stackTraceLimit = saved;
      }
    }
  }
  return new Definition;
}
function $constructor(name, initializer, proto, params) {
  const zodProto = {};
  function Internals(def) {
    this.def = def;
    this.constr = _;
    this.traits = new Set;
  }
  Internals.prototype = zodProto;
  const protoMembers = proto;
  const initialized = protoMembers && new WeakSet;
  function init(inst, def) {
    if (!inst._zod) {
      _zodDesc.value = new Internals(def);
      try {
        Object.defineProperty(inst, "_zod", _zodDesc);
      } finally {
        _zodDesc.value = undefined;
      }
    } else if (inst._zod.traits.has(name)) {
      return;
    }
    inst._zod.traits.add(name);
    initializer(inst, def);
    if (initialized) {
      const own = Object.getPrototypeOf(inst);
      const ctorProto = inst._zod.constr.prototype;
      let up = own;
      while (up && up !== ctorProto)
        up = Object.getPrototypeOf(up);
      const target = up ?? own;
      if (!initialized.has(target)) {
        initialized.add(target);
        members(target, protoMembers);
      }
    }
    const proto = _.prototype;
    for (const k in proto) {
      if (!Object.prototype.hasOwnProperty.call(proto, k))
        continue;
      if (!(k in inst)) {
        inst[k] = proto[k].bind(inst);
      }
    }
  }
  const Parent = params?.Parent ?? Object;

  class Definition extends Parent {
  }
  Object.defineProperty(Definition, "name", { value: name });
  function _(def) {
    const inst = params?.Parent ? newError(Definition) : this;
    init(inst, def);
    const deferred = inst._zod.deferred;
    if (deferred) {
      for (const fn of deferred) {
        fn();
      }
      inst._zod.deferred = undefined;
    }
    const pp = globalThis.__zod_globalConfig?.postProcessor;
    if (pp)
      pp(inst);
    return inst;
  }
  Object.defineProperty(_, "init", { value: init });
  Object.defineProperty(_, Symbol.hasInstance, {
    value: (inst) => {
      if (params?.Parent && inst instanceof params.Parent)
        return true;
      return inst?._zod?.traits?.has(name);
    }
  });
  Object.defineProperty(_, "name", { value: name });
  return _;
}
class $ZodAsyncError extends Error {
  constructor() {
    super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
  }
}

class $ZodEncodeError extends Error {
  constructor(name) {
    super(`Encountered unidirectional transform during encode: ${name}`);
    this.name = "ZodEncodeError";
  }
}
(_a = globalThis).__zod_globalConfig ?? (_a.__zod_globalConfig = {});
var globalConfig = globalThis.__zod_globalConfig;
function config(newConfig) {
  if (newConfig)
    Object.assign(globalConfig, newConfig);
  return globalConfig;
}
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/errors.js
function _getMessage() {
  const internals = this._zod;
  internals.message ?? (internals.message = JSON.stringify(internals.def, jsonStringifyReplacer, 2));
  return internals.message;
}
function _setMessage(value) {
  this._zod.message = value;
}
var _messageDesc = {
  get: _getMessage,
  set: _setMessage,
  enumerable: true,
  configurable: true
};
var _issuesDesc = { value: undefined, enumerable: false };
var _installedToString = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
var initializer = (inst, def) => {
  inst.name = "$ZodError";
  _issuesDesc.value = def;
  Object.defineProperty(inst, "issues", _issuesDesc);
  _issuesDesc.value = undefined;
  Object.defineProperty(inst, "message", _messageDesc);
  const proto = Object.getPrototypeOf(inst);
  if (!_installedToString.has(proto)) {
    _installedToString.add(proto);
    Object.defineProperty(proto, "toString", {
      configurable: true,
      enumerable: false,
      get() {
        const value = () => this.message;
        Object.defineProperty(this, "toString", { value, configurable: true, writable: true });
        return value;
      },
      set(value) {
        Object.defineProperty(this, "toString", { value, configurable: true, writable: true });
      }
    });
  }
};
var $ZodError = $constructor("$ZodError", initializer);
var $ZodRealError = $constructor("$ZodError", initializer, undefined, {
  Parent: Error
});
function node(obj, key, make) {
  if (!Object.prototype.hasOwnProperty.call(obj, key)) {
    if (key === "__proto__") {
      Object.defineProperty(obj, key, { value: make(), writable: true, enumerable: true, configurable: true });
    } else {
      obj[key] = make();
    }
  }
  return obj[key];
}
function flattenError(error, mapper = (issue) => issue.message) {
  const fieldErrors = {};
  const formErrors = [];
  for (const sub of error.issues) {
    if (sub.path.length > 0) {
      node(fieldErrors, sub.path[0], () => []).push(mapper(sub));
    } else {
      formErrors.push(mapper(sub));
    }
  }
  return { formErrors, fieldErrors };
}
function formatError(error, mapper = (issue) => issue.message) {
  const fieldErrors = { _errors: [] };
  const processError = (error, path = []) => {
    for (const issue of error.issues) {
      if (issue.code === "invalid_union" && issue.errors.length) {
        issue.errors.map((issues) => processError({ issues }, [...path, ...issue.path]));
      } else if (issue.code === "invalid_key") {
        processError({ issues: issue.issues }, [...path, ...issue.path]);
      } else if (issue.code === "invalid_element") {
        processError({ issues: issue.issues }, [...path, ...issue.path]);
      } else {
        const fullpath = [...path, ...issue.path];
        if (fullpath.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < fullpath.length) {
            const el = fullpath[i];
            const terminal = i === fullpath.length - 1;
            if (el === "_errors") {
              if (terminal)
                curr._errors.push(mapper(issue));
              i++;
              continue;
            }
            if (!Object.prototype.hasOwnProperty.call(curr, el)) {
              Object.defineProperty(curr, el, {
                value: { _errors: [] },
                enumerable: true,
                writable: true,
                configurable: true
              });
            }
            const node = curr[el];
            if (terminal) {
              node._errors.push(mapper(issue));
            }
            curr = node;
            i++;
          }
        }
      }
    }
  };
  processError(error);
  return fieldErrors;
}

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/parse.js
function finalizeParams(callee, params) {
  return { callee: params?.callee ?? callee, Err: params?.Err };
}
var _parse = (_Err) => {
  const fn = (schema, value, _ctx, _params) => {
    const ctx = _ctx ? { ..._ctx, async: false } : { async: false };
    const result = schema._zod.run({ value, issues: [] }, ctx);
    if (result instanceof Promise) {
      throw new $ZodAsyncError;
    }
    if (result.issues.length) {
      const e = new (_params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
      captureStackTrace(e, _params?.callee ?? fn);
      throw e;
    }
    return result.value;
  };
  return fn;
};
var _parseAsync = (_Err) => {
  const fn = async (schema, value, _ctx, params) => {
    const ctx = _ctx ? { ..._ctx, async: true } : { async: true };
    let result = schema._zod.run({ value, issues: [] }, ctx);
    if (result instanceof Promise)
      result = await result;
    if (result.issues.length) {
      const e = new (params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
      captureStackTrace(e, params?.callee ?? fn);
      throw e;
    }
    return result.value;
  };
  return fn;
};
var _safeParse = (_Err) => (schema, value, _ctx) => {
  const ctx = _ctx ? { ..._ctx, async: false } : { async: false };
  const result = schema._zod.run({ value, issues: [] }, ctx);
  if (result instanceof Promise) {
    throw new $ZodAsyncError;
  }
  return result.issues.length ? failure(_Err, result.issues, ctx) : { success: true, data: result.value };
};
function failure(Err, issues, ctx) {
  let error;
  return {
    success: false,
    get error() {
      if (!error) {
        error = new Err(issues.map((iss) => finalizeIssue(iss, ctx, config())));
        issues = undefined;
        ctx = undefined;
      }
      return error;
    },
    set error(e) {
      error = e;
      issues = undefined;
      ctx = undefined;
    }
  };
}
var _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
  const ctx = _ctx ? { ..._ctx, async: true } : { async: true };
  let result = schema._zod.run({ value, issues: [] }, ctx);
  if (result instanceof Promise)
    result = await result;
  return result.issues.length ? failure(_Err, result.issues, ctx) : { success: true, data: result.value };
};
var COMPILE_INVALID = /* @__PURE__ */ Symbol.for("zod.compile.invalid");
var COMPILE_FALLBACK = /* @__PURE__ */ Symbol.for("zod.compile.fallback");
var validate = (schema, value, _ctx) => {
  const validator = schema._zod.bag.validator;
  if (validator !== undefined) {
    if (validator(value) !== COMPILE_INVALID)
      return true;
    if (validator.definite === true && _ctx === undefined)
      return false;
  }
  return validateFallback(schema, value, _ctx);
};
function validateFallback(schema, value, _ctx) {
  const ctx = _ctx ? { ..._ctx, async: false, abortEarly: true } : { async: false, abortEarly: true };
  const fallbackRun = schema._zod.bag.fallbackRun;
  let result;
  if (fallbackRun) {
    ctx[COMPILE_FALLBACK] = true;
    result = fallbackRun({ value, issues: [] }, ctx);
  } else {
    result = schema._zod.run({ value, issues: [] }, ctx);
  }
  if (result instanceof Promise) {
    throw new $ZodAsyncError;
  }
  return result.issues.length === 0;
}
var validateAsync = async (schema, value, _ctx) => {
  const ctx = _ctx ? { ..._ctx, async: true, abortEarly: true } : { async: true, abortEarly: true };
  let result = schema._zod.run({ value, issues: [] }, ctx);
  if (result instanceof Promise)
    result = await result;
  return result.issues.length === 0;
};
var _encode = (_Err) => {
  const parse = _parse(_Err);
  const fn = (schema, value, _ctx, _params) => {
    const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
    return parse(schema, value, ctx, finalizeParams(fn, _params));
  };
  return fn;
};
var _decode = (_Err) => {
  const parse = _parse(_Err);
  const fn = (schema, value, _ctx, _params) => {
    return parse(schema, value, _ctx, finalizeParams(fn, _params));
  };
  return fn;
};
var _encodeAsync = (_Err) => {
  const parseAsync = _parseAsync(_Err);
  const fn = async (schema, value, _ctx, _params) => {
    const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
    return await parseAsync(schema, value, ctx, finalizeParams(fn, _params));
  };
  return fn;
};
var _decodeAsync = (_Err) => {
  const parseAsync = _parseAsync(_Err);
  const fn = async (schema, value, _ctx, _params) => {
    return await parseAsync(schema, value, _ctx, finalizeParams(fn, _params));
  };
  return fn;
};
var _safeEncode = (_Err) => (schema, value, _ctx) => {
  const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
  return _safeParse(_Err)(schema, value, ctx);
};
var _safeDecode = (_Err) => (schema, value, _ctx) => {
  return _safeParse(_Err)(schema, value, _ctx);
};
var _safeEncodeAsync = (_Err) => async (schema, value, _ctx) => {
  const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
  return _safeParseAsync(_Err)(schema, value, ctx);
};
var _safeDecodeAsync = (_Err) => async (schema, value, _ctx) => {
  return _safeParseAsync(_Err)(schema, value, _ctx);
};
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/regexes.js
var cuid = /^[cC][0-9a-z]{6,}$/;
var cuid2 = /^[0-9a-z]+$/;
var ulid = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/;
var xid = /^[0-9a-vA-V]{20}$/;
var ksuid = /^[A-Za-z0-9]{27}$/;
var nanoid = /^[a-zA-Z0-9_-]{21}$/;
function nanoidOfLength(length) {
  return new RegExp(`^[a-zA-Z0-9_-]{${length}}$`);
}
var duration = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
var guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
var uuid = (version) => {
  if (!version)
    return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
  return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
};
var email = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
var _emoji = `^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$`;
function emoji() {
  return new RegExp(_emoji, "u");
}
var ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
var cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
var cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/;
var base64url = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/;
var httpProtocol = /^https?$/;
var e164 = /^\+[1-9]\d{6,14}$/;
var dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
function anchor(source) {
  return new RegExp(`^${source}$`);
}
var date = /* @__PURE__ */ anchor(dateSource);
function timeSource(args) {
  const hhmm = `(?:[01]\\d|2[0-3]):[0-5]\\d`;
  const regex = typeof args.precision === "number" ? args.precision === -1 ? `${hhmm}` : args.precision === 0 ? `${hhmm}:[0-5]\\d` : `${hhmm}:[0-5]\\d\\.\\d{${args.precision}}` : args.seconds ? `${hhmm}:[0-5]\\d(?:\\.\\d+)?` : `${hhmm}(?::[0-5]\\d(?:\\.\\d+)?)?`;
  return regex;
}
function time(args) {
  return new RegExp(`^${timeSource(args)}$`);
}
function datetime(args) {
  const opts = ["Z"];
  if (args.offset)
    opts.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);
  const qualified = `${timeSource({ precision: args.precision, seconds: true })}(?:${opts.join("|")})`;
  const timeRegex = args.local ? `${qualified}|${timeSource({ precision: args.precision })}` : qualified;
  return new RegExp(`^${dateSource}T(?:${timeRegex})$`);
}
var anyString = /^[\s\S]{0,}$/;
var integer = /^-?\d+$/;
var number = /^-?\d+(?:\.\d+)?$/;
var boolean = /^(?:true|false)$/i;
var lowercase = /^[^A-Z]*$/;
var uppercase = /^[^a-z]*$/;

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/checks.js
var $ZodCheck = /* @__PURE__ */ $constructor("$ZodCheck", (inst, def) => {
  var _a;
  inst._zod ?? (inst._zod = {});
  inst._zod.def = def;
  (_a = inst._zod).onattach ?? (_a.onattach = []);
});
var _whenHasLength = (payload) => {
  const val = payload.value;
  return !nullish(val) && val.length !== undefined;
};
var numericOriginMap = {
  number: "number",
  bigint: "bigint",
  object: "date"
};
var $ZodCheckLessThan = /* @__PURE__ */ $constructor("$ZodCheckLessThan", (inst, def) => {
  $ZodCheck.init(inst, def);
  const origin = numericOriginMap[typeof def.value];
  inst._zod.check = (payload) => {
    if (def.inclusive ? payload.value <= def.value : payload.value < def.value) {
      return;
    }
    payload.issues.push({
      origin: numericOriginMap[typeof payload.value] ?? origin,
      code: "too_big",
      maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
      input: payload.value,
      inclusive: def.inclusive,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckGreaterThan = /* @__PURE__ */ $constructor("$ZodCheckGreaterThan", (inst, def) => {
  $ZodCheck.init(inst, def);
  const origin = numericOriginMap[typeof def.value];
  inst._zod.check = (payload) => {
    if (def.inclusive ? payload.value >= def.value : payload.value > def.value) {
      return;
    }
    payload.issues.push({
      origin: numericOriginMap[typeof payload.value] ?? origin,
      code: "too_small",
      minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
      input: payload.value,
      inclusive: def.inclusive,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckMultipleOf = /* @__PURE__ */ $constructor("$ZodCheckMultipleOf", (inst, def) => {
  $ZodCheck.init(inst, def);
  inst._zod.check = (payload) => {
    if (typeof payload.value !== typeof def.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    const isMultiple = typeof payload.value === "bigint" ? def.value !== BigInt(0) && payload.value % def.value === BigInt(0) : floatSafeRemainder(payload.value, def.value) === 0;
    if (isMultiple)
      return;
    payload.issues.push({
      origin: typeof payload.value,
      code: "not_multiple_of",
      divisor: def.value,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckNumberFormat = /* @__PURE__ */ $constructor("$ZodCheckNumberFormat", (inst, def) => {
  $ZodCheck.init(inst, def);
  def.format = def.format || "float64";
  const isInt = def.format?.includes("int");
  const origin = isInt ? "int" : "number";
  const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
  inst._zod.check = (payload) => {
    const input = payload.value;
    if (isInt) {
      if (!Number.isInteger(input)) {
        payload.issues.push({
          expected: origin,
          format: def.format,
          code: "invalid_type",
          continue: false,
          input,
          inst
        });
        return;
      }
      if (!Number.isSafeInteger(input)) {
        if (input > 0) {
          payload.issues.push({
            input,
            code: "too_big",
            maximum: Number.MAX_SAFE_INTEGER,
            note: "Integers must be within the safe integer range.",
            inst,
            origin,
            inclusive: true,
            continue: !def.abort
          });
        } else {
          payload.issues.push({
            input,
            code: "too_small",
            minimum: Number.MIN_SAFE_INTEGER,
            note: "Integers must be within the safe integer range.",
            inst,
            origin,
            inclusive: true,
            continue: !def.abort
          });
        }
        return;
      }
    }
    if (input < minimum) {
      payload.issues.push({
        origin: "number",
        input,
        code: "too_small",
        minimum,
        inclusive: true,
        inst,
        continue: !def.abort
      });
    }
    if (input > maximum) {
      payload.issues.push({
        origin: "number",
        input,
        code: "too_big",
        maximum,
        inclusive: true,
        inst,
        continue: !def.abort
      });
    }
  };
});
var $ZodCheckMaxLength = /* @__PURE__ */ $constructor("$ZodCheckMaxLength", (inst, def) => {
  var _a;
  $ZodCheck.init(inst, def);
  (_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
  inst._zod.check = (payload) => {
    const input = payload.value;
    const units = input.length;
    const length = typeof input === "string" && units > def.maximum ? codePointLength(input) : units;
    if (length <= def.maximum)
      return;
    const origin = getLengthableOrigin(input);
    payload.issues.push({
      origin,
      code: "too_big",
      maximum: def.maximum,
      inclusive: true,
      input,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckMinLength = /* @__PURE__ */ $constructor("$ZodCheckMinLength", (inst, def) => {
  var _a;
  $ZodCheck.init(inst, def);
  (_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
  inst._zod.check = (payload) => {
    const input = payload.value;
    const units = input.length;
    const length = typeof input === "string" && units >= def.minimum && units < def.minimum * 2 ? codePointLength(input) : units;
    if (length >= def.minimum)
      return;
    const origin = getLengthableOrigin(input);
    payload.issues.push({
      origin,
      code: "too_small",
      minimum: def.minimum,
      inclusive: true,
      input,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckLengthEquals = /* @__PURE__ */ $constructor("$ZodCheckLengthEquals", (inst, def) => {
  var _a;
  $ZodCheck.init(inst, def);
  (_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
  inst._zod.check = (payload) => {
    const input = payload.value;
    const units = input.length;
    const length = typeof input === "string" && units >= def.length && units <= def.length * 2 ? codePointLength(input) : units;
    if (length === def.length)
      return;
    const origin = getLengthableOrigin(input);
    const tooBig = length > def.length;
    payload.issues.push({
      origin,
      ...tooBig ? { code: "too_big", maximum: def.length } : { code: "too_small", minimum: def.length },
      inclusive: true,
      exact: true,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckStringFormat = /* @__PURE__ */ $constructor("$ZodCheckStringFormat", (inst, def) => {
  var _a, _b;
  $ZodCheck.init(inst, def);
  if (def.pattern)
    (_a = inst._zod).check ?? (_a.check = (payload) => {
      def.pattern.lastIndex = 0;
      if (def.pattern.test(payload.value))
        return;
      payload.issues.push({
        origin: "string",
        code: "invalid_format",
        format: def.format,
        input: payload.value,
        ...def.pattern ? { pattern: def.pattern.toString() } : {},
        inst,
        continue: !def.abort
      });
    });
  else
    (_b = inst._zod).check ?? (_b.check = () => {});
});
var $ZodCheckRegex = /* @__PURE__ */ $constructor("$ZodCheckRegex", (inst, def) => {
  $ZodCheckStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    def.pattern.lastIndex = 0;
    if (def.pattern.test(payload.value))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: payload.value,
      pattern: def.pattern.toString(),
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckLowerCase = /* @__PURE__ */ $constructor("$ZodCheckLowerCase", (inst, def) => {
  def.pattern ?? (def.pattern = lowercase);
  $ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckUpperCase = /* @__PURE__ */ $constructor("$ZodCheckUpperCase", (inst, def) => {
  def.pattern ?? (def.pattern = uppercase);
  $ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckIncludes = /* @__PURE__ */ $constructor("$ZodCheckIncludes", (inst, def) => {
  $ZodCheck.init(inst, def);
  const escapedRegex = escapeRegex(def.includes);
  const pattern = new RegExp(typeof def.position === "number" ? `^.{${def.position},}${escapedRegex}` : escapedRegex);
  def.pattern = pattern;
  inst._zod.check = (payload) => {
    if (payload.value.includes(def.includes, def.position))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: def.includes,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckStartsWith = /* @__PURE__ */ $constructor("$ZodCheckStartsWith", (inst, def) => {
  $ZodCheck.init(inst, def);
  const pattern = new RegExp(`^${escapeRegex(def.prefix)}.*`);
  def.pattern ?? (def.pattern = pattern);
  inst._zod.check = (payload) => {
    if (payload.value.startsWith(def.prefix))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: def.prefix,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckEndsWith = /* @__PURE__ */ $constructor("$ZodCheckEndsWith", (inst, def) => {
  $ZodCheck.init(inst, def);
  const pattern = new RegExp(`.*${escapeRegex(def.suffix)}$`);
  def.pattern ?? (def.pattern = pattern);
  inst._zod.check = (payload) => {
    if (payload.value.endsWith(def.suffix))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: def.suffix,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
function handleCheckPropertyResult(result, payload, property) {
  if (result.issues.length) {
    payload.issues.push(...prefixIssues(property, result.issues));
  }
}
var $ZodCheckProperties = /* @__PURE__ */ $constructor("$ZodCheckProperties", (inst, def) => {
  $ZodCheck.init(inst, def);
  hide(inst, Symbol.iterator, function* () {
    yield inst;
  });
  let entries;
  inst._zod.check = (payload) => {
    if (payload.value == null) {
      payload.issues.push({ expected: "object", code: "invalid_type", input: payload.value, inst });
      return;
    }
    entries ?? (entries = Reflect.ownKeys(def.shape).map((key) => [key, def.shape[key]]));
    const input = payload.value;
    let proms;
    for (const [key, schema] of entries) {
      const result = schema._zod.run({ value: input[key], issues: [] }, {});
      if (result instanceof Promise) {
        proms ?? (proms = []);
        proms.push(result.then((result) => handleCheckPropertyResult(result, payload, key)));
      } else {
        handleCheckPropertyResult(result, payload, key);
      }
    }
    if (proms)
      return Promise.all(proms).then(() => {
        return;
      });
    return;
  };
});
var $ZodCheckOverwrite = /* @__PURE__ */ $constructor("$ZodCheckOverwrite", (inst, def) => {
  $ZodCheck.init(inst, def);
  inst._zod.check = (payload) => {
    payload.value = def.tx(payload.value);
  };
});

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/doc.js
class Doc {
  constructor(args = [], closed = {}) {
    this.content = [];
    this.indent = 0;
    this.args = args;
    this.closed = closed;
  }
  indented(fn) {
    this.indent += 1;
    try {
      fn(this);
    } finally {
      this.indent -= 1;
    }
  }
  write(arg) {
    if (typeof arg === "function") {
      arg(this, { execution: "sync" });
      arg(this, { execution: "async" });
      return;
    }
    const content = arg;
    const lines = content.split(`
`).filter((x) => x);
    const minIndent = Math.min(...lines.map((x) => x.length - x.trimStart().length));
    const dedented = lines.map((x) => x.slice(minIndent)).map((x) => " ".repeat(this.indent * 2) + x);
    for (const line of dedented) {
      this.content.push(line);
    }
  }
  compile() {
    const F = Function;
    const content = this?.content ?? [``];
    const factory = new F(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${content.join(`
`)}
};`);
    return factory(...Object.values(this.closed));
  }
}

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/versions.js
var version = {
  major: 4,
  minor: 6,
  patch: 7
};

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/schemas.js
var $ZodType = /* @__PURE__ */ $constructor("$ZodType", (inst, def) => {
  var _a;
  inst ?? (inst = {});
  inst._zod.def = def;
  inst._zod.bag = inst._zod.bag || {};
  inst._zod.version = version;
  const defChecks = inst._zod.def.checks;
  const checks = inst._zod.traits.has("$ZodCheck") ? [inst, ...defChecks ?? []] : defChecks?.length ? [...defChecks] : [];
  for (const ch of checks) {
    for (const fn of ch._zod.onattach) {
      fn(inst);
    }
  }
  if (checks.length === 0) {
    (_a = inst._zod).deferred ?? (_a.deferred = []);
    inst._zod.deferred?.push(() => {
      inst._zod.run = inst._zod.parse;
    });
  } else {
    const runChecks = (payload, checks, ctx) => {
      if (payload.memo)
        return payload;
      let isAborted = aborted(payload);
      let asyncResult;
      for (const ch of checks) {
        if (ch._zod.def.when) {
          if (explicitlyAborted(payload))
            continue;
          const shouldRun = ch._zod.def.when(payload);
          if (!shouldRun)
            continue;
        } else if (isAborted) {
          continue;
        }
        const currLen = payload.issues.length;
        const _ = ch._zod.check(payload);
        if (_ instanceof Promise && ctx?.async === false) {
          throw new $ZodAsyncError;
        }
        if (asyncResult || _ instanceof Promise) {
          asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
            await _;
            const nextLen = payload.issues.length;
            if (nextLen === currLen)
              return;
            attachSchema(payload.issues, currLen, inst);
            if (!isAborted)
              isAborted = aborted(payload, currLen);
          });
        } else {
          const nextLen = payload.issues.length;
          if (nextLen === currLen)
            continue;
          attachSchema(payload.issues, currLen, inst);
          if (!isAborted)
            isAborted = aborted(payload, currLen);
        }
      }
      if (asyncResult) {
        return asyncResult.then(() => {
          return payload;
        });
      }
      return payload;
    };
    const handleCanaryResult = (canary, payload, ctx) => {
      if (aborted(canary)) {
        canary.aborted = true;
        return canary;
      }
      const checkResult = runChecks(payload, checks, ctx);
      if (checkResult instanceof Promise) {
        if (ctx.async === false)
          throw new $ZodAsyncError;
        return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
      }
      return inst._zod.parse(checkResult, ctx);
    };
    inst._zod.run = (payload, ctx) => {
      if (ctx.skipChecks) {
        return inst._zod.parse(payload, ctx);
      }
      if (ctx.direction === "backward") {
        const canary = inst._zod.parse({ value: payload.value, issues: [] }, { ...ctx, skipChecks: true });
        if (canary instanceof Promise) {
          return canary.then((canary) => {
            return handleCanaryResult(canary, payload, ctx);
          });
        }
        return handleCanaryResult(canary, payload, ctx);
      }
      const result = inst._zod.parse(payload, ctx);
      if (result instanceof Promise) {
        if (ctx.async === false)
          throw new $ZodAsyncError;
        return result.then((result) => runChecks(result, checks, ctx));
      }
      return runChecks(result, checks, ctx);
    };
  }
}, {
  get "~standard"() {
    return hide(this, "~standard", standardProps(this));
  },
  set "~standard"(value) {
    own(this, "~standard", value);
  }
});
var toStandardResult = (r, ctx) => r.issues.length ? { issues: r.issues.map((iss) => finalizeIssue(iss, ctx, config())) } : { value: r.value };
async function validateAsync2(inst, value) {
  const ctx = { async: true };
  return toStandardResult(await inst._zod.run({ value, issues: [] }, ctx), ctx);
}
function standardProps(inst) {
  return {
    validate: (value) => {
      const ctx = { async: false };
      try {
        const r = inst._zod.run({ value, issues: [] }, ctx);
        if (!(r instanceof Promise))
          return toStandardResult(r, ctx);
      } catch (_) {}
      return validateAsync2(inst, value);
    },
    vendor: "zod",
    version: 1
  };
}
var $ZodString = /* @__PURE__ */ $constructor("$ZodString", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.pattern = def.pattern ?? anyString;
  inst._zod.parse = (payload, _) => {
    if (def.coerce)
      try {
        payload.value = String(payload.value);
      } catch (_) {}
    if (typeof payload.value === "string")
      return payload;
    payload.issues.push({
      expected: "string",
      code: "invalid_type",
      input: payload.value,
      inst
    });
    return payload;
  };
});
var $ZodStringFormat = /* @__PURE__ */ $constructor("$ZodStringFormat", (inst, def) => {
  $ZodCheckStringFormat.init(inst, def);
  $ZodString.init(inst, def);
});
var $ZodGUID = /* @__PURE__ */ $constructor("$ZodGUID", (inst, def) => {
  def.pattern ?? (def.pattern = guid);
  $ZodStringFormat.init(inst, def);
});
var $ZodUUID = /* @__PURE__ */ $constructor("$ZodUUID", (inst, def) => {
  if (def.version) {
    const versionMap = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    };
    const v = versionMap[def.version];
    if (v === undefined)
      throw new Error(`Invalid UUID version: "${def.version}"`);
    def.pattern ?? (def.pattern = uuid(v));
  } else
    def.pattern ?? (def.pattern = uuid());
  $ZodStringFormat.init(inst, def);
});
var $ZodEmail = /* @__PURE__ */ $constructor("$ZodEmail", (inst, def) => {
  def.pattern ?? (def.pattern = email);
  $ZodStringFormat.init(inst, def);
});
var URL_BAD_FORMAT = 1;
var URL_UNPARSEABLE = 2;
function canParseURL(input) {
  try {
    if (typeof URL !== "undefined" && typeof URL.canParse === "function")
      return URL.canParse(input);
    new URL(input);
    return true;
  } catch {
    return false;
  }
}
function validateURL(trimmed, def) {
  if (!("normalize" in def) && !("hostname" in def) && !("protocol" in def)) {
    return canParseURL(trimmed) || URL_UNPARSEABLE;
  }
  return parseURLObject(trimmed, def);
}
function parseURLObject(trimmed, def) {
  if (!def.normalize && def.protocol?.source === httpProtocol.source && !/^https?:\/\//i.test(trimmed)) {
    return URL_BAD_FORMAT;
  }
  try {
    if (typeof URL !== "undefined") {
      const URLStatic = URL;
      if (typeof URLStatic.parse === "function")
        return URLStatic.parse(trimmed) ?? URL_UNPARSEABLE;
    }
    return new URL(trimmed);
  } catch {
    return URL_UNPARSEABLE;
  }
}
var asciiTabOrNewline = /[\t\n\r]/g;
function stripTabAndNewline(value) {
  return value.replace(asciiTabOrNewline, "");
}
function urlHostnameOk(url, hostname) {
  hostname.lastIndex = 0;
  return hostname.test(url.hostname);
}
function urlProtocolOk(url, protocol) {
  protocol.lastIndex = 0;
  return protocol.test(url.protocol.endsWith(":") ? url.protocol.slice(0, -1) : url.protocol);
}
var $ZodURL = /* @__PURE__ */ $constructor("$ZodURL", (inst, def) => {
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    try {
      const trimmed = payload.value.trim();
      const url = validateURL(trimmed, def);
      if (url === URL_BAD_FORMAT) {
        payload.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: payload.value,
          inst,
          continue: !def.abort
        });
        return;
      }
      if (url === URL_UNPARSEABLE) {
        payload.issues.push({
          code: "invalid_format",
          format: "url",
          input: payload.value,
          inst,
          continue: !def.abort
        });
        return;
      }
      if (url === true) {
        payload.value = stripTabAndNewline(trimmed);
        return;
      }
      if (def.hostname && !urlHostnameOk(url, def.hostname)) {
        payload.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid hostname",
          pattern: def.hostname.source,
          input: payload.value,
          inst,
          continue: !def.abort
        });
      }
      if (def.protocol && !urlProtocolOk(url, def.protocol)) {
        payload.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid protocol",
          pattern: def.protocol.source,
          input: payload.value,
          inst,
          continue: !def.abort
        });
      }
      payload.value = def.normalize ? url.href : stripTabAndNewline(trimmed);
      return;
    } catch (_) {
      payload.issues.push({
        code: "invalid_format",
        format: "url",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    }
  };
});
var $ZodEmoji = /* @__PURE__ */ $constructor("$ZodEmoji", (inst, def) => {
  def.pattern ?? (def.pattern = emoji());
  $ZodStringFormat.init(inst, def);
});
var $ZodNanoID = /* @__PURE__ */ $constructor("$ZodNanoID", (inst, def) => {
  if (def.length !== undefined && (!Number.isInteger(def.length) || def.length < 1))
    throw new Error(`Invalid nanoid length: ${def.length}`);
  def.pattern ?? (def.pattern = def.length === undefined ? nanoid : nanoidOfLength(def.length));
  $ZodStringFormat.init(inst, def);
});
var $ZodCUID = /* @__PURE__ */ $constructor("$ZodCUID", (inst, def) => {
  def.pattern ?? (def.pattern = cuid);
  $ZodStringFormat.init(inst, def);
});
var $ZodCUID2 = /* @__PURE__ */ $constructor("$ZodCUID2", (inst, def) => {
  def.pattern ?? (def.pattern = cuid2);
  $ZodStringFormat.init(inst, def);
});
var $ZodULID = /* @__PURE__ */ $constructor("$ZodULID", (inst, def) => {
  def.pattern ?? (def.pattern = ulid);
  $ZodStringFormat.init(inst, def);
});
var $ZodXID = /* @__PURE__ */ $constructor("$ZodXID", (inst, def) => {
  def.pattern ?? (def.pattern = xid);
  $ZodStringFormat.init(inst, def);
});
var $ZodKSUID = /* @__PURE__ */ $constructor("$ZodKSUID", (inst, def) => {
  def.pattern ?? (def.pattern = ksuid);
  $ZodStringFormat.init(inst, def);
});
var $ZodISODateTime = /* @__PURE__ */ $constructor("$ZodISODateTime", (inst, def) => {
  def.pattern ?? (def.pattern = datetime(def));
  $ZodStringFormat.init(inst, def);
});
var $ZodISODate = /* @__PURE__ */ $constructor("$ZodISODate", (inst, def) => {
  def.pattern ?? (def.pattern = date);
  $ZodStringFormat.init(inst, def);
});
var $ZodISOTime = /* @__PURE__ */ $constructor("$ZodISOTime", (inst, def) => {
  def.pattern ?? (def.pattern = time(def));
  $ZodStringFormat.init(inst, def);
});
var $ZodISODuration = /* @__PURE__ */ $constructor("$ZodISODuration", (inst, def) => {
  def.pattern ?? (def.pattern = duration);
  $ZodStringFormat.init(inst, def);
});
var $ZodIPv4 = /* @__PURE__ */ $constructor("$ZodIPv4", (inst, def) => {
  def.pattern ?? (def.pattern = ipv4);
  $ZodStringFormat.init(inst, def);
});
var ipv6Alphabet = /^[0-9a-fA-F:.]+$/;
function isValidIPv6(value) {
  if (!ipv6Alphabet.test(value))
    return false;
  return canParseURL(`http://[${value}]`);
}
var $ZodIPv6 = /* @__PURE__ */ $constructor("$ZodIPv6", (inst, def) => {
  def.pattern ?? (def.pattern = ipv6);
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    if (!isValidIPv6(payload.value)) {
      payload.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    }
  };
});
var $ZodCIDRv4 = /* @__PURE__ */ $constructor("$ZodCIDRv4", (inst, def) => {
  def.pattern ?? (def.pattern = cidrv4);
  $ZodStringFormat.init(inst, def);
});
function isValidCIDRv6(value) {
  const parts = value.split("/");
  if (parts.length !== 2)
    return false;
  const [address, prefix] = parts;
  if (!prefix)
    return false;
  const prefixNum = Number(prefix);
  if (`${prefixNum}` !== prefix)
    return false;
  if (prefixNum < 0 || prefixNum > 128)
    return false;
  return isValidIPv6(address);
}
var $ZodCIDRv6 = /* @__PURE__ */ $constructor("$ZodCIDRv6", (inst, def) => {
  def.pattern ?? (def.pattern = cidrv6);
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    if (!isValidCIDRv6(payload.value)) {
      payload.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    }
  };
});
function isValidBase64(data) {
  if (data === "")
    return true;
  if (/\s/.test(data))
    return false;
  if (data.length % 4 !== 0)
    return false;
  try {
    atob(data);
    return true;
  } catch {
    return false;
  }
}
var base64Charset = /^[0-9a-zA-Z+/]*={0,2}$/;
var $ZodBase64 = /* @__PURE__ */ $constructor("$ZodBase64", (inst, def) => {
  def.pattern ?? (def.pattern = base64Charset);
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    if (isValidBase64(payload.value))
      return;
    payload.issues.push({
      code: "invalid_format",
      format: "base64",
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var base64urlCharset = /^[A-Za-z0-9_-]*$/;
function isValidBase64URL(data) {
  if (!base64urlCharset.test(data))
    return false;
  const base64 = data.replace(/[-_]/g, (c) => c === "-" ? "+" : "/");
  const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, "=");
  return isValidBase64(padded);
}
var $ZodBase64URL = /* @__PURE__ */ $constructor("$ZodBase64URL", (inst, def) => {
  def.pattern ?? (def.pattern = base64urlCharset);
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    if (isValidBase64URL(payload.value))
      return;
    payload.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodE164 = /* @__PURE__ */ $constructor("$ZodE164", (inst, def) => {
  def.pattern ?? (def.pattern = e164);
  $ZodStringFormat.init(inst, def);
});
function isValidJWT(token, algorithm = null) {
  try {
    const tokensParts = token.split(".");
    if (tokensParts.length !== 3)
      return false;
    const [header] = tokensParts;
    if (!header)
      return false;
    const parsedHeader = JSON.parse(atob(header));
    if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT")
      return false;
    if (!parsedHeader.alg)
      return false;
    if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm))
      return false;
    return true;
  } catch {
    return false;
  }
}
var $ZodJWT = /* @__PURE__ */ $constructor("$ZodJWT", (inst, def) => {
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    if (isValidJWT(payload.value, def.alg))
      return;
    payload.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodNumber = /* @__PURE__ */ $constructor("$ZodNumber", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.pattern = number;
  inst._zod.parse = (payload, _ctx) => {
    if (def.coerce)
      try {
        payload.value = Number(payload.value);
      } catch (_) {}
    const input = payload.value;
    if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) {
      return payload;
    }
    const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? String(input) : undefined : undefined;
    payload.issues.push({
      expected: "number",
      code: "invalid_type",
      input,
      inst,
      ...received ? { received } : {}
    });
    return payload;
  };
});
var $ZodNumberFormat = /* @__PURE__ */ $constructor("$ZodNumberFormat", (inst, def) => {
  $ZodCheckNumberFormat.init(inst, def);
  $ZodNumber.init(inst, def);
});
var $ZodBoolean = /* @__PURE__ */ $constructor("$ZodBoolean", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.pattern = boolean;
  inst._zod.parse = (payload, _ctx) => {
    if (def.coerce)
      try {
        payload.value = Boolean(payload.value);
      } catch (_) {}
    const input = payload.value;
    if (typeof input === "boolean")
      return payload;
    payload.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input,
      inst
    });
    return payload;
  };
});
var $ZodUnknown = /* @__PURE__ */ $constructor("$ZodUnknown", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload) => payload;
});
var $ZodNever = /* @__PURE__ */ $constructor("$ZodNever", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, _ctx) => {
    payload.issues.push({
      expected: "never",
      code: "invalid_type",
      input: payload.value,
      inst
    });
    return payload;
  };
});
function capSize(inst, size) {
  const caps = sizeCaps(inst._zod.def.checks);
  if (!caps.length)
    return;
  const cap = Math.min(...caps.map((c) => c[0]));
  const parse = inst._zod.parse;
  inst._zod.parse = (payload, ctx) => {
    const n = size(payload.value);
    if (n > cap && !ctx?.skipChecks && ctx?.direction !== "backward") {
      for (const [max, ch] of sizeCaps(inst._zod.def.checks)) {
        if (n > max && ch._zod.def.when(payload)) {
          const start = payload.issues.length;
          ch._zod.check(payload);
          payload.issues[start].continue = false;
          attachSchema(payload.issues, start, inst);
          return payload;
        }
      }
    }
    return parse(payload, ctx);
  };
}
var arraySize = (input) => Array.isArray(input) ? input.length : -1;
function handleArrayResult(result, final, index) {
  if (result.issues.length) {
    final.issues.push(...prefixIssues(index, result.issues));
  }
  final.value[index] = result.value;
}
var $ZodArray = /* @__PURE__ */ $constructor("$ZodArray", (inst, def) => {
  $ZodType.init(inst, def);
  const memo = globalConfig.memoizer;
  memo?.attach(inst);
  inst._zod.parse = (payload, ctx) => {
    const input = payload.value;
    if (!Array.isArray(input)) {
      payload.issues.push({
        expected: "array",
        code: "invalid_type",
        input,
        inst
      });
      return payload;
    }
    payload.value = memo ? memo.alloc(inst, payload, Array(input.length), ctx) : Array(input.length);
    const proms = [];
    const abortEarly = ctx?.abortEarly;
    for (let i = 0;i < input.length; i++) {
      const item = input[i];
      const result = def.element._zod.run({
        value: item,
        issues: []
      }, ctx);
      if (result instanceof Promise) {
        proms.push(result.then((result) => handleArrayResult(result, payload, i)));
      } else {
        handleArrayResult(result, payload, i);
        if (abortEarly && result.issues.length !== 0 && aborted(result))
          break;
      }
    }
    if (proms.length) {
      return Promise.all(proms).then(() => payload);
    }
    return payload;
  };
  capSize(inst, arraySize);
});
function handlePropertyResult(result, final, key, input, optin, optout) {
  const isPresent = key in input;
  const isOptionalOut = optout === "optional";
  if (!isPresent && isOptionalOut && optin === "optional") {
    return;
  }
  if (result.issues.length) {
    if (optin !== undefined && isOptionalOut && !isPresent) {
      return;
    }
    final.issues.push(...prefixIssues(key, result.issues));
  }
  if (!isPresent && optin === undefined) {
    if (!result.issues.length) {
      final.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: undefined,
        path: [key]
      });
    }
    return;
  }
  if (result.value === undefined) {
    if (isPresent || optin === "defaulted" && !isOptionalOut) {
      final.value[key] = undefined;
    }
  } else {
    final.value[key] = result.value;
  }
}
var NO_SYMBOL_KEYS = [];
function normalizeDef(def) {
  const keys = Object.keys(def.shape);
  const ownSymbols = Object.getOwnPropertySymbols(def.shape);
  const symbolKeys = ownSymbols.length ? ownSymbols : NO_SYMBOL_KEYS;
  const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
  for (const k of allKeys) {
    if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) {
      throw new Error(`Invalid element at key "${String(k)}": expected a Zod schema`);
    }
  }
  const okeys = optionalKeys(def.shape);
  return {
    ...def,
    allKeys,
    symbolKeys,
    keySet: new Set(keys),
    numKeys: keys.length,
    optionalKeys: new Set(okeys)
  };
}
function handleCatchall(proms, input, payload, ctx, def, inst, abortEarly) {
  const unrecognized = [];
  const keySet = def.keySet;
  const _catchall = def.catchall._zod;
  const t = _catchall.def.type;
  const optin = _catchall.optin;
  const optout = _catchall.optout;
  let seen = 0;
  for (const key in input) {
    if (abortEarly && payload.issues.length !== seen) {
      if (aborted(payload, seen))
        break;
      seen = payload.issues.length;
    }
    if (keySet.has(key))
      continue;
    if (key === "__proto__") {
      if (t === "never")
        unrecognized.push(key);
      continue;
    }
    if (t === "never") {
      unrecognized.push(key);
      continue;
    }
    const r = _catchall.run({ value: input[key], issues: [] }, ctx);
    if (r instanceof Promise) {
      proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
    } else {
      handlePropertyResult(r, payload, key, input, optin, optout);
    }
  }
  if (unrecognized.length) {
    payload.issues.push({
      code: "unrecognized_keys",
      keys: unrecognized,
      input,
      inst,
      continue: true
    });
  }
  if (!proms.length)
    return payload;
  return Promise.all(proms).then(() => {
    return payload;
  });
}
var $ZodObject = /* @__PURE__ */ $constructor("$ZodObject", (inst, def) => {
  $ZodType.init(inst, def);
  const desc = Object.getOwnPropertyDescriptor(def, "shape");
  const sh = desc?.get ? desc.get.raw : def.shape ?? {};
  if (sh) {
    const get = () => {
      const newSh = { ...sh };
      Object.defineProperty(def, "shape", { value: newSh });
      get.raw = newSh;
      return newSh;
    };
    get.raw = sh;
    Object.defineProperty(def, "shape", { get });
  }
  const _normalized = cached(() => normalizeDef(def));
  defineLazyInternal(inst, "propValues", (zod) => {
    const shape = zod.def.shape;
    const propValues = {};
    for (const key in shape) {
      const field = shape[key]._zod;
      if (field.values) {
        if (!Object.prototype.hasOwnProperty.call(propValues, key)) {
          assignProp(propValues, key, new Set);
        }
        for (const v of field.values)
          propValues[key].add(v);
        if (field.optin !== undefined)
          propValues[key].add(undefined);
      }
    }
    return propValues;
  });
  const isObject2 = isObject;
  const catchall = def.catchall;
  let value;
  const memo = globalConfig.memoizer;
  memo?.attach(inst);
  inst._zod.parse = (payload, ctx) => {
    value ?? (value = _normalized.value);
    const input = payload.value;
    if (!isObject2(input)) {
      payload.issues.push({
        expected: "object",
        code: "invalid_type",
        input,
        inst
      });
      return payload;
    }
    payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
    const proms = [];
    const shape = value.shape;
    const abortEarly = ctx?.abortEarly;
    let seen = payload.issues.length;
    for (const key of value.allKeys) {
      if (abortEarly && payload.issues.length !== seen) {
        if (aborted(payload, seen))
          break;
        seen = payload.issues.length;
      }
      if (key === "__proto__")
        continue;
      const el = shape[key];
      const optin = el._zod.optin;
      const optout = el._zod.optout;
      const r = el._zod.run({ value: input[key], issues: [] }, ctx);
      if (r instanceof Promise) {
        proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
      } else {
        handlePropertyResult(r, payload, key, input, optin, optout);
      }
    }
    if (!catchall) {
      return proms.length ? Promise.all(proms).then(() => payload) : payload;
    }
    return handleCatchall(proms, input, payload, ctx, _normalized.value, inst, abortEarly === true);
  };
});
var $ZodObjectJIT = /* @__PURE__ */ $constructor("$ZodObjectJIT", (inst, def) => {
  $ZodObject.init(inst, def);
  const superParse = inst._zod.parse;
  const _normalized = cached(() => normalizeDef(def));
  const memo = globalConfig.memoizer;
  const generateFastpass = (shape) => {
    const normalized = _normalized.value;
    const syms = normalized.symbolKeys;
    const doc = new Doc(["payload", "ctx"], { shape, inst, memo, syms });
    const parseStr = (k) => `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
    const prefixStr = (id, k) => `
          let ${id}_ab = false;
          for (let i = 0; i < ${id}.issues.length; i++) {
            const iss = ${id}.issues[i];
            iss.path = iss.path ? [${k}, ...iss.path] : [${k}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${id}_ab = true;
          }
          if (${id}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
    doc.write(`const input = payload.value;`);
    const ids = Object.create(null);
    let counter = 0;
    for (const key of normalized.allKeys) {
      ids[key] = `key_${counter++}`;
    }
    doc.write(memo ? `const newResult = memo.alloc(inst, payload, {}, ctx);` : `const newResult = {};`);
    for (const key of normalized.allKeys) {
      if (key === "__proto__")
        continue;
      const id = ids[key];
      const k = typeof key === "symbol" ? `syms[${syms.indexOf(key)}]` : esc(key);
      const isPresent = `${k} in input`;
      const schema = shape[key];
      const optin = schema?._zod?.optin;
      const isOptionalIn = optin !== undefined;
      const isOptionalOut = schema?._zod?.optout === "optional";
      doc.write(`const ${id} = ${parseStr(k)};`);
      if (isOptionalIn && isOptionalOut) {
        const assign = optin === "optional" ? `${id}_present` : `${id}.value !== undefined || ${id}_present`;
        doc.write(`
        const ${id}_present = ${isPresent};
        if (!${id}.issues.length || ${id}_present) {
          if (${id}.issues.length) {${prefixStr(id, k)}
          }

          if (${assign}) {
            newResult[${k}] = ${id}.value;
          }
        }

      `);
      } else if (!isOptionalIn) {
        doc.write(`
        const ${id}_present = ${isPresent};
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
        if (!${id}_present && !${id}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${k}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${id}_present) {
          newResult[${k}] = ${id}.value;
        }

      `);
      } else {
        doc.write(`
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
      `);
        if (optin === "defaulted") {
          doc.write(`newResult[${k}] = ${id}.value;`);
        } else {
          doc.write(`
        if (${id}.value !== undefined || ${isPresent}) {
          newResult[${k}] = ${id}.value;
        }
      `);
        }
      }
    }
    doc.write(`payload.value = newResult;`);
    doc.write(`return payload;`);
    return doc.compile();
  };
  let fastpass;
  const isObject2 = isObject;
  const jit = !globalConfig.jitless;
  const allowsEval2 = allowsEval;
  const fastEnabled = jit && allowsEval2.value;
  const catchall = def.catchall;
  let value;
  inst._zod.parse = (payload, ctx) => {
    value ?? (value = _normalized.value);
    const input = payload.value;
    if (!isObject2(input)) {
      payload.issues.push({
        expected: "object",
        code: "invalid_type",
        input,
        inst
      });
      return payload;
    }
    if (jit && fastEnabled && ctx?.async === false && ctx.jitless !== true) {
      if (!fastpass)
        fastpass = generateFastpass(def.shape);
      payload = fastpass(payload, ctx);
      if (!catchall)
        return payload;
      return handleCatchall([], input, payload, ctx, value, inst, ctx?.abortEarly === true);
    }
    return superParse(payload, ctx);
  };
});
function handleUnionResults(results, final, inst, ctx) {
  for (const result of results) {
    if (result.issues.length === 0) {
      final.value = result.value;
      return final;
    }
  }
  const nonaborted = results.filter((r) => !aborted(r));
  if (nonaborted.length === 1) {
    final.value = nonaborted[0].value;
    return nonaborted[0];
  }
  final.issues.push({
    code: "invalid_union",
    input: final.value,
    inst,
    errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
  });
  return final;
}
var $ZodUnion = /* @__PURE__ */ $constructor("$ZodUnion", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazyInternal(inst, "optin", (zod) => zod.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : zod.def.options.some((o) => o._zod.optin !== undefined) ? "optional" : undefined);
  defineLazyInternal(inst, "optout", (zod) => zod.def.options.some((o) => o._zod.optout === "optional") ? "optional" : undefined);
  defineLazyInternal(inst, "values", (zod) => {
    if (zod.def.options.every((o) => o._zod.values)) {
      return new Set(zod.def.options.flatMap((option) => Array.from(option._zod.values)));
    }
    return;
  });
  defineLazyInternal(inst, "pattern", (zod) => {
    if (zod.def.options.every((o) => o._zod.pattern)) {
      const patterns = zod.def.options.map((o) => o._zod.pattern);
      return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
    }
    return;
  });
  const first = def.options.length === 1 ? def.options[0]._zod.run : null;
  inst._zod.parse = (payload, ctx) => {
    if (first) {
      return first(payload, ctx);
    }
    let async = false;
    const results = [];
    for (const option of def.options) {
      const result = option._zod.run({
        value: payload.value,
        issues: []
      }, ctx);
      if (result instanceof Promise) {
        results.push(result);
        async = true;
      } else {
        if (result.issues.length === 0)
          return result;
        results.push(result);
      }
    }
    if (!async)
      return handleUnionResults(results, payload, inst, ctx);
    return Promise.all(results).then((results) => {
      return handleUnionResults(results, payload, inst, ctx);
    });
  };
});
function discriminatorMap(def) {
  const map = new Map;
  for (const option of def.options) {
    const values = option._zod.propValues?.[def.discriminator];
    if (!values || values.size === 0)
      throw new Error(`Invalid discriminated union option at index "${def.options.indexOf(option)}"`);
    for (const value of values) {
      if (map.has(value)) {
        if (value !== undefined)
          throw new Error(`Duplicate discriminator value "${String(value)}"`);
        map.set(value, null);
      } else {
        map.set(value, option);
      }
    }
  }
  return map;
}
var $ZodDiscriminatedUnion = /* @__PURE__ */ $constructor("$ZodDiscriminatedUnion", (inst, def) => {
  def.inclusive = false;
  $ZodUnion.init(inst, def);
  const _super = inst._zod.parse;
  defineLazyInternal(inst, "propValues", (zod) => {
    const propValues = {};
    let undefinedCount = 0;
    for (const option of zod.def.options) {
      const pv = option._zod.propValues;
      if (!pv || Object.keys(pv).length === 0)
        throw new Error(`Invalid discriminated union option at index "${zod.def.options.indexOf(option)}"`);
      if (pv[zod.def.discriminator]?.has(undefined))
        undefinedCount++;
      for (const [k, v] of Object.entries(pv)) {
        if (!Object.prototype.hasOwnProperty.call(propValues, k)) {
          assignProp(propValues, k, new Set);
        }
        for (const val of v) {
          propValues[k].add(val);
        }
      }
    }
    if (!zod.def.unionFallback && undefinedCount > 1)
      propValues[zod.def.discriminator]?.delete(undefined);
    return propValues;
  });
  def.options.forEach((option, i) => {
    const propShape = rawShape(option._zod.def);
    if (propShape && !Object.prototype.hasOwnProperty.call(propShape, def.discriminator)) {
      throw new Error(`Invalid discriminated union option at index "${i}"`);
    }
  });
  const disc = cached(() => discriminatorMap(def));
  inst._zod.parse = (payload, ctx) => {
    const input = payload.value;
    if (!isObject(input)) {
      payload.issues.push({
        code: "invalid_type",
        expected: "object",
        input,
        inst
      });
      return payload;
    }
    const value = input?.[def.discriminator];
    const opt = disc.value.get(value);
    if (opt && (value !== undefined || ctx.direction !== "backward")) {
      return opt._zod.run(payload, ctx);
    }
    if (def.unionFallback || ctx.direction === "backward") {
      return _super(payload, ctx);
    }
    payload.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: def.discriminator,
      options: Array.from(disc.value.keys()).filter((value) => disc.value.get(value) !== null),
      input,
      path: [def.discriminator],
      inst
    });
    return payload;
  };
});
var $ZodIntersection = /* @__PURE__ */ $constructor("$ZodIntersection", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, ctx) => {
    const input = payload.value;
    const left = def.left._zod.run({ value: input, issues: [] }, ctx);
    const right = def.right._zod.run({ value: input, issues: [] }, ctx);
    const async = left instanceof Promise || right instanceof Promise;
    if (async) {
      return Promise.all([left, right]).then(([left, right]) => {
        return handleIntersectionResults(payload, left, right);
      });
    }
    return handleIntersectionResults(payload, left, right);
  };
});
function mergeValues(a, b) {
  if (a === b) {
    return { valid: true, data: a };
  }
  if (a instanceof Date && b instanceof Date && +a === +b) {
    return { valid: true, data: a };
  }
  if (isPlainObject(a) && isPlainObject(b)) {
    const bKeys = Object.keys(b);
    const sharedKeys = Object.keys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    if (Object.prototype.hasOwnProperty.call(newObj, "__proto__"))
      delete newObj.__proto__;
    for (const key of sharedKeys) {
      if (key === "__proto__")
        continue;
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return {
          valid: false,
          mergeErrorPath: [key, ...sharedValue.mergeErrorPath]
        };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  }
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) {
      return { valid: false, mergeErrorPath: [] };
    }
    const newArray = [];
    for (let index = 0;index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return {
          valid: false,
          mergeErrorPath: [index, ...sharedValue.mergeErrorPath]
        };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  }
  return { valid: false, mergeErrorPath: [] };
}
function handleIntersectionResults(result, left, right) {
  const unrecKeys = new Map;
  let unrecIssue;
  const keyIssues = new Map;
  const collect = (iss, side) => {
    let keys;
    if (iss.code === "unrecognized_keys" && !iss.path?.length) {
      unrecIssue ?? (unrecIssue = iss);
      keys = iss.keys;
    } else if (iss.code === "invalid_key" && iss.origin === "record" && iss.path?.length === 1) {
      const k = String(iss.path[0]);
      if (!keyIssues.has(k))
        keyIssues.set(k, iss);
      keys = [k];
    } else {
      return false;
    }
    for (const k of keys) {
      if (!unrecKeys.has(k))
        unrecKeys.set(k, {});
      unrecKeys.get(k)[side] = true;
    }
    return true;
  };
  for (const iss of left.issues) {
    if (!collect(iss, "l"))
      result.issues.push(iss);
  }
  for (const iss of right.issues) {
    if (!collect(iss, "r"))
      result.issues.push(iss);
  }
  const bothKeys = [...unrecKeys].filter(([, f]) => f.l && f.r).map(([k]) => k);
  if (bothKeys.length) {
    const aggregated = unrecIssue ? bothKeys.filter((k) => unrecIssue.keys.includes(k)) : [];
    if (aggregated.length)
      result.issues.push({ ...unrecIssue, keys: aggregated });
    for (const k of bothKeys) {
      if (!aggregated.includes(k) && keyIssues.has(k))
        result.issues.push(keyIssues.get(k));
    }
  }
  const merged = mergeValues(left.value, right.value);
  if (!merged.valid) {
    if (aborted(result))
      return result;
    throw new Error(`Unmergable intersection. Error path: ` + `${JSON.stringify(merged.mergeErrorPath)}`);
  }
  result.value = merged.data;
  return result;
}
var $ZodTuple = /* @__PURE__ */ $constructor("$ZodTuple", (inst, def) => {
  $ZodType.init(inst, def);
  const items = def.items;
  const memo = globalConfig.memoizer;
  memo?.attach(inst);
  inst._zod.parse = (payload, ctx) => {
    const input = payload.value;
    if (!Array.isArray(input)) {
      payload.issues.push({
        input,
        inst,
        expected: "tuple",
        code: "invalid_type"
      });
      return payload;
    }
    payload.value = memo ? memo.alloc(inst, payload, [], ctx) : [];
    const proms = [];
    const optinStart = getTupleOptStart(items, "optin");
    const optoutStart = getTupleOptStart(items, "optout");
    if (!def.rest) {
      if (input.length < optinStart) {
        payload.issues.push({
          code: "too_small",
          minimum: optinStart,
          inclusive: true,
          input,
          inst,
          origin: "array"
        });
        return payload;
      }
      if (input.length > items.length) {
        payload.issues.push({
          code: "too_big",
          maximum: items.length,
          inclusive: true,
          input,
          inst,
          origin: "array"
        });
      }
    }
    const itemResults = new Array(items.length);
    const abortEarly = def.rest ? ctx?.abortEarly : undefined;
    let itemAborted = false;
    for (let i = 0;i < items.length; i++) {
      const r = items[i]._zod.run({ value: input[i], issues: [] }, ctx);
      if (r instanceof Promise) {
        proms.push(r.then((rr) => {
          itemResults[i] = rr;
        }));
      } else {
        itemResults[i] = r;
        if (abortEarly && !itemAborted && r.issues.length)
          itemAborted = aborted(r);
      }
    }
    if (def.rest && !itemAborted) {
      let i = items.length - 1;
      const rest = input.slice(items.length);
      let seen = payload.issues.length;
      for (const el of rest) {
        if (abortEarly && payload.issues.length !== seen) {
          if (aborted(payload, seen))
            break;
          seen = payload.issues.length;
        }
        i++;
        const result = def.rest._zod.run({ value: el, issues: [] }, ctx);
        if (result instanceof Promise) {
          proms.push(result.then((r) => handleTupleResult(r, payload, i)));
        } else {
          handleTupleResult(result, payload, i);
        }
      }
    }
    if (proms.length) {
      return Promise.all(proms).then(() => handleTupleResults(itemResults, payload, items, input, optoutStart));
    }
    return handleTupleResults(itemResults, payload, items, input, optoutStart);
  };
});
function getTupleOptStart(items, key) {
  for (let i = items.length - 1;i >= 0; i--) {
    const omittable = key === "optin" ? items[i]._zod.optin !== undefined : items[i]._zod.optout === "optional";
    if (!omittable)
      return i + 1;
  }
  return 0;
}
function handleTupleResult(result, final, index) {
  if (result.issues.length) {
    final.issues.push(...prefixIssues(index, result.issues));
  }
  final.value[index] = result.value;
}
function handleTupleResults(itemResults, final, items, input, optoutStart) {
  for (let i = 0;i < items.length; i++) {
    const r = itemResults[i];
    const isPresent = i < input.length;
    if (!isPresent && i >= optoutStart && items[i]._zod.optin === "optional") {
      final.value.length = i;
      break;
    }
    if (r.issues.length) {
      if (!isPresent && i >= optoutStart) {
        final.value.length = i;
        break;
      }
      final.issues.push(...prefixIssues(i, r.issues));
    }
    final.value[i] = r.value;
  }
  for (let i = final.value.length - 1;i >= input.length; i--) {
    if (items[i]._zod.optout === "optional" && final.value[i] === undefined) {
      final.value.length = i;
    } else {
      break;
    }
  }
  return final;
}
var $ZodRecord = /* @__PURE__ */ $constructor("$ZodRecord", (inst, def) => {
  $ZodType.init(inst, def);
  const memo = globalConfig.memoizer;
  memo?.attach(inst);
  inst._zod.parse = (payload, ctx) => {
    const input = payload.value;
    if (!isPlainObject(input)) {
      payload.issues.push({
        expected: "record",
        code: "invalid_type",
        input,
        inst
      });
      return payload;
    }
    const proms = [];
    const values = def.keyType._zod.values;
    if (values && !def.partial) {
      payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
      const recordKeys = new Set;
      for (const key of values) {
        if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
          recordKeys.add(typeof key === "number" ? key.toString() : key);
          if (key === "__proto__")
            continue;
          const keyResult = def.keyType._zod.run({ value: key, issues: [] }, ctx);
          if (keyResult instanceof Promise) {
            throw new Error("Async schemas not supported in object keys currently");
          }
          if (keyResult.issues.length) {
            payload.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
              input: key,
              path: [key],
              inst
            });
            continue;
          }
          const outKey = keyResult.value;
          if (outKey === "__proto__")
            continue;
          const result = def.valueType._zod.run({ value: input[key], issues: [] }, ctx);
          if (result instanceof Promise) {
            proms.push(result.then((result) => {
              if (result.issues.length) {
                payload.issues.push(...prefixIssues(key, result.issues));
              }
              payload.value[outKey] = result.value;
            }));
          } else {
            if (result.issues.length) {
              payload.issues.push(...prefixIssues(key, result.issues));
            }
            payload.value[outKey] = result.value;
          }
        }
      }
      let unrecognized;
      for (const key in input) {
        if (!recordKeys.has(key)) {
          if (def.mode === "loose") {
            if (key === "__proto__")
              continue;
            payload.value[key] = input[key];
          } else {
            unrecognized = unrecognized ?? [];
            unrecognized.push(key);
          }
        }
      }
      if (unrecognized && unrecognized.length > 0) {
        payload.issues.push({
          code: "unrecognized_keys",
          input,
          inst,
          keys: unrecognized,
          continue: true
        });
      }
    } else {
      payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
      let unrecognized;
      for (const key of Reflect.ownKeys(input)) {
        if (key === "__proto__")
          continue;
        if (!Object.prototype.propertyIsEnumerable.call(input, key))
          continue;
        let keyResult = def.keyType._zod.run({ value: key, issues: [] }, ctx);
        if (keyResult instanceof Promise) {
          throw new Error("Async schemas not supported in object keys currently");
        }
        const checkNumericKey = typeof key === "string" && number.test(key) && keyResult.issues.length;
        if (checkNumericKey) {
          const retryResult = def.keyType._zod.run({ value: Number(key), issues: [] }, ctx);
          if (retryResult instanceof Promise) {
            throw new Error("Async schemas not supported in object keys currently");
          }
          if (retryResult.issues.length === 0) {
            keyResult = retryResult;
          }
        }
        if (keyResult.issues.length) {
          if (def.mode === "loose") {
            payload.value[key] = input[key];
          } else if (values) {
            unrecognized = unrecognized ?? [];
            unrecognized.push(key);
          } else {
            payload.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
              input: key,
              path: [key],
              inst
            });
          }
          continue;
        }
        const outKey = keyResult.value;
        if (outKey === "__proto__")
          continue;
        const result = def.valueType._zod.run({ value: input[key], issues: [] }, ctx);
        if (result instanceof Promise) {
          proms.push(result.then((result) => {
            if (result.issues.length) {
              payload.issues.push(...prefixIssues(key, result.issues));
            }
            payload.value[outKey] = result.value;
          }));
        } else {
          if (result.issues.length) {
            payload.issues.push(...prefixIssues(key, result.issues));
          }
          payload.value[outKey] = result.value;
        }
      }
      if (unrecognized && unrecognized.length > 0) {
        payload.issues.push({
          code: "unrecognized_keys",
          input,
          inst,
          keys: unrecognized,
          continue: true
        });
      }
    }
    if (proms.length) {
      return Promise.all(proms).then(() => payload);
    }
    return payload;
  };
});
var $ZodEnum = /* @__PURE__ */ $constructor("$ZodEnum", (inst, def) => {
  $ZodType.init(inst, def);
  const values = getEnumValues(def.entries);
  const valuesSet = new Set(values);
  inst._zod.values = valuesSet;
  defineLazyInternal(inst, "pattern", (zod) => {
    const patternValues = getEnumValues(zod.def.entries).filter((k) => propertyKeyTypes.has(typeof k));
    return new RegExp(patternValues.length ? `^(${patternValues.map((o) => escapeRegex(o.toString())).join("|")})$` : "^[^\\s\\S]$");
  });
  inst._zod.parse = (payload, _ctx) => {
    const input = payload.value;
    if (valuesSet.has(input)) {
      return payload;
    }
    payload.issues.push({
      code: "invalid_value",
      values,
      input,
      inst
    });
    return payload;
  };
});
var $ZodLiteral = /* @__PURE__ */ $constructor("$ZodLiteral", (inst, def) => {
  $ZodType.init(inst, def);
  const values = new Set(def.values);
  inst._zod.values = values;
  defineLazyInternal(inst, "pattern", (zod) => {
    const vals = zod.def.values;
    return new RegExp(vals.length ? `^(${vals.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
  });
  inst._zod.parse = (payload, _ctx) => {
    const input = payload.value;
    if (values.has(input)) {
      return payload;
    }
    payload.issues.push({
      code: "invalid_value",
      values: def.values,
      input,
      inst
    });
    return payload;
  };
});
var $ZodTransform = /* @__PURE__ */ $constructor("$ZodTransform", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.optin = "optional";
  globalConfig.memoizer?.guard(inst);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      throw new $ZodEncodeError(inst.constructor.name);
    }
    const _out = def.transform(payload.value, payload);
    if (ctx.async) {
      const output = _out instanceof Promise ? _out : Promise.resolve(_out);
      return output.then((output) => {
        payload.value = output;
        return payload;
      });
    }
    if (_out instanceof Promise) {
      throw new $ZodAsyncError;
    }
    payload.value = _out;
    return payload;
  };
});
function handleOptionalResult(payload, result) {
  payload.value = result.issues.length ? undefined : result.value;
  return payload;
}
var $ZodOptional = /* @__PURE__ */ $constructor("$ZodOptional", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
  inst._zod.optout = "optional";
  defineLazyInternal(inst, "values", (zod) => {
    const values = zod.def.innerType._zod.values;
    return values ? new Set([...values, undefined]) : undefined;
  });
  defineLazyInternal(inst, "pattern", (zod) => {
    const pattern = zod.def.innerType._zod.pattern;
    return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : undefined;
  });
  inst._zod.parse = (payload, ctx) => {
    if (payload.value === undefined) {
      if (def.innerType._zod.optin !== "defaulted")
        return payload;
      const result = def.innerType._zod.run({ value: payload.value, issues: [] }, ctx);
      if (result instanceof Promise)
        return result.then((result) => handleOptionalResult(payload, result));
      return handleOptionalResult(payload, result);
    }
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodExactOptional = /* @__PURE__ */ $constructor("$ZodExactOptional", (inst, def) => {
  $ZodOptional.init(inst, def);
  defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
  defineLazyInternal(inst, "pattern", (zod) => zod.def.innerType._zod.pattern);
  inst._zod.parse = (payload, ctx) => {
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodNullable = /* @__PURE__ */ $constructor("$ZodNullable", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin);
  defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
  defineLazyInternal(inst, "pattern", (zod) => {
    const pattern = zod.def.innerType._zod.pattern;
    return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : undefined;
  });
  defineLazyInternal(inst, "values", (zod) => {
    return zod.def.innerType._zod.values ? new Set([...zod.def.innerType._zod.values, null]) : undefined;
  });
  inst._zod.parse = (payload, ctx) => {
    if (payload.value === null)
      return payload;
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodDefault = /* @__PURE__ */ $constructor("$ZodDefault", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.optin = "defaulted";
  defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    if (payload.value === undefined) {
      payload.value = def.defaultValue;
      return payload;
    }
    const result = def.innerType._zod.run(payload, ctx);
    if (result instanceof Promise) {
      return result.then((result) => handleDefaultResult(result, def));
    }
    return handleDefaultResult(result, def);
  };
});
function handleDefaultResult(payload, def) {
  if (payload.value === undefined) {
    payload.value = def.defaultValue;
  }
  return payload;
}
var $ZodPrefault = /* @__PURE__ */ $constructor("$ZodPrefault", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.optin = "defaulted";
  defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    if (payload.value === undefined) {
      payload.value = def.defaultValue;
    }
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodNonOptional = /* @__PURE__ */ $constructor("$ZodNonOptional", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazyInternal(inst, "values", (zod) => {
    const v = zod.def.innerType._zod.values;
    return v ? new Set([...v].filter((x) => x !== undefined)) : undefined;
  });
  inst._zod.parse = (payload, ctx) => {
    const result = def.innerType._zod.run(payload, ctx);
    if (result instanceof Promise) {
      return result.then((result) => handleNonOptionalResult(result, inst));
    }
    return handleNonOptionalResult(result, inst);
  };
});
function handleNonOptionalResult(payload, inst) {
  if (!payload.issues.length && payload.value === undefined) {
    payload.issues.push({
      code: "invalid_type",
      expected: "nonoptional",
      input: payload.value,
      inst
    });
  }
  return payload;
}
function handleCatchResult(payload, result, def, ctx) {
  if (!result.issues.length) {
    payload.value = result.value;
    if (result.memo)
      payload.memo = true;
    return payload;
  }
  payload.value = def.catchValue({
    ...result,
    value: payload.value,
    error: {
      issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config()))
    },
    input: payload.value
  });
  return payload;
}
var $ZodCatch = /* @__PURE__ */ $constructor("$ZodCatch", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
  defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
  defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    const result = def.innerType._zod.run({ value: payload.value, issues: [] }, ctx);
    if (result instanceof Promise) {
      return result.then((result) => handleCatchResult(payload, result, def, ctx));
    }
    return handleCatchResult(payload, result, def, ctx);
  };
});
var $ZodPipe = /* @__PURE__ */ $constructor("$ZodPipe", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
  defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
  defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
  defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      const right = def.out._zod.run(payload, ctx);
      if (right instanceof Promise) {
        return right.then((right) => handlePipeResult(right, def.in, ctx));
      }
      return handlePipeResult(right, def.in, ctx);
    }
    const left = def.in._zod.run(payload, ctx);
    if (left instanceof Promise) {
      return left.then((left) => handlePipeResult(left, def.out, ctx));
    }
    return handlePipeResult(left, def.out, ctx);
  };
});
function handlePipeResult(left, next, ctx) {
  if (left.issues.some((iss) => iss.code !== "unrecognized_keys")) {
    left.aborted = true;
    return left;
  }
  return next._zod.run({ value: left.value, issues: left.issues }, ctx);
}
var $ZodReadonly = /* @__PURE__ */ $constructor("$ZodReadonly", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazyInternal(inst, "propValues", (zod) => zod.def.innerType._zod.propValues);
  defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
  defineLazyInternal(inst, "optin", (zod) => zod.def.innerType?._zod?.optin);
  defineLazyInternal(inst, "optout", (zod) => zod.def.innerType?._zod?.optout);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    const result = def.innerType._zod.run(payload, ctx);
    if (result instanceof Promise) {
      return result.then(handleReadonlyResult);
    }
    return handleReadonlyResult(result);
  };
});
function handleReadonlyResult(payload) {
  if (!payload.memo)
    payload.value = Object.freeze(payload.value);
  return payload;
}
var $ZodCustom = /* @__PURE__ */ $constructor("$ZodCustom", (inst, def) => {
  $ZodCheck.init(inst, def);
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, _) => {
    return payload;
  };
  inst._zod.check = (payload) => {
    const input = payload.value;
    const r = def.fn(input);
    if (r instanceof Promise) {
      return r.then((r) => handleRefineResult(r, payload, input, inst));
    }
    handleRefineResult(r, payload, input, inst);
    return;
  };
});
function handleRefineResult(result, payload, input, inst) {
  if (!result) {
    const _iss = {
      code: "custom",
      input,
      inst,
      path: [...inst._zod.def.path ?? []],
      continue: !inst._zod.def.abort
    };
    if (inst._zod.def.params)
      _iss.params = inst._zod.def.params;
    payload.issues.push(issue(_iss));
  }
}
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/memoizer.js
class $ZodCyclicError extends Error {
  constructor() {
    super(`Cannot parse a reference cycle that closes through a transform`);
    this.name = "ZodCyclicError";
  }
}
var STATE = "~memo";
var NO_ISSUES = [];
function isRef(value) {
  return value !== null && typeof value === "object";
}
function cloneIssues(issues) {
  return issues.map((iss) => iss.path ? { ...iss, path: iss.path.slice() } : { ...iss });
}
var recursive = /* @__PURE__ */ new WeakMap;
var NONE = 0;
var ASSUMED = 1;
var PROVEN = 2;
function isRecursive(inst, stack, resolve) {
  const cached = recursive.get(inst);
  if (cached !== undefined)
    return cached ? PROVEN : NONE;
  if (stack.has(inst))
    return PROVEN;
  stack.add(inst);
  let result = NONE;
  const check = (child) => {
    if (result !== PROVEN && child?._zod) {
      const answer = isRecursive(child, stack, resolve);
      if (answer > result)
        result = answer;
    }
  };
  const shape = (sh, spread) => {
    let answer = NONE;
    for (const key of Reflect.ownKeys(sh)) {
      const desc = Object.getOwnPropertyDescriptor(sh, key);
      if (spread && !desc.enumerable)
        continue;
      const child = desc.get ? ASSUMED : desc.value?._zod ? isRecursive(desc.value, stack, resolve) : NONE;
      if (child > answer)
        answer = child;
    }
    return answer;
  };
  const merge = (answer) => {
    if (answer > result)
      result = answer;
  };
  const def = inst._zod.def;
  const kind = def.type;
  switch (kind) {
    case "object": {
      const raw = rawShape(def);
      merge(raw ? shape(raw, true) : ASSUMED);
      check(def.catchall);
      break;
    }
    case "array":
      check(def.element);
      break;
    case "tuple":
      for (const el of def.items)
        check(el);
      check(def.rest);
      break;
    case "record":
    case "map":
      check(def.keyType);
      check(def.valueType);
      break;
    case "set":
      check(def.valueType);
      break;
    case "union":
      for (const el of def.options)
        check(el);
      break;
    case "intersection":
      check(def.left);
      check(def.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      check(def.innerType);
      break;
    case "pipe":
      check(def.in);
      check(def.out);
      break;
    case "function":
      check(def.input);
      check(def.output);
      break;
    case "lazy": {
      const inner = def._cachedInner ?? (resolve ? inst._zod.innerType : undefined);
      merge(inner ? isRecursive(inner, stack, false) : ASSUMED);
      break;
    }
    case "template_literal":
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default: {
      for (const key in def) {
        const desc = Object.getOwnPropertyDescriptor(def, key);
        if (!desc || desc.get)
          continue;
        const value = desc.value;
        if (!value || typeof value !== "object")
          continue;
        if (value._zod)
          check(value);
        else if (Array.isArray(value))
          for (const el of value)
            check(el);
      }
    }
  }
  stack.delete(inst);
  return settle(inst, result);
}
function settle(inst, answer) {
  if (answer !== ASSUMED)
    recursive.set(inst, answer === PROVEN);
  return answer;
}
function bucketFor(state, inst) {
  let bucket = state.buckets.get(inst);
  if (!bucket) {
    bucket = new WeakMap;
    state.buckets.set(inst, bucket);
  }
  return bucket;
}
var handoff;
var open2 = [];
var memo = {
  alloc(_inst, payload, empty) {
    const bucket = handoff;
    if (!bucket)
      return empty;
    handoff = undefined;
    const entry = { value: empty, issues: null };
    bucket.set(payload.value, entry);
    open2.push(entry);
    return empty;
  },
  guard(inst) {
    var _a;
    (_a = inst._zod).deferred ?? (_a.deferred = []);
    inst._zod.deferred.push(() => {
      const base = inst._zod.parse;
      const wrapped = (payload, ctx) => {
        if (ctx.direction !== "backward" && isBackEdge(ctx, payload.value))
          throw new $ZodCyclicError;
        return base(payload, ctx);
      };
      inst._zod.parse = wrapped;
      if (inst._zod.run === base)
        inst._zod.run = wrapped;
    });
  },
  attach(inst) {
    var _a;
    let isRecursiveInst;
    let rechecked = false;
    let lastCtx;
    let lastBucket;
    (_a = inst._zod).deferred ?? (_a.deferred = []);
    inst._zod.deferred.push(() => {
      const base = inst._zod.parse;
      const wrapped = (payload, ctx) => {
        if (isRecursiveInst === undefined) {
          const walked = isRecursive(inst, new Set, false);
          if (walked === NONE) {
            inst._zod.parse = base;
            if (inst._zod.run === wrapped)
              inst._zod.run = base;
            return base(payload, ctx);
          }
          if (walked === PROVEN || rechecked)
            isRecursiveInst = true;
          else
            rechecked = true;
        }
        const input = payload.value;
        if (!isRef(input))
          return base(payload, ctx);
        let state = ctx[STATE];
        if (!state) {
          state = { buckets: new WeakMap, backEdges: undefined };
          ctx[STATE] = state;
        }
        let bucket;
        if (lastCtx === ctx) {
          bucket = lastBucket;
        } else {
          bucket = bucketFor(state, inst);
          lastCtx = ctx;
          lastBucket = bucket;
        }
        const hit = bucket.get(input);
        if (hit) {
          payload.value = hit.value;
          if (hit.issues) {
            if (hit.issues.length)
              payload.issues.push(...cloneIssues(hit.issues));
          } else {
            payload.memo = true;
            state.backEdges ?? (state.backEdges = new WeakSet);
            state.backEdges.add(hit.value);
          }
          return payload;
        }
        handoff = bucket;
        const depth = open2.length;
        const result = base(payload, ctx);
        handoff = undefined;
        const entry = open2.length > depth ? open2.pop() : undefined;
        if (result instanceof Promise) {
          return result.then((r) => {
            if (entry)
              entry.issues = r.issues.length ? cloneIssues(r.issues) : NO_ISSUES;
            return r;
          });
        }
        if (entry)
          entry.issues = result.issues.length ? cloneIssues(result.issues) : NO_ISSUES;
        return result;
      };
      inst._zod.parse = wrapped;
      if (inst._zod.run === base)
        inst._zod.run = wrapped;
    });
  }
};
function memoizer() {
  return memo;
}
function isBackEdge(ctx, value) {
  const backEdges = ctx[STATE]?.backEdges;
  return backEdges !== undefined && isRef(value) && backEdges.has(value);
}
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/locales/en.js
var error = () => {
  const Sizable = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function getSizing(origin) {
    return Sizable[origin] ?? null;
  }
  const FormatDictionary = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    currency_code: "currency code",
    credit_card: "credit card number",
    iban: "IBAN",
    jwt: "JWT",
    template_literal: "input"
  };
  const TypeDictionary = {
    nan: "NaN"
  };
  function getTypeName(type, input) {
    if (type === "number" && typeof input === "number" && !Number.isFinite(input)) {
      return String(input);
    }
    return TypeDictionary[type] ?? type;
  }
  return (issue) => {
    switch (issue.code) {
      case "invalid_type": {
        const expected = getTypeName(issue.expected);
        const receivedType = parsedType(issue.input);
        const received = getTypeName(receivedType, issue.input);
        return `Invalid input: expected ${expected}, received ${received}`;
      }
      case "invalid_value":
        if (issue.values.length === 1)
          return `Invalid input: expected ${stringifyPrimitive(issue.values[0])}`;
        return `Invalid option: expected one of ${joinValues(issue.values, "|")}`;
      case "too_big": {
        const adj = issue.exact ? "exactly " : issue.inclusive ? "<=" : "<";
        const sizing = getSizing(issue.origin);
        if (sizing)
          return `Too big: expected ${issue.origin ?? "value"} to have ${adj}${issue.maximum.toString()} ${sizing.unit ?? "elements"}`;
        return `Too big: expected ${issue.origin ?? "value"} to be ${adj}${issue.maximum.toString()}`;
      }
      case "too_small": {
        const adj = issue.exact ? "exactly " : issue.inclusive ? ">=" : ">";
        const sizing = getSizing(issue.origin);
        if (sizing) {
          return `Too small: expected ${issue.origin} to have ${adj}${issue.minimum.toString()} ${sizing.unit}`;
        }
        return `Too small: expected ${issue.origin} to be ${adj}${issue.minimum.toString()}`;
      }
      case "invalid_format": {
        const _issue = issue;
        if (_issue.format === "starts_with") {
          return `Invalid string: must start with "${_issue.prefix}"`;
        }
        if (_issue.format === "ends_with")
          return `Invalid string: must end with "${_issue.suffix}"`;
        if (_issue.format === "includes")
          return `Invalid string: must include "${_issue.includes}"`;
        if (_issue.format === "regex")
          return `Invalid string: must match pattern ${_issue.pattern}`;
        return `Invalid ${FormatDictionary[_issue.format] ?? issue.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${issue.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${issue.keys.length > 1 ? "s" : ""}: ${joinValues(issue.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${issue.origin}`;
      case "invalid_union":
        if (issue.options && Array.isArray(issue.options) && issue.options.length > 0) {
          const opts = issue.options.map((o) => `'${o}'`).join(" | ");
          return `Invalid discriminator value. Expected ${opts}`;
        }
        if (issue.inclusive === false) {
          return "Invalid input: more than one option matched";
        }
        return "Invalid input";
      case "invalid_element":
        return `Invalid value in ${issue.origin}`;
      default:
        return `Invalid input`;
    }
  };
};
function en_default() {
  return {
    localeError: error()
  };
}
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/registries.js
var _a2;
class $ZodRegistry {
  constructor() {
    this._map = new WeakMap;
    this._idmap = new Map;
  }
  add(schema, ..._meta) {
    const meta = _meta[0];
    this._map.set(schema, meta);
    if (meta && typeof meta === "object" && "id" in meta) {
      this._idmap.set(meta.id, schema);
    }
    return this;
  }
  clear() {
    this._map = new WeakMap;
    this._idmap = new Map;
    return this;
  }
  remove(schema) {
    const meta = this._map.get(schema);
    if (meta && typeof meta === "object" && "id" in meta) {
      this._idmap.delete(meta.id);
    }
    this._map.delete(schema);
    return this;
  }
  get(schema) {
    const p = schema._zod.parent;
    if (p) {
      const pm = { ...this.get(p) ?? {} };
      delete pm.id;
      const f = { ...pm, ...this._map.get(schema) };
      return Object.keys(f).length ? f : undefined;
    }
    return this._map.get(schema);
  }
  has(schema) {
    return this._map.has(schema);
  }
}
function registry() {
  return new $ZodRegistry;
}
(_a2 = globalThis).__zod_globalRegistry ?? (_a2.__zod_globalRegistry = registry());
var globalRegistry = globalThis.__zod_globalRegistry;
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/api.js
function snapshotChecks(def) {
  if (def.checks)
    def.checks = [...def.checks];
  return def;
}
function _string(Class, params) {
  return new Class(snapshotChecks({ type: "string", ...normalizeParams(params) }));
}
function _email(Class, params) {
  return new Class({
    type: "string",
    format: "email",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _guid(Class, params) {
  return new Class({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _uuid(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _uuidv4(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    version: "v4",
    ...normalizeParams(params)
  });
}
function _uuidv6(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    version: "v6",
    ...normalizeParams(params)
  });
}
function _uuidv7(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    version: "v7",
    ...normalizeParams(params)
  });
}
function _url(Class, params) {
  return new Class({
    type: "string",
    format: "url",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _emoji2(Class, params) {
  return new Class({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _nanoid(Class, params) {
  return new Class({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cuid(Class, params) {
  return new Class({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cuid2(Class, params) {
  return new Class({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ulid(Class, params) {
  return new Class({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _xid(Class, params) {
  return new Class({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ksuid(Class, params) {
  return new Class({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ipv4(Class, params) {
  return new Class({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ipv6(Class, params) {
  return new Class({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cidrv4(Class, params) {
  return new Class({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cidrv6(Class, params) {
  return new Class({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _base64(Class, params) {
  return new Class({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _base64url(Class, params) {
  return new Class({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _e164(Class, params) {
  return new Class({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _jwt(Class, params) {
  return new Class({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _isoDateTime(Class, params) {
  return new Class({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: false,
    local: false,
    precision: null,
    ...normalizeParams(params)
  });
}
function _isoDate(Class, params) {
  return new Class({
    type: "string",
    format: "date",
    check: "string_format",
    ...normalizeParams(params)
  });
}
function _isoTime(Class, params) {
  return new Class({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...normalizeParams(params)
  });
}
function _isoDuration(Class, params) {
  return new Class({
    type: "string",
    format: "duration",
    check: "string_format",
    ...normalizeParams(params)
  });
}
function _number(Class, params) {
  return new Class(snapshotChecks({ type: "number", checks: [], ...normalizeParams(params) }));
}
function _int(Class, params) {
  return new Class({
    type: "number",
    check: "number_format",
    abort: false,
    format: "safeint",
    ...normalizeParams(params)
  });
}
function _boolean(Class, params) {
  return new Class({
    type: "boolean",
    ...normalizeParams(params)
  });
}
function _unknown(Class) {
  return new Class({
    type: "unknown"
  });
}
function _never(Class, params) {
  return new Class({
    type: "never",
    ...normalizeParams(params)
  });
}
function _lt(value, params) {
  return new $ZodCheckLessThan({
    check: "less_than",
    ...normalizeParams(params),
    value,
    inclusive: false
  });
}
function _lte(value, params) {
  return new $ZodCheckLessThan({
    check: "less_than",
    ...normalizeParams(params),
    value,
    inclusive: true
  });
}
function _gt(value, params) {
  return new $ZodCheckGreaterThan({
    check: "greater_than",
    ...normalizeParams(params),
    value,
    inclusive: false
  });
}
function _gte(value, params) {
  return new $ZodCheckGreaterThan({
    check: "greater_than",
    ...normalizeParams(params),
    value,
    inclusive: true
  });
}
function _multipleOf(value, params) {
  return new $ZodCheckMultipleOf({
    check: "multiple_of",
    ...normalizeParams(params),
    value
  });
}
function _maxLength(maximum, params) {
  const ch = new $ZodCheckMaxLength({
    check: "max_length",
    ...normalizeParams(params),
    maximum
  });
  return ch;
}
function _minLength(minimum, params) {
  return new $ZodCheckMinLength({
    check: "min_length",
    ...normalizeParams(params),
    minimum
  });
}
function _length(length, params) {
  return new $ZodCheckLengthEquals({
    check: "length_equals",
    ...normalizeParams(params),
    length
  });
}
function _regex(pattern, params) {
  return new $ZodCheckRegex({
    check: "string_format",
    format: "regex",
    ...normalizeParams(params),
    pattern
  });
}
function _lowercase(params) {
  return new $ZodCheckLowerCase({
    check: "string_format",
    format: "lowercase",
    ...normalizeParams(params)
  });
}
function _uppercase(params) {
  return new $ZodCheckUpperCase({
    check: "string_format",
    format: "uppercase",
    ...normalizeParams(params)
  });
}
function _includes(includes, params) {
  return new $ZodCheckIncludes({
    check: "string_format",
    format: "includes",
    ...normalizeParams(params),
    includes
  });
}
function _startsWith(prefix, params) {
  return new $ZodCheckStartsWith({
    check: "string_format",
    format: "starts_with",
    ...normalizeParams(params),
    prefix
  });
}
function _endsWith(suffix, params) {
  return new $ZodCheckEndsWith({
    check: "string_format",
    format: "ends_with",
    ...normalizeParams(params),
    suffix
  });
}
function _properties(shape, params) {
  return new $ZodCheckProperties({
    check: "properties",
    shape,
    ...normalizeParams(params)
  });
}
function _overwrite(tx) {
  return new $ZodCheckOverwrite({
    check: "overwrite",
    tx
  });
}
function _normalize(form) {
  return _overwrite((input) => input.normalize(form));
}
function _trim() {
  return _overwrite((input) => input.trim());
}
function _toLowerCase() {
  return _overwrite((input) => input.toLowerCase());
}
function _toUpperCase() {
  return _overwrite((input) => input.toUpperCase());
}
function _slugify() {
  return _overwrite((input) => slugify(input));
}
function _array(Class, element, params) {
  return new Class({
    type: "array",
    element,
    ...normalizeParams(params)
  });
}
function _refine(Class, fn, _params) {
  const schema = new Class({
    type: "custom",
    check: "custom",
    fn,
    ...normalizeParams(_params)
  });
  return schema;
}
function _superRefine(fn, params) {
  const ch = _check((payload) => {
    payload.addIssue = (issue2) => {
      if (typeof issue2 === "string") {
        payload.issues.push(issue(issue2, payload.value, ch._zod.def));
      } else {
        const _issue = issue2;
        if (_issue.fatal)
          _issue.continue = false;
        _issue.code ?? (_issue.code = "custom");
        if (!("input" in _issue))
          _issue.input = payload.value;
        _issue.inst ?? (_issue.inst = ch);
        _issue.continue ?? (_issue.continue = !ch._zod.def.abort);
        payload.issues.push(issue(_issue));
      }
    };
    return fn(payload.value, payload);
  }, params);
  return ch;
}
function _check(fn, params) {
  const ch = new $ZodCheck({
    check: "custom",
    ...normalizeParams(params)
  });
  ch._zod.check = fn;
  return ch;
}
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/to-json-schema.js
function assignProps(target, ...sources) {
  for (const source of sources) {
    for (const key of Reflect.ownKeys(source)) {
      if (Object.prototype.propertyIsEnumerable.call(source, key)) {
        assignProp(target, key, source[key]);
      }
    }
  }
  return target;
}
function initializeContext(params) {
  let target = params?.target ?? "draft-2020-12";
  if (target === "draft-4")
    target = "draft-04";
  if (target === "draft-7")
    target = "draft-07";
  return {
    processors: params.processors ?? {},
    metadataRegistry: params?.metadata ?? globalRegistry,
    target,
    unrepresentable: params?.unrepresentable ?? "throw",
    override: params?.override ?? (() => {}),
    io: params?.io ?? "output",
    counter: 0,
    seen: new Map,
    sharedDefsExtractedFor: undefined,
    sharedEmitDoneFor: undefined,
    cycles: params?.cycles ?? "ref",
    reused: params?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: params?.external ?? undefined
  };
}
function handleUnrepresentable(schema, ctx, json, params, message) {
  const result = typeof ctx.unrepresentable === "function" ? ctx.unrepresentable({ zodSchema: schema, path: params.path, message }) : ctx.unrepresentable;
  if (result === "any")
    return false;
  if (result === undefined || result === "throw")
    throw new Error(message);
  Object.assign(json, result);
  return true;
}
function processSchema(schema, ctx, _params = { path: [], schemaPath: [] }) {
  var _a;
  const def = schema._zod.def;
  const seen = ctx.seen.get(schema);
  if (seen) {
    seen.count++;
    const isCycle = _params.schemaPath.includes(schema);
    if (isCycle) {
      seen.cycle = _params.path;
    }
    return seen.schema;
  }
  const result = { schema: {}, count: 1, cycle: undefined, path: _params.path };
  ctx.seen.set(schema, result);
  ctx.sharedDefsExtractedFor = undefined;
  ctx.sharedEmitDoneFor = undefined;
  const overrideSchema = schema._zod.toJSONSchema?.();
  if (overrideSchema) {
    result.schema = overrideSchema;
  } else {
    const params = {
      ..._params,
      schemaPath: [..._params.schemaPath, schema],
      path: _params.path
    };
    if (schema._zod.processJSONSchema) {
      schema._zod.processJSONSchema(ctx, result.schema, params);
    } else {
      const _json = result.schema;
      const processor = ctx.processors[def.type];
      if (!processor) {
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
      }
      processor(schema, ctx, _json, params);
    }
    const parent = schema._zod.parent;
    if (parent) {
      if (!result.ref)
        result.ref = parent;
      processSchema(parent, ctx, params);
      ctx.seen.get(parent).isParent = true;
    }
  }
  const meta = ctx.metadataRegistry.get(schema);
  if (meta)
    assignProps(result.schema, meta);
  if (ctx.io === "input" && isTransforming(schema)) {
    delete result.schema.examples;
    delete result.schema.default;
  }
  if (ctx.io === "input" && "_prefault" in result.schema)
    (_a = result.schema).default ?? (_a.default = result.schema._prefault);
  delete result.schema._prefault;
  const _result = ctx.seen.get(schema);
  return _result.schema;
}
function encodeJSONPointerSegment(segment) {
  return segment.replace(/~/g, "~0").replace(/\//g, "~1");
}
function extractDefs(ctx, schema) {
  const root = ctx.seen.get(schema);
  if (!root)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (ctx.external && ctx.sharedDefsExtractedFor === ctx.external)
    return;
  const idToSchema = new Map;
  for (const entry of ctx.seen.entries()) {
    const id = ctx.metadataRegistry.get(entry[0])?.id;
    if (id) {
      const existing = idToSchema.get(id);
      if (existing && existing !== entry[0]) {
        throw new Error(`Duplicate schema id "${id}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      }
      idToSchema.set(id, entry[0]);
    }
  }
  const makeURI = (entry) => {
    const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
    if (ctx.external) {
      const externalId = ctx.external.registry.get(entry[0])?.id;
      const uriGenerator = ctx.external.uri ?? ((id) => id);
      if (externalId) {
        return { ref: uriGenerator(externalId) };
      }
      const id = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
      entry[1].defId = id;
      return { defId: id, ref: `${uriGenerator("__shared")}#/${defsSegment}/${encodeJSONPointerSegment(id)}` };
    }
    const uriPrefix = `#`;
    const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
    if (entry[1] === root && !entry[1].schema.id) {
      return { ref: uriPrefix };
    }
    const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
    return { defId, ref: defUriPrefix + encodeJSONPointerSegment(defId) };
  };
  const extractToDef = (entry) => {
    if (entry[1].schema.$ref) {
      return;
    }
    const seen = entry[1];
    const { ref, defId } = makeURI(entry);
    seen.def = { ...seen.schema };
    if (defId)
      seen.defId = defId;
    const schema = seen.schema;
    for (const key in schema) {
      delete schema[key];
    }
    schema.$ref = ref;
  };
  if (ctx.cycles === "throw") {
    for (const entry of ctx.seen.entries()) {
      const seen = entry[1];
      if (seen.cycle) {
        throw new Error("Cycle detected: " + `#/${seen.cycle?.join("/")}/<root>` + '\n\nSet the `cycles` parameter to `"ref"` to resolve cyclical schemas with defs.');
      }
    }
  }
  for (const entry of ctx.seen.entries()) {
    const seen = entry[1];
    if (schema === entry[0]) {
      extractToDef(entry);
      continue;
    }
    if (ctx.external) {
      const ext = ctx.external.registry.get(entry[0])?.id;
      if (schema !== entry[0] && ext) {
        extractToDef(entry);
        continue;
      }
    }
    const id = ctx.metadataRegistry.get(entry[0])?.id;
    if (id) {
      extractToDef(entry);
      continue;
    }
    if (seen.cycle) {
      extractToDef(entry);
      continue;
    }
    if (seen.count > 1) {
      if (ctx.reused === "ref") {
        extractToDef(entry);
      }
    }
  }
  if (ctx.external)
    ctx.sharedDefsExtractedFor = ctx.external;
}
function compactTypeUnion(schema) {
  const options = schema.anyOf;
  if (!Array.isArray(options) || options.length === 0 || schema.type !== undefined)
    return;
  const types = [];
  for (const option of options) {
    if (!option || typeof option !== "object")
      return;
    compactTypeUnion(option);
    const keys = Object.keys(option);
    if (keys.length !== 1 || keys[0] !== "type")
      return;
    const type = option.type;
    for (const member of Array.isArray(type) ? type : [type]) {
      if (typeof member !== "string")
        return;
      if (!types.includes(member))
        types.push(member);
    }
  }
  delete schema.anyOf;
  schema.type = types.length === 1 ? types[0] : types;
}
var FOLDABLE_KEYS = new Set(["type", "properties", "required", "additionalProperties"]);
var UNION_KEYS = ["oneOf", "anyOf"];
function undeclaredConstraint(member) {
  const extra = member.additionalProperties;
  if (extra === undefined || extra === false || typeof extra !== "object" || extra === null)
    return null;
  return Object.keys(extra).length ? extra : null;
}
function foldObjects(members) {
  const objects = [];
  for (const member of members) {
    if (typeof member !== "object" || member.type !== "object")
      return null;
    for (const key in member) {
      if (!FOLDABLE_KEYS.has(key))
        return null;
    }
    objects.push(member);
  }
  const properties = {};
  const required = new Set;
  for (const object of objects) {
    for (const key in object.properties) {
      if (Object.prototype.hasOwnProperty.call(properties, key))
        continue;
      const parts = [];
      for (const other of objects) {
        const part = other.properties?.[key] ?? undeclaredConstraint(other);
        if (part === null || part === undefined)
          continue;
        if (!parts.some((seen) => JSON.stringify(seen) === JSON.stringify(part)))
          parts.push(part);
      }
      const merged = parts.length === 1 ? parts[0] : foldObjects(parts) ?? { allOf: parts };
      assignProp(properties, key, merged);
    }
    for (const key of object.required ?? [])
      required.add(key);
  }
  const folded = { type: "object", properties };
  if (required.size)
    folded.required = [...required];
  if (objects.every((object) => object.additionalProperties === false)) {
    folded.additionalProperties = false;
  } else {
    const constraints = [];
    for (const object of objects) {
      const constraint = undeclaredConstraint(object);
      if (constraint && !constraints.some((seen) => JSON.stringify(seen) === JSON.stringify(constraint)))
        constraints.push(constraint);
    }
    if (constraints.length === 1)
      folded.additionalProperties = constraints[0];
    else if (constraints.length > 1)
      folded.additionalProperties = { allOf: constraints };
  }
  return folded;
}
function foldIntersection(json) {
  const allOf = json.allOf;
  if (!Array.isArray(allOf) || allOf.length < 2)
    return;
  for (const key of FOLDABLE_KEYS)
    if (key in json)
      return;
  const unions = allOf.filter((m) => UNION_KEYS.some((k) => Array.isArray(m[k])));
  let folded = null;
  if (!unions.length) {
    folded = foldObjects(allOf);
  } else {
    const union = unions[0];
    const keyword = UNION_KEYS.find((k) => Array.isArray(union[k]));
    if (Object.keys(union).length !== 1)
      return;
    const rest = allOf.filter((m) => m !== union);
    const branches = union[keyword].map((branch) => foldObjects([...rest, branch]));
    if (branches.some((b) => !b))
      return;
    folded = { [keyword]: branches };
  }
  if (!folded)
    return;
  delete json.allOf;
  assignProps(json, folded);
}
function finalize(ctx, schema) {
  const root = ctx.seen.get(schema);
  if (!root)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const flattenRef = (zodSchema) => {
    const seen = ctx.seen.get(zodSchema);
    if (seen.ref === null)
      return;
    const schema = seen.def ?? seen.schema;
    const _cached = { ...schema };
    const ref = seen.ref;
    seen.ref = null;
    if (ref) {
      flattenRef(ref);
      const refSeen = ctx.seen.get(ref);
      const refSchema = refSeen.schema;
      if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
        schema.allOf = schema.allOf ?? [];
        schema.allOf.push(refSchema);
      } else {
        assignProps(schema, refSchema);
      }
      assignProps(schema, _cached);
      const isParentRef = zodSchema._zod.parent === ref;
      if (isParentRef) {
        for (const key in schema) {
          if (key === "$ref" || key === "allOf")
            continue;
          if (!(key in _cached)) {
            delete schema[key];
          }
        }
      }
      if (refSchema.$ref && refSeen.def) {
        for (const key in schema) {
          if (key === "$ref" || key === "allOf")
            continue;
          if (key in refSeen.def && JSON.stringify(schema[key]) === JSON.stringify(refSeen.def[key])) {
            delete schema[key];
          }
        }
      }
    }
    const parent = zodSchema._zod.parent;
    if (parent && parent !== ref) {
      flattenRef(parent);
      const parentSeen = ctx.seen.get(parent);
      if (parentSeen?.schema.$ref) {
        schema.$ref = parentSeen.schema.$ref;
        if (parentSeen.def) {
          for (const key in schema) {
            if (key === "$ref" || key === "allOf")
              continue;
            if (key in parentSeen.def && JSON.stringify(schema[key]) === JSON.stringify(parentSeen.def[key])) {
              delete schema[key];
            }
          }
        }
      }
    }
    ctx.override({
      zodSchema,
      jsonSchema: schema,
      path: seen.path ?? []
    });
  };
  if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
    for (const entry of [...ctx.seen.entries()].reverse()) {
      flattenRef(entry[0]);
    }
    if (ctx.target !== "openapi-3.0") {
      for (const entry of ctx.seen.entries()) {
        compactTypeUnion(entry[1].def ?? entry[1].schema);
      }
    }
    for (const rewrite of ctx.deferred)
      rewrite();
    if (ctx.intersections.length) {
      const carriers = new Map;
      for (const seen of ctx.seen.values()) {
        for (const json of [seen.schema, seen.def]) {
          const allOf = json?.allOf;
          if (!Array.isArray(allOf))
            continue;
          const existing = carriers.get(allOf);
          if (existing)
            existing.push(json);
          else
            carriers.set(allOf, [json]);
        }
      }
      for (const allOf of ctx.intersections) {
        for (const json of carriers.get(allOf) ?? [])
          foldIntersection(json);
      }
    }
  }
  const result = {};
  if (ctx.target === "draft-2020-12") {
    result.$schema = "https://json-schema.org/draft/2020-12/schema";
  } else if (ctx.target === "draft-07") {
    result.$schema = "http://json-schema.org/draft-07/schema#";
  } else if (ctx.target === "draft-04") {
    result.$schema = "http://json-schema.org/draft-04/schema#";
  } else if (ctx.target === "openapi-3.0") {}
  if (ctx.external?.uri) {
    const id = ctx.external.registry.get(schema)?.id;
    if (!id)
      throw new Error("Schema is missing an `id` property");
    result.$id = ctx.external.uri(id);
  }
  assignProps(result, root.defId ? root.schema : root.def ?? root.schema);
  const rootMetaId = ctx.metadataRegistry.get(schema)?.id;
  if (rootMetaId !== undefined && result.id === rootMetaId)
    delete result.id;
  const defs = ctx.external?.defs ?? {};
  if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
    for (const entry of ctx.seen.entries()) {
      const seen = entry[1];
      if (seen.def && seen.defId) {
        if (seen.def.id === seen.defId)
          delete seen.def.id;
        assignProp(defs, seen.defId, seen.def);
      }
    }
  }
  if (ctx.external)
    ctx.sharedEmitDoneFor = ctx.external;
  if (ctx.external) {} else {
    if (Object.keys(defs).length > 0) {
      if (ctx.target === "draft-2020-12") {
        result.$defs = defs;
      } else {
        result.definitions = defs;
      }
    }
  }
  try {
    const finalized = JSON.parse(JSON.stringify(result));
    Object.defineProperty(finalized, "~standard", {
      value: {
        ...schema["~standard"],
        jsonSchema: {
          input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
          output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
        }
      },
      enumerable: false,
      writable: false
    });
    return finalized;
  } catch (_err) {
    throw new Error("Error converting schema to JSON.");
  }
}
function isTransforming(_schema, _ctx) {
  const ctx = _ctx ?? { seen: new Set };
  if (ctx.seen.has(_schema))
    return false;
  ctx.seen.add(_schema);
  const def = _schema._zod.def;
  if (def.type === "transform")
    return true;
  if (def.type === "array")
    return isTransforming(def.element, ctx);
  if (def.type === "set")
    return isTransforming(def.valueType, ctx);
  if (def.type === "lazy")
    return isTransforming(def.getter(), ctx);
  if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault" || def.type === "catch") {
    return isTransforming(def.innerType, ctx);
  }
  if (def.type === "intersection") {
    return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
  }
  if (def.type === "record" || def.type === "map") {
    return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
  }
  if (def.type === "pipe") {
    if (_schema._zod.traits.has("$ZodCodec"))
      return true;
    return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
  }
  if (def.type === "object") {
    for (const key in def.shape) {
      if (isTransforming(def.shape[key], ctx))
        return true;
    }
    return false;
  }
  if (def.type === "union") {
    for (const option of def.options) {
      if (isTransforming(option, ctx))
        return true;
    }
    return false;
  }
  if (def.type === "tuple") {
    for (const item of def.items) {
      if (isTransforming(item, ctx))
        return true;
    }
    if (def.rest && isTransforming(def.rest, ctx))
      return true;
    return false;
  }
  return false;
}
var createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
  const ctx = initializeContext({ ...params, processors });
  processSchema(schema, ctx);
  extractDefs(ctx, schema);
  return finalize(ctx, schema);
};
var createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
  const { libraryOptions, target } = params ?? {};
  const ctx = initializeContext({ ...libraryOptions ?? {}, target, io, processors });
  processSchema(schema, ctx);
  extractDefs(ctx, schema);
  return finalize(ctx, schema);
};
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/core/json-schema-processors.js
var narrowMin = (agg, key, value) => {
  if (agg[key] === undefined || value > agg[key])
    agg[key] = value;
};
var narrowMax = (agg, key, value) => {
  if (agg[key] === undefined || value < agg[key])
    agg[key] = value;
};
var narrowBoth = (agg, value) => {
  narrowMin(agg, "minimum", value);
  narrowMax(agg, "maximum", value);
};
var addDivisor = (agg, value) => {
  agg.multipleOf ?? (agg.multipleOf = []);
  if (!agg.multipleOf.includes(value))
    agg.multipleOf.push(value);
};
var addPattern = (agg, pattern) => {
  agg.patterns ?? (agg.patterns = new Set);
  agg.patterns.add(pattern);
};
var intersectMime = (agg, mime) => {
  agg.mime = agg.mime ? agg.mime.filter((m) => mime.includes(m)) : [...mime];
};
var setFormat = (agg, format) => {
  agg.format = format;
  if (format.includes("int"))
    agg.isInt = true;
};
var minContributor = (agg, def) => narrowMin(agg, "minimum", def.minimum);
var maxContributor = (agg, def) => narrowMax(agg, "maximum", def.maximum);
var formatContributor = (ranges) => (agg, def) => {
  setFormat(agg, def.format);
  const [minimum, maximum] = ranges[def.format];
  narrowMin(agg, "minimum", minimum);
  narrowMax(agg, "maximum", maximum);
};
var contributors = {
  greater_than: (agg, def) => narrowMin(agg, def.inclusive ? "minimum" : "exclusiveMinimum", def.value),
  less_than: (agg, def) => narrowMax(agg, def.inclusive ? "maximum" : "exclusiveMaximum", def.value),
  multiple_of: (agg, def) => addDivisor(agg, def.value),
  number_format: formatContributor(NUMBER_FORMAT_RANGES),
  bigint_format: formatContributor(BIGINT_FORMAT_RANGES),
  min_length: minContributor,
  max_length: maxContributor,
  length_equals: (agg, def) => narrowBoth(agg, def.length),
  min_size: minContributor,
  max_size: maxContributor,
  size_equals: (agg, def) => narrowBoth(agg, def.size),
  string_format: (agg, def) => {
    setFormat(agg, def.format);
    if (def.pattern)
      addPattern(agg, def.pattern);
    if (def.format === "base64" || def.format === "base64url")
      agg.contentEncoding = def.format;
    if (def.local || def.precision === -1)
      agg.laxFormat = true;
  },
  mime_type: (agg, def) => intersectMime(agg, def.mime)
};
function aggregateChecks(schema) {
  const agg = {};
  const def = schema._zod.def;
  const list = schema._zod.traits.has("$ZodCheck") ? [schema, ...def.checks ?? []] : def.checks ?? [];
  for (const ch of list)
    contributors[ch._zod.def.check]?.(agg, ch._zod.def);
  const bag = schema._zod.bag;
  if (bag.minimum !== undefined)
    narrowMin(agg, "minimum", bag.minimum);
  if (bag.exclusiveMinimum !== undefined)
    narrowMin(agg, "exclusiveMinimum", bag.exclusiveMinimum);
  if (bag.maximum !== undefined)
    narrowMax(agg, "maximum", bag.maximum);
  if (bag.exclusiveMaximum !== undefined)
    narrowMax(agg, "exclusiveMaximum", bag.exclusiveMaximum);
  if (bag.multipleOf !== undefined)
    addDivisor(agg, bag.multipleOf);
  if (bag.format !== undefined) {
    agg.format ?? (agg.format = bag.format);
    if (bag.format.includes("int"))
      agg.isInt = true;
  }
  if (bag.mime)
    intersectMime(agg, bag.mime);
  for (const pattern of bag.patterns ?? [])
    addPattern(agg, pattern);
  return agg;
}
var formatMap = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
};
var exactPatterns = new Map([
  [base64Charset, base64],
  [base64urlCharset, base64url]
]);
var exactPattern = (p) => exactPatterns.get(p) ?? p;
var stringProcessor = (schema, ctx, _json, _params) => {
  const json = _json;
  json.type = "string";
  const { minimum, maximum, format, patterns, contentEncoding, laxFormat } = aggregateChecks(schema);
  if (typeof minimum === "number")
    json.minLength = minimum;
  if (typeof maximum === "number")
    json.maxLength = maximum;
  if (format) {
    json.format = formatMap[format] ?? format;
    if (json.format === "")
      delete json.format;
    if (format === "time" || laxFormat) {
      delete json.format;
    }
  }
  if (contentEncoding)
    json.contentEncoding = contentEncoding;
  if (patterns && patterns.size > 0) {
    const patternList = [...patterns].map(exactPattern);
    if (patternList.length === 1)
      json.pattern = patternList[0].source;
    else if (patternList.length > 1) {
      json.allOf = [
        ...patternList.map((regex) => ({
          ...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
          pattern: regex.source
        }))
      ];
    }
  }
};
var numberProcessor = (schema, ctx, _json, params) => {
  const json = _json;
  const { minimum, maximum, multipleOf, exclusiveMaximum, exclusiveMinimum, isInt } = aggregateChecks(schema);
  json.type = isInt ? "integer" : "number";
  const exMin = typeof exclusiveMinimum === "number" && exclusiveMinimum >= (minimum ?? Number.NEGATIVE_INFINITY);
  const exMax = typeof exclusiveMaximum === "number" && exclusiveMaximum <= (maximum ?? Number.POSITIVE_INFINITY);
  const legacy = ctx.target === "draft-04" || ctx.target === "openapi-3.0";
  if (exMin) {
    if (legacy) {
      json.minimum = exclusiveMinimum;
      json.exclusiveMinimum = true;
    } else {
      json.exclusiveMinimum = exclusiveMinimum;
    }
  } else if (typeof minimum === "number") {
    json.minimum = minimum;
  }
  if (exMax) {
    if (legacy) {
      json.maximum = exclusiveMaximum;
      json.exclusiveMaximum = true;
    } else {
      json.exclusiveMaximum = exclusiveMaximum;
    }
  } else if (typeof maximum === "number") {
    json.maximum = maximum;
  }
  if (multipleOf) {
    const divisors = new Set;
    for (const divisor of multipleOf) {
      if (Number.isFinite(divisor) && divisor !== 0)
        divisors.add(Math.abs(divisor));
      else
        handleUnrepresentable(schema, ctx, json, params, `A multipleOf divisor of ${divisor} cannot be represented in JSON Schema`);
    }
    const [first, ...rest] = divisors;
    if (first !== undefined)
      json.multipleOf = first;
    if (rest.length)
      json.allOf = [...json.allOf ?? [], ...rest.map((m) => ({ multipleOf: m }))];
  }
};
var booleanProcessor = (_schema, _ctx, json, _params) => {
  json.type = "boolean";
};
var neverProcessor = (_schema, _ctx, json, _params) => {
  json.not = {};
};
var unknownProcessor = (_schema, _ctx, _json, _params) => {};
var enumProcessor = (schema, _ctx, json, _params) => {
  const def = schema._zod.def;
  const values = getEnumValues(def.entries);
  if (values.length === 0) {
    json.not = {};
    return;
  }
  if (values.every((v) => typeof v === "number"))
    json.type = "number";
  if (values.every((v) => typeof v === "string"))
    json.type = "string";
  json.enum = values;
};
var literalProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  if (def.values.length === 0) {
    json.not = {};
    return;
  }
  const vals = [];
  for (const val of def.values) {
    if (val === undefined) {
      if (handleUnrepresentable(schema, ctx, json, params, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof val === "bigint") {
      if (handleUnrepresentable(schema, ctx, json, params, "BigInt literals cannot be represented in JSON Schema"))
        return;
      vals.push(Number(val));
    } else {
      vals.push(val);
    }
  }
  if (vals.length === 0) {} else if (vals.length === 1) {
    const val = vals[0];
    json.type = val === null ? "null" : typeof val;
    if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") {
      json.enum = [val];
    } else {
      json.const = val;
    }
  } else {
    if (vals.every((v) => typeof v === "number"))
      json.type = "number";
    if (vals.every((v) => typeof v === "string"))
      json.type = "string";
    if (vals.every((v) => typeof v === "boolean"))
      json.type = "boolean";
    if (vals.every((v) => v === null))
      json.type = "null";
    json.enum = vals;
  }
};
var customProcessor = (schema, ctx, json, params) => {
  handleUnrepresentable(schema, ctx, json, params, "Custom types cannot be represented in JSON Schema");
};
var transformProcessor = (schema, ctx, json, params) => {
  handleUnrepresentable(schema, ctx, json, params, "Transforms cannot be represented in JSON Schema");
};
var arrayProcessor = (schema, ctx, _json, params) => {
  const json = _json;
  const def = schema._zod.def;
  const { minimum, maximum } = aggregateChecks(schema);
  if (typeof minimum === "number")
    json.minItems = minimum;
  if (typeof maximum === "number")
    json.maxItems = maximum;
  json.type = "array";
  json.items = processSchema(def.element, ctx, {
    ...params,
    path: [...params.path, "items"]
  });
};
function inputOptin(schema) {
  const def = schema._zod.def;
  if (def.type === "pipe" && def.in._zod.traits.has("$ZodTransform")) {
    return inputOptin(def.out);
  }
  if (def.type === "catch") {
    return inputOptin(def.innerType);
  }
  return schema._zod.optin;
}
var objectProcessor = (schema, ctx, _json, params) => {
  const json = _json;
  const def = schema._zod.def;
  const shape = def.shape;
  const symbolKeys = Object.getOwnPropertySymbols(shape);
  if (symbolKeys.length && handleUnrepresentable(schema, ctx, json, params, "Symbol keys cannot be represented in JSON Schema")) {
    return;
  }
  json.type = "object";
  json.properties = {};
  for (const key in shape) {
    assignProp(json.properties, key, processSchema(shape[key], ctx, {
      ...params,
      path: [...params.path, "properties", key]
    }));
  }
  const requiredKeys = [];
  for (const key of Object.keys(shape)) {
    const field = def.shape[key];
    if (ctx.io === "input" ? inputOptin(field) === undefined : field._zod.optout === undefined) {
      requiredKeys.push(key);
    }
  }
  if (requiredKeys.length > 0) {
    json.required = requiredKeys;
  }
  if (def.catchall?._zod.def.type === "never") {
    json.additionalProperties = false;
  } else if (!def.catchall) {
    if (ctx.io === "output")
      json.additionalProperties = false;
  } else if (def.catchall) {
    json.additionalProperties = processSchema(def.catchall, ctx, {
      ...params,
      path: [...params.path, "additionalProperties"]
    });
  }
};
var unionProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  const isExclusive = def.inclusive === false;
  const options = def.options.map((x, i) => processSchema(x, ctx, {
    ...params,
    path: [...params.path, isExclusive ? "oneOf" : "anyOf", i]
  }));
  if (isExclusive) {
    json.oneOf = options;
  } else {
    json.anyOf = options;
  }
};
var intersectionProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  const a = processSchema(def.left, ctx, {
    ...params,
    path: [...params.path, "allOf", 0]
  });
  const b = processSchema(def.right, ctx, {
    ...params,
    path: [...params.path, "allOf", 1]
  });
  const isSimpleIntersection = (val) => ("allOf" in val) && Object.keys(val).length === 1;
  const allOf = [
    ...isSimpleIntersection(a) ? a.allOf : [a],
    ...isSimpleIntersection(b) ? b.allOf : [b]
  ];
  json.allOf = allOf;
  ctx.intersections.push(allOf);
};
var tupleProcessor = (schema, ctx, _json, params) => {
  const json = _json;
  const def = schema._zod.def;
  json.type = "array";
  const prefixPath = ctx.target === "draft-2020-12" ? "prefixItems" : "items";
  const restPath = ctx.target === "draft-2020-12" ? "items" : ctx.target === "openapi-3.0" ? "items" : "additionalItems";
  const prefixItems = def.items.map((x, i) => processSchema(x, ctx, {
    ...params,
    path: [...params.path, prefixPath, i]
  }));
  const rest = def.rest ? processSchema(def.rest, ctx, {
    ...params,
    path: [...params.path, restPath, ...ctx.target === "openapi-3.0" ? [def.items.length] : []]
  }) : null;
  let minItems = def.items.length;
  while (minItems > 0) {
    const item = def.items[minItems - 1];
    const optional = ctx.io === "input" ? inputOptin(item) !== undefined : item._zod.optout === "optional";
    if (!optional)
      break;
    minItems--;
  }
  const maxItems = def.items.length;
  const isClosed = !def.rest;
  if (ctx.target === "draft-2020-12") {
    json.prefixItems = prefixItems;
    if (isClosed) {
      json.items = false;
    } else if (rest) {
      json.items = rest;
    }
    if (minItems > 0)
      json.minItems = minItems;
    if (isClosed)
      json.maxItems = maxItems;
  } else if (ctx.target === "openapi-3.0") {
    json.items = {
      anyOf: prefixItems
    };
    if (rest) {
      json.items.anyOf.push(rest);
    }
    if (minItems > 0)
      json.minItems = minItems;
    if (isClosed)
      json.maxItems = maxItems;
  } else {
    json.items = prefixItems;
    if (isClosed) {
      json.additionalItems = false;
    } else if (rest) {
      json.additionalItems = rest;
    }
    if (minItems > 0)
      json.minItems = minItems;
    if (isClosed)
      json.maxItems = maxItems;
  }
  const { minimum, maximum } = aggregateChecks(schema);
  if (typeof minimum === "number")
    json.minItems = minimum;
  if (typeof maximum === "number")
    json.maxItems = maximum;
};
function stringifyKeyNames(bySchema, json, visited) {
  if (json.$ref) {
    if (visited.has(json))
      return json;
    visited.add(json);
    const def = bySchema.get(json)?.def;
    if (!def)
      return json;
    const inlined = stringifyKeyNames(bySchema, def, visited);
    return inlined === def ? json : inlined;
  }
  for (const keyword of ["anyOf", "oneOf"]) {
    const branches = json[keyword];
    if (!Array.isArray(branches))
      continue;
    const mapped = branches.map((branch) => stringifyKeyNames(bySchema, branch, visited));
    if (mapped.some((branch, i) => branch !== branches[i]))
      json = { ...json, [keyword]: mapped };
  }
  const types = Array.isArray(json.type) ? json.type : [json.type];
  const numericType = !types.includes("string") && types.some((t) => t === "number" || t === "integer");
  const values = json.enum ?? (json.const !== undefined ? [json.const] : undefined);
  if (!numericType && !values?.some((v) => typeof v === "number"))
    return json;
  const { minimum, maximum, exclusiveMinimum, exclusiveMaximum, multipleOf, format, id, ...rest } = json;
  if (rest.enum)
    rest.enum = rest.enum.map((v) => typeof v === "number" ? String(v) : v);
  else if (typeof rest.const === "number")
    rest.const = String(rest.const);
  if (!numericType)
    return rest;
  rest.type = "string";
  if (!values)
    rest.pattern = (types.includes("number") ? number : integer).source;
  return rest;
}
var pendingRecords = new WeakMap;
function rewriteKeyNames(ctx) {
  const bySchema = new Map;
  for (const entry of ctx.seen.values()) {
    if (entry.def && !bySchema.has(entry.schema))
      bySchema.set(entry.schema, entry);
  }
  const rewrites = new Map;
  for (const record of pendingRecords.get(ctx) ?? []) {
    const seen = ctx.seen.get(record);
    const names = (seen?.def ?? seen?.schema)?.propertyNames;
    if (!names || names === true || rewrites.has(names))
      continue;
    const rewritten = stringifyKeyNames(bySchema, names, new Set);
    if (rewritten !== names)
      rewrites.set(names, rewritten);
  }
  if (!rewrites.size)
    return;
  for (const entry of ctx.seen.values()) {
    for (const carrier of [entry.schema, entry.def]) {
      const rewritten = carrier && rewrites.get(carrier.propertyNames);
      if (rewritten)
        carrier.propertyNames = rewritten;
    }
  }
}
var recordProcessor = (schema, ctx, _json, params) => {
  const json = _json;
  const def = schema._zod.def;
  json.type = "object";
  const keyType = def.keyType;
  const patterns = aggregateChecks(keyType).patterns;
  if (def.mode === "loose" && patterns && patterns.size > 0) {
    const valueSchema = processSchema(def.valueType, ctx, {
      ...params,
      path: [...params.path, "patternProperties", "*"]
    });
    json.patternProperties = {};
    for (const pattern of patterns) {
      assignProp(json.patternProperties, exactPattern(pattern).source, valueSchema);
    }
  } else {
    if (ctx.target === "draft-07" || ctx.target === "draft-2020-12") {
      json.propertyNames = processSchema(def.keyType, ctx, {
        ...params,
        path: [...params.path, "propertyNames"]
      });
      let pending = pendingRecords.get(ctx);
      if (!pending) {
        pending = [];
        pendingRecords.set(ctx, pending);
        ctx.deferred.push(() => rewriteKeyNames(ctx));
      }
      pending.push(schema);
    }
    json.additionalProperties = processSchema(def.valueType, ctx, {
      ...params,
      path: [...params.path, "additionalProperties"]
    });
  }
  const keyValues = keyType._zod.values;
  const omittableOnInput = ctx.io === "input" && inputOptin(def.valueType) !== undefined;
  if (keyValues && !def.partial && !omittableOnInput) {
    const validKeyValues = [...keyValues].filter((v) => typeof v === "string" || typeof v === "number");
    if (validKeyValues.length > 0) {
      json.required = validKeyValues.map(String);
    }
  }
};
var nullableProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  const inner = processSchema(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  if (ctx.target === "openapi-3.0") {
    seen.ref = def.innerType;
    json.nullable = true;
  } else {
    json.anyOf = [inner, { type: "null" }];
  }
};
var nonoptionalProcessor = (schema, ctx, _json, params) => {
  const def = schema._zod.def;
  processSchema(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
};
var UNREPRESENTABLE_DEFAULT = Symbol();
function serializeDefaultValue(value, schema, ctx, json, params) {
  let unrepresentable = false;
  const serialized = JSON.stringify(value, (_, val) => {
    if (typeof val !== "bigint")
      return val;
    unrepresentable = true;
    return null;
  });
  if (!unrepresentable)
    return JSON.parse(serialized);
  handleUnrepresentable(schema, ctx, json, params, "BigInt defaults cannot be represented in JSON Schema");
  return UNREPRESENTABLE_DEFAULT;
}
var defaultProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  processSchema(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
  if (value !== UNREPRESENTABLE_DEFAULT)
    json.default = value;
};
var prefaultProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  processSchema(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  if (ctx.io !== "input")
    return;
  const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
  if (value !== UNREPRESENTABLE_DEFAULT)
    json._prefault = value;
};
var catchProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  processSchema(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  let catchValue;
  try {
    catchValue = def.catchValue(undefined);
  } catch {
    handleUnrepresentable(schema, ctx, json, params, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  json.default = catchValue;
};
var pipeProcessor = (schema, ctx, _json, params) => {
  const def = schema._zod.def;
  const inIsTransform = def.in._zod.traits.has("$ZodTransform");
  const innerType = ctx.io === "input" ? inIsTransform ? def.out : def.in : def.out;
  processSchema(innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = innerType;
};
var readonlyProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  processSchema(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  json.readOnly = true;
};
var optionalProcessor = (schema, ctx, _json, params) => {
  const def = schema._zod.def;
  processSchema(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
};
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/classic/errors.js
var _installedErrorProtos = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function _lazyMethod(proto, key, make) {
  Object.defineProperty(proto, key, {
    configurable: true,
    enumerable: false,
    get() {
      const value = make(this);
      Object.defineProperty(this, key, { value, configurable: true, writable: true });
      return value;
    },
    set(value) {
      Object.defineProperty(this, key, { value, configurable: true, writable: true });
    }
  });
}
var initializer2 = (inst, issues) => {
  $ZodError.init(inst, issues);
  inst.name = "ZodError";
  const proto = Object.getPrototypeOf(inst);
  if (_installedErrorProtos.has(proto))
    return;
  _installedErrorProtos.add(proto);
  _lazyMethod(proto, "format", (self) => (mapper) => formatError(self, mapper));
  _lazyMethod(proto, "flatten", (self) => (mapper) => flattenError(self, mapper));
  _lazyMethod(proto, "addIssue", (self) => (issue) => {
    self.issues.push(issue);
    self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
  });
  _lazyMethod(proto, "addIssues", (self) => (issues) => {
    self.issues.push(...issues);
    self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
  });
  Object.defineProperty(proto, "isEmpty", {
    configurable: true,
    enumerable: false,
    get() {
      return this.issues.length === 0;
    }
  });
};
var ZodRealError = /* @__PURE__ */ $constructor("ZodError", initializer2, undefined, {
  Parent: Error
});

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/classic/parse.js
var parse2 = /* @__PURE__ */ _parse(ZodRealError);
var parseAsync = /* @__PURE__ */ _parseAsync(ZodRealError);
var safeParse = /* @__PURE__ */ _safeParse(ZodRealError);
var safeParseAsync = /* @__PURE__ */ _safeParseAsync(ZodRealError);
var encode = /* @__PURE__ */ _encode(ZodRealError);
var decode = /* @__PURE__ */ _decode(ZodRealError);
var encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError);
var decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError);
var safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError);
var safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError);
var safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
var safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);

// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/classic/schemas.js
function _ensureDefaultLocale() {
  if (!globalConfig.localeError)
    config(en_default());
}
function _ensureDefaultMemoizer() {
  if (!globalConfig.memoizer)
    config({ memoizer: memoizer() });
}
var ZodType = /* @__PURE__ */ $constructor("ZodType", (inst, def) => {
  _ensureDefaultLocale();
  $ZodType.init(inst, def);
  inst.def = def;
  inst.type = def.type;
  return inst;
}, {
  check(...chks) {
    const def = this.def;
    return this.clone(mergeDefs(def, {
      checks: [
        ...def.checks ?? [],
        ...chks.map((ch) => typeof ch === "function" ? { _zod: { check: ch, def: { check: "custom" }, onattach: [] } } : ch)
      ]
    }), { parent: true });
  },
  with(...chks) {
    return this.check(...chks);
  },
  clone(def, params) {
    return clone(this, def, params);
  },
  brand() {
    return this;
  },
  register(reg, meta) {
    reg.add(this, meta);
    return this;
  },
  refine(check, params) {
    return this.check(refine(check, params));
  },
  superRefine(refinement, params) {
    return this.check(superRefine(refinement, params));
  },
  overwrite(fn) {
    return this.check(_overwrite(fn));
  },
  optional() {
    return optional(this);
  },
  exactOptional() {
    return exactOptional(this);
  },
  nullable() {
    return nullable(this);
  },
  nullish() {
    return optional(nullable(this));
  },
  nonoptional(params) {
    return nonoptional(this, params);
  },
  array() {
    return array(this);
  },
  or(arg) {
    return union([this, arg]);
  },
  and(arg) {
    return intersection(this, arg);
  },
  transform(tx) {
    return pipe(this, transform(tx));
  },
  default(d) {
    return _default(this, d);
  },
  prefault(d) {
    return prefault(this, d);
  },
  catch(params) {
    return _catch(this, params);
  },
  pipe(target) {
    return pipe(this, target);
  },
  readonly() {
    return readonly(this);
  },
  describe(description) {
    const cl = this.clone();
    globalRegistry.add(cl, { description });
    return cl;
  },
  meta(...args) {
    if (args.length === 0)
      return globalRegistry.get(this);
    const cl = this.clone();
    globalRegistry.add(cl, args[0]);
    return cl;
  },
  isOptional() {
    return this.safeParse(undefined).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(fn, ...args) {
    return args.length === 0 ? fn(this) : fn(this, ...args);
  },
  get "~standard"() {
    return hide(this, "~standard", {
      ...standardProps(this),
      jsonSchema: {
        input: createStandardJSONSchemaMethod(this, "input"),
        output: createStandardJSONSchemaMethod(this, "output")
      }
    });
  },
  set "~standard"(value) {
    own(this, "~standard", value);
  },
  parse: function _parse(data, params) {
    return parse2(this, data, params, { callee: _parse });
  },
  parseAsync: async function _parseAsync(data, params) {
    return await parseAsync(this, data, params, { callee: _parseAsync });
  },
  safeParse(data, params) {
    return safeParse(this, data, params);
  },
  async safeParseAsync(data, params) {
    return safeParseAsync(this, data, params);
  },
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(value) {
    own(this, "spa", value);
  },
  validate(data, params) {
    return validate(this, data, params);
  },
  validateAsync(data, params) {
    return validateAsync(this, data, params);
  },
  encode: function _encode(data, params) {
    return encode(this, data, params, { callee: _encode });
  },
  decode: function _decode(data, params) {
    return decode(this, data, params, { callee: _decode });
  },
  encodeAsync: async function _encodeAsync(data, params) {
    return await encodeAsync(this, data, params, { callee: _encodeAsync });
  },
  decodeAsync: async function _decodeAsync(data, params) {
    return await decodeAsync(this, data, params, { callee: _decodeAsync });
  },
  safeEncode(data, params) {
    return safeEncode(this, data, params);
  },
  safeDecode(data, params) {
    return safeDecode(this, data, params);
  },
  async safeEncodeAsync(data, params) {
    return safeEncodeAsync(this, data, params);
  },
  async safeDecodeAsync(data, params) {
    return safeDecodeAsync(this, data, params);
  },
  toJSONSchema(params) {
    return createToJSONSchemaMethod(this, {})(params);
  },
  get description() {
    return globalRegistry.get(this)?.description;
  },
  get _def() {
    return this._zod.def;
  }
});
var _ZodString = /* @__PURE__ */ $constructor("_ZodString", (inst, def) => {
  $ZodString.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => stringProcessor(inst, ctx, json, params);
}, /* @__PURE__ */ derived({
  format: (inst) => aggregateChecks(inst).format ?? null,
  minLength: (inst) => aggregateChecks(inst).minimum ?? null,
  maxLength: (inst) => aggregateChecks(inst).maximum ?? null
}, {
  regex(...args) {
    return this.check(_regex(...args));
  },
  includes(...args) {
    return this.check(_includes(...args));
  },
  startsWith(...args) {
    return this.check(_startsWith(...args));
  },
  endsWith(...args) {
    return this.check(_endsWith(...args));
  },
  min(...args) {
    return this.check(_minLength(...args));
  },
  max(...args) {
    return this.check(_maxLength(...args));
  },
  length(...args) {
    return this.check(_length(...args));
  },
  nonempty(...args) {
    return this.check(_minLength(1, ...args));
  },
  lowercase(params) {
    return this.check(_lowercase(params));
  },
  uppercase(params) {
    return this.check(_uppercase(params));
  },
  trim() {
    return this.check(_trim());
  },
  normalize(...args) {
    return this.check(_normalize(...args));
  },
  toLowerCase() {
    return this.check(_toLowerCase());
  },
  toUpperCase() {
    return this.check(_toUpperCase());
  },
  slugify() {
    return this.check(_slugify());
  }
}));
var ZodString = /* @__PURE__ */ $constructor("ZodString", (inst, def) => {
  $ZodString.init(inst, def);
  _ZodString.init(inst, def);
}, {
  email(params) {
    return this.check(_email(ZodEmail, params));
  },
  url(params) {
    return this.check(_url(ZodURL, params));
  },
  jwt(params) {
    return this.check(_jwt(ZodJWT, params));
  },
  emoji(params) {
    return this.check(_emoji2(ZodEmoji, params));
  },
  guid(params) {
    return this.check(_guid(ZodGUID, params));
  },
  uuid(params) {
    return this.check(_uuid(ZodUUID, params));
  },
  uuidv4(params) {
    return this.check(_uuidv4(ZodUUID, params));
  },
  uuidv6(params) {
    return this.check(_uuidv6(ZodUUID, params));
  },
  uuidv7(params) {
    return this.check(_uuidv7(ZodUUID, params));
  },
  nanoid(params) {
    return this.check(_nanoid(ZodNanoID, params));
  },
  cuid(params) {
    return this.check(_cuid(ZodCUID, params));
  },
  cuid2(params) {
    return this.check(_cuid2(ZodCUID2, params));
  },
  ulid(params) {
    return this.check(_ulid(ZodULID, params));
  },
  base64(params) {
    return this.check(_base64(ZodBase64, params));
  },
  base64url(params) {
    return this.check(_base64url(ZodBase64URL, params));
  },
  xid(params) {
    return this.check(_xid(ZodXID, params));
  },
  ksuid(params) {
    return this.check(_ksuid(ZodKSUID, params));
  },
  ipv4(params) {
    return this.check(_ipv4(ZodIPv4, params));
  },
  ipv6(params) {
    return this.check(_ipv6(ZodIPv6, params));
  },
  cidrv4(params) {
    return this.check(_cidrv4(ZodCIDRv4, params));
  },
  cidrv6(params) {
    return this.check(_cidrv6(ZodCIDRv6, params));
  },
  e164(params) {
    return this.check(_e164(ZodE164, params));
  },
  datetime(params) {
    return this.check(_isoDateTime(ZodISODateTime, params));
  },
  date(params) {
    return this.check(_isoDate(ZodISODate, params));
  },
  time(params) {
    return this.check(_isoTime(ZodISOTime, params));
  },
  duration(params) {
    return this.check(_isoDuration(ZodISODuration, params));
  }
});
function string2(params) {
  return _string(ZodString, params);
}
var ZodStringFormat = /* @__PURE__ */ $constructor("ZodStringFormat", (inst, def) => {
  $ZodStringFormat.init(inst, def);
  _ZodString.init(inst, def);
});
var ZodISODateTime = /* @__PURE__ */ $constructor("ZodISODateTime", (inst, def) => {
  $ZodISODateTime.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodISODate = /* @__PURE__ */ $constructor("ZodISODate", (inst, def) => {
  $ZodISODate.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodISOTime = /* @__PURE__ */ $constructor("ZodISOTime", (inst, def) => {
  $ZodISOTime.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodISODuration = /* @__PURE__ */ $constructor("ZodISODuration", (inst, def) => {
  $ZodISODuration.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodEmail = /* @__PURE__ */ $constructor("ZodEmail", (inst, def) => {
  $ZodEmail.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodGUID = /* @__PURE__ */ $constructor("ZodGUID", (inst, def) => {
  $ZodGUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodUUID = /* @__PURE__ */ $constructor("ZodUUID", (inst, def) => {
  $ZodUUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
function uuid2(params) {
  return _uuid(ZodUUID, params);
}
var ZodURL = /* @__PURE__ */ $constructor("ZodURL", (inst, def) => {
  $ZodURL.init(inst, def);
  ZodStringFormat.init(inst, def);
});
function url(params) {
  return _url(ZodURL, params);
}
var ZodEmoji = /* @__PURE__ */ $constructor("ZodEmoji", (inst, def) => {
  $ZodEmoji.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodNanoID = /* @__PURE__ */ $constructor("ZodNanoID", (inst, def) => {
  $ZodNanoID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCUID = /* @__PURE__ */ $constructor("ZodCUID", (inst, def) => {
  $ZodCUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCUID2 = /* @__PURE__ */ $constructor("ZodCUID2", (inst, def) => {
  $ZodCUID2.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodULID = /* @__PURE__ */ $constructor("ZodULID", (inst, def) => {
  $ZodULID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodXID = /* @__PURE__ */ $constructor("ZodXID", (inst, def) => {
  $ZodXID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodKSUID = /* @__PURE__ */ $constructor("ZodKSUID", (inst, def) => {
  $ZodKSUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodIPv4 = /* @__PURE__ */ $constructor("ZodIPv4", (inst, def) => {
  $ZodIPv4.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodIPv6 = /* @__PURE__ */ $constructor("ZodIPv6", (inst, def) => {
  $ZodIPv6.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCIDRv4 = /* @__PURE__ */ $constructor("ZodCIDRv4", (inst, def) => {
  $ZodCIDRv4.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCIDRv6 = /* @__PURE__ */ $constructor("ZodCIDRv6", (inst, def) => {
  $ZodCIDRv6.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodBase64 = /* @__PURE__ */ $constructor("ZodBase64", (inst, def) => {
  $ZodBase64.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodBase64URL = /* @__PURE__ */ $constructor("ZodBase64URL", (inst, def) => {
  $ZodBase64URL.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodE164 = /* @__PURE__ */ $constructor("ZodE164", (inst, def) => {
  $ZodE164.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodJWT = /* @__PURE__ */ $constructor("ZodJWT", (inst, def) => {
  $ZodJWT.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodNumber = /* @__PURE__ */ $constructor("ZodNumber", (inst, def) => {
  $ZodNumber.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => numberProcessor(inst, ctx, json, params);
  inst.isFinite = true;
}, /* @__PURE__ */ derived({
  minValue: (inst) => {
    const { minimum, exclusiveMinimum } = aggregateChecks(inst);
    return Math.max(minimum ?? Number.NEGATIVE_INFINITY, exclusiveMinimum ?? Number.NEGATIVE_INFINITY);
  },
  maxValue: (inst) => {
    const { maximum, exclusiveMaximum } = aggregateChecks(inst);
    return Math.min(maximum ?? Number.POSITIVE_INFINITY, exclusiveMaximum ?? Number.POSITIVE_INFINITY);
  },
  isInt: (inst) => {
    const { isInt, multipleOf } = aggregateChecks(inst);
    return !!isInt || !!multipleOf?.some(Number.isSafeInteger);
  },
  format: (inst) => aggregateChecks(inst).format ?? null
}, {
  gt(value, params) {
    return this.check(_gt(value, params));
  },
  gte(value, params) {
    return this.check(_gte(value, params));
  },
  min(value, params) {
    return this.check(_gte(value, params));
  },
  lt(value, params) {
    return this.check(_lt(value, params));
  },
  lte(value, params) {
    return this.check(_lte(value, params));
  },
  max(value, params) {
    return this.check(_lte(value, params));
  },
  int(params) {
    return this.check(int(params));
  },
  safe(params) {
    return this.check(int(params));
  },
  positive(params) {
    return this.check(_gt(0, params));
  },
  nonnegative(params) {
    return this.check(_gte(0, params));
  },
  negative(params) {
    return this.check(_lt(0, params));
  },
  nonpositive(params) {
    return this.check(_lte(0, params));
  },
  multipleOf(value, params) {
    return this.check(_multipleOf(value, params));
  },
  step(value, params) {
    return this.check(_multipleOf(value, params));
  },
  finite() {
    return this;
  }
}));
function number2(params) {
  return _number(ZodNumber, params);
}
var ZodNumberFormat = /* @__PURE__ */ $constructor("ZodNumberFormat", (inst, def) => {
  $ZodNumberFormat.init(inst, def);
  ZodNumber.init(inst, def);
});
function int(params) {
  return _int(ZodNumberFormat, params);
}
var ZodBoolean = /* @__PURE__ */ $constructor("ZodBoolean", (inst, def) => {
  $ZodBoolean.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => booleanProcessor(inst, ctx, json, params);
});
function boolean2(params) {
  return _boolean(ZodBoolean, params);
}
var ZodUnknown = /* @__PURE__ */ $constructor("ZodUnknown", (inst, def) => {
  $ZodUnknown.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => unknownProcessor(inst, ctx, json, params);
});
function unknown() {
  return _unknown(ZodUnknown);
}
var ZodNever = /* @__PURE__ */ $constructor("ZodNever", (inst, def) => {
  $ZodNever.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => neverProcessor(inst, ctx, json, params);
});
function never(params) {
  return _never(ZodNever, params);
}
var ZodArray = /* @__PURE__ */ $constructor("ZodArray", (inst, def) => {
  _ensureDefaultMemoizer();
  $ZodArray.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => arrayProcessor(inst, ctx, json, params);
  inst.element = def.element;
}, {
  min(n, params) {
    return this.check(_minLength(n, params));
  },
  nonempty(params) {
    return this.check(_minLength(1, params));
  },
  max(n, params) {
    return this.check(_maxLength(n, params));
  },
  length(n, params) {
    return this.check(_length(n, params));
  },
  unwrap() {
    return this.element;
  }
});
function array(element, params) {
  return _array(ZodArray, element, params);
}
var ZodObject = /* @__PURE__ */ $constructor("ZodObject", (inst, def) => {
  _ensureDefaultMemoizer();
  $ZodObjectJIT.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => objectProcessor(inst, ctx, json, params);
  installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
}, {
  keyof() {
    return _enum(Object.keys(this._zod.def.shape));
  },
  catchall(catchall) {
    return this.clone(mergeDefs(this._zod.def, { catchall }));
  },
  passthrough() {
    return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
  },
  loose() {
    return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
  },
  strict() {
    return this.clone(mergeDefs(this._zod.def, { catchall: never() }));
  },
  strip() {
    return this.clone(mergeDefs(this._zod.def, { catchall: undefined }));
  },
  extend(incoming) {
    return extend(this, incoming);
  },
  safeExtend(incoming) {
    return safeExtend(this, incoming);
  },
  merge(other) {
    return merge(this, other);
  },
  pick(mask) {
    return pick(this, mask);
  },
  omit(mask) {
    return omit(this, mask);
  },
  partial(...args) {
    return partial(ZodOptional, this, args[0]);
  },
  exactPartial(...args) {
    return partial(ZodExactOptional, this, args[0], "exactPartial");
  },
  required(...args) {
    return required(ZodNonOptional, this, args[0]);
  }
});
function object(shape, params) {
  const def = {
    type: "object",
    shape: shape ?? {},
    ...normalizeParams(params)
  };
  return new ZodObject(def);
}
function strictObject(shape, params) {
  return new ZodObject({
    type: "object",
    shape,
    catchall: never(),
    ...normalizeParams(params)
  });
}
var ZodUnion = /* @__PURE__ */ $constructor("ZodUnion", (inst, def) => {
  $ZodUnion.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => unionProcessor(inst, ctx, json, params);
  inst.options = def.options;
});
function union(options, params) {
  return new ZodUnion({
    type: "union",
    options,
    ...normalizeParams(params)
  });
}
var ZodDiscriminatedUnion = /* @__PURE__ */ $constructor("ZodDiscriminatedUnion", (inst, def) => {
  ZodUnion.init(inst, def);
  $ZodDiscriminatedUnion.init(inst, def);
});
function discriminatedUnion(discriminator, options, params) {
  return new ZodDiscriminatedUnion({
    type: "union",
    options,
    discriminator,
    ...normalizeParams(params)
  });
}
var ZodIntersection = /* @__PURE__ */ $constructor("ZodIntersection", (inst, def) => {
  $ZodIntersection.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => intersectionProcessor(inst, ctx, json, params);
});
function intersection(left, right) {
  return new ZodIntersection({
    type: "intersection",
    left,
    right
  });
}
var ZodTuple = /* @__PURE__ */ $constructor("ZodTuple", (inst, def) => {
  _ensureDefaultMemoizer();
  $ZodTuple.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => tupleProcessor(inst, ctx, json, params);
}, {
  rest(rest) {
    return this.clone({
      ...this._zod.def,
      rest
    });
  },
  partial() {
    const def = this._zod.def;
    if (def.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...def,
      items: def.items.map((item) => new ZodOptional({ type: "optional", innerType: item }))
    });
  }
});
function tuple(items, _paramsOrRest, _params) {
  const hasRest = _paramsOrRest instanceof $ZodType;
  const params = hasRest ? _params : _paramsOrRest;
  const rest = hasRest ? _paramsOrRest : null;
  return new ZodTuple({
    type: "tuple",
    items,
    rest,
    ...normalizeParams(params)
  });
}
var ZodRecord = /* @__PURE__ */ $constructor("ZodRecord", (inst, def) => {
  _ensureDefaultMemoizer();
  $ZodRecord.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => recordProcessor(inst, ctx, json, params);
  inst.keyType = def.keyType;
  inst.valueType = def.valueType;
});
function record(keyType, valueType, params) {
  if (!valueType || !valueType._zod) {
    return new ZodRecord({
      type: "record",
      keyType: string2(),
      valueType: keyType,
      ...normalizeParams(valueType)
    });
  }
  return new ZodRecord({
    type: "record",
    keyType,
    valueType,
    ...normalizeParams(params)
  });
}
function partialRecord(keyType, valueType, params) {
  return new ZodRecord({
    type: "record",
    keyType,
    valueType,
    ...normalizeParams(params),
    partial: true
  });
}
var ZodEnum = /* @__PURE__ */ $constructor("ZodEnum", (inst, def) => {
  $ZodEnum.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => enumProcessor(inst, ctx, json, params);
  inst.enum = def.entries;
  inst.options = [...inst._zod.values];
  const keys = new Set(Object.keys(def.entries));
  inst.extract = (values, params) => {
    const newEntries = {};
    for (const value of values) {
      if (keys.has(value)) {
        newEntries[value] = def.entries[value];
      } else
        throw new Error(`Key ${value} not found in enum`);
    }
    return new ZodEnum({
      ...def,
      checks: [],
      ...normalizeParams(params),
      entries: newEntries
    });
  };
  inst.exclude = (values, params) => {
    const newEntries = { ...def.entries };
    for (const value of values) {
      if (keys.has(value)) {
        delete newEntries[value];
      } else
        throw new Error(`Key ${value} not found in enum`);
    }
    return new ZodEnum({
      ...def,
      checks: [],
      ...normalizeParams(params),
      entries: newEntries
    });
  };
});
function _enum(values, params) {
  const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
  return new ZodEnum({
    type: "enum",
    entries,
    ...normalizeParams(params)
  });
}
var ZodLiteral = /* @__PURE__ */ $constructor("ZodLiteral", (inst, def) => {
  $ZodLiteral.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => literalProcessor(inst, ctx, json, params);
  inst.values = new Set(def.values);
  Object.defineProperty(inst, "value", {
    get() {
      if (def.values.length > 1) {
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      }
      return def.values[0];
    }
  });
});
function literal(value, params) {
  return new ZodLiteral({
    type: "literal",
    values: Array.isArray(value) ? value : [value],
    ...normalizeParams(params)
  });
}
var ZodTransform = /* @__PURE__ */ $constructor("ZodTransform", (inst, def) => {
  _ensureDefaultMemoizer();
  $ZodTransform.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => transformProcessor(inst, ctx, json, params);
  inst._zod.parse = (payload, _ctx) => {
    if (_ctx.direction === "backward") {
      throw new $ZodEncodeError(inst.constructor.name);
    }
    payload.addIssue = (issue2) => {
      if (typeof issue2 === "string") {
        payload.issues.push(issue(issue2, payload.value, def));
      } else {
        const _issue = issue2;
        if (_issue.fatal)
          _issue.continue = false;
        _issue.code ?? (_issue.code = "custom");
        if (!("input" in _issue))
          _issue.input = payload.value;
        _issue.inst ?? (_issue.inst = inst);
        payload.issues.push(issue(_issue));
      }
    };
    const output = def.transform(payload.value, payload);
    if (output instanceof Promise) {
      return output.then((output) => {
        payload.value = output;
        return payload;
      });
    }
    payload.value = output;
    return payload;
  };
});
function transform(fn) {
  return new ZodTransform({
    type: "transform",
    transform: fn
  });
}
var ZodOptional = /* @__PURE__ */ $constructor("ZodOptional", (inst, def) => {
  $ZodOptional.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function optional(innerType) {
  return new ZodOptional({
    type: "optional",
    innerType
  });
}
var ZodExactOptional = /* @__PURE__ */ $constructor("ZodExactOptional", (inst, def) => {
  $ZodExactOptional.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function exactOptional(innerType) {
  return new ZodExactOptional({
    type: "optional",
    innerType
  });
}
var ZodNullable = /* @__PURE__ */ $constructor("ZodNullable", (inst, def) => {
  $ZodNullable.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => nullableProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function nullable(innerType) {
  return new ZodNullable({
    type: "nullable",
    innerType
  });
}
var ZodDefault = /* @__PURE__ */ $constructor("ZodDefault", (inst, def) => {
  $ZodDefault.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => defaultProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
  inst.removeDefault = inst.unwrap;
});
function _default(innerType, defaultValue) {
  return new ZodDefault({
    type: "default",
    innerType,
    get defaultValue() {
      return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
    }
  });
}
var ZodPrefault = /* @__PURE__ */ $constructor("ZodPrefault", (inst, def) => {
  $ZodPrefault.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => prefaultProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function prefault(innerType, defaultValue) {
  return new ZodPrefault({
    type: "prefault",
    innerType,
    get defaultValue() {
      return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
    }
  });
}
var ZodNonOptional = /* @__PURE__ */ $constructor("ZodNonOptional", (inst, def) => {
  $ZodNonOptional.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => nonoptionalProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function nonoptional(innerType, params) {
  return new ZodNonOptional({
    type: "nonoptional",
    innerType,
    ...normalizeParams(params)
  });
}
var ZodCatch = /* @__PURE__ */ $constructor("ZodCatch", (inst, def) => {
  $ZodCatch.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => catchProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
  inst.removeCatch = inst.unwrap;
});
function _catch(innerType, catchValue) {
  return new ZodCatch({
    type: "catch",
    innerType,
    catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
  });
}
var ZodPipe = /* @__PURE__ */ $constructor("ZodPipe", (inst, def) => {
  $ZodPipe.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => pipeProcessor(inst, ctx, json, params);
  inst.in = def.in;
  inst.out = def.out;
});
function pipe(in_, out) {
  return new ZodPipe({
    type: "pipe",
    in: in_,
    out
  });
}
var ZodReadonly = /* @__PURE__ */ $constructor("ZodReadonly", (inst, def) => {
  $ZodReadonly.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => readonlyProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function readonly(innerType) {
  return new ZodReadonly({
    type: "readonly",
    innerType
  });
}
var ZodCustom = /* @__PURE__ */ $constructor("ZodCustom", (inst, def) => {
  $ZodCustom.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => customProcessor(inst, ctx, json, params);
});
function refine(fn, _params = {}) {
  return _refine(ZodCustom, fn, _params);
}
function superRefine(fn, params) {
  return _superRefine(fn, params);
}
var ZodInstanceOf = /* @__PURE__ */ $constructor("ZodInstanceOf", (inst, def) => {
  ZodCustom.init(inst, def);
}, {
  properties(shape, params) {
    return this.check(_properties(shape, params));
  }
});
function _instanceof(cls, params = {}) {
  const inst = new ZodInstanceOf({
    type: "custom",
    check: "custom",
    fn: (data) => data instanceof cls,
    abort: true,
    ...normalizeParams(params)
  });
  inst._zod.bag.Class = cls;
  inst._zod.check = (payload) => {
    if (!(payload.value instanceof cls)) {
      payload.issues.push({
        code: "invalid_type",
        expected: cls.name,
        input: payload.value,
        inst,
        path: [...inst._zod.def.path ?? []]
      });
    }
  };
  return inst;
}
// node_modules/.bun/zod@4.6.7/node_modules/zod/v4/classic/iso.js
function datetime2(params) {
  return _isoDateTime(ZodISODateTime, params);
}
function date2(params) {
  return _isoDate(ZodISODate, params);
}
function time2(params) {
  return _isoTime(ZodISOTime, params);
}
function duration2(params) {
  return _isoDuration(ZodISODuration, params);
}
// packages/kernel/src/values.ts
var providerKinds = [
  "openai",
  "anthropic",
  "gemini",
  "deepseek",
  "ollama",
  "azure",
  "bedrock",
  "vertex"
];
var protocols = ["chat", "responses", "messages", "gemini"];
var operations = [
  ...protocols,
  "embeddings",
  "images",
  "image_edits",
  "speech",
  "transcription",
  "translation",
  "files",
  "batches",
  "videos",
  "music",
  "moderations",
  "completions"
];
var dimensions = [
  "input_tokens",
  "output_tokens",
  "cached_input_tokens",
  "cache_write_tokens",
  "cache_write_5m_tokens",
  "cache_write_1h_tokens",
  "requests",
  "images",
  "audio_ms",
  "music_ms",
  "video_ms",
  "audio_seconds",
  "video_seconds",
  "characters"
];
// packages/kernel/src/errors.ts
class DomainError extends Error {
  code;
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "DomainError";
  }
}
// packages/kernel/src/numbers.ts
function normalizedNumber(source) {
  if (source.length > 200)
    throw new DomainError("numeric_limit", "Numeric literal exceeds protocol budget");
  const match = /^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d{1,5}))?$/.exec(source);
  if (!match)
    throw new DomainError("invalid_numeric_literal", "Invalid protocol numeric literal");
  let digits = `${match[2]}${match[3] ?? ""}`.replace(/^0+/, "");
  let exponent = Number(match[4] ?? "0") - (match[3]?.length ?? 0);
  if (!digits)
    return { digits: "0", exponent: 0, negative: false };
  const trimmed = digits.replace(/0+$/, "");
  exponent += digits.length - trimmed.length;
  digits = trimmed;
  return { digits, exponent, negative: match[1] === "-" };
}
// packages/kernel/src/canonical.ts
function canonical(value, numberLiteral = () => {
  return;
}, depth = 0) {
  if (depth > 64)
    throw new DomainError("invalid_request", "JSON nesting exceeds limit");
  if (Array.isArray(value))
    return `[${value.map((v, index) => {
      const literal = typeof v === "number" ? numberLiteral(value, String(index)) : undefined;
      if (literal) {
        const number = normalizedNumber(literal);
        return `${number.negative ? "-" : ""}${number.digits}e${number.exponent}`;
      }
      return canonical(v, numberLiteral, depth + 1);
    }).join(",")}]`;
  if (typeof value === "object" && value !== null) {
    const obj = value;
    return `{${Object.keys(obj).sort().map((k) => {
      const literal = typeof obj[k] === "number" ? numberLiteral(obj, k) : undefined;
      if (literal) {
        const number = normalizedNumber(literal);
        return `${JSON.stringify(k)}:${number.negative ? "-" : ""}${number.digits}e${number.exponent}`;
      }
      return `${JSON.stringify(k)}:${canonical(obj[k], numberLiteral, depth + 1)}`;
    }).join(",")}}`;
  }
  const result = JSON.stringify(value);
  if (result === undefined)
    throw new Error("Invalid JSON value");
  return result;
}
// packages/kernel/src/cost.ts
var maxAtoms = 10n ** 38n - 1n;
// packages/contracts/src/public.ts
var positiveInteger = string2().regex(/^[1-9][0-9]{0,37}$/);
var integer2 = string2().regex(/^(0|[1-9][0-9]{0,37})$/);
var rateSchema = object({ numerator: integer2, denominator: positiveInteger }).strict();
var pricingSchema = object({
  currency: string2().regex(/^[A-Z]{3,8}$/),
  rates: partialRecord(_enum(dimensions), rateSchema)
}).strict().superRefine((value, context) => {
  if (value.rates.cache_write_tokens && (value.rates.cache_write_5m_tokens || value.rates.cache_write_1h_tokens))
    context.addIssue({
      code: "custom",
      message: "Choose aggregate or TTL-specific cache write rates"
    });
  for (const prefix of ["audio", "video"]) {
    if (value.rates[`${prefix}_ms`] && value.rates[`${prefix}_seconds`])
      context.addIssue({ code: "custom", message: "Choose one duration unit per media type" });
  }
});
var parameterPath = string2().regex(/^[A-Za-z_][A-Za-z0-9_]*(?:\.(?:[A-Za-z_][A-Za-z0-9_]*|[0-9]+|\*))*$/).max(200);
var parameterRange = object({ minimum: number2().finite().optional(), maximum: number2().finite().optional() }).strict().refine((v) => (v.minimum !== undefined || v.maximum !== undefined) && !(v.minimum !== undefined && v.maximum !== undefined && v.minimum > v.maximum), "A parameter range requires ordered bounds");
var requestPolicySchema = object({
  allowed_parameters: array(string2().regex(/^[A-Za-z_][A-Za-z0-9_]*$/).max(100)).max(100).optional(),
  blocked_parameters: array(parameterPath).max(100).optional(),
  parameter_ranges: record(parameterPath, parameterRange).refine((v) => Object.keys(v).length <= 100, "Too many parameter ranges").optional()
}).strict();
var projectSchema = object({
  name: string2().min(1).max(100),
  external_ref: string2().max(200).optional(),
  organization_id: uuid2().optional(),
  billing_currency: string2().regex(/^[A-Z]{3,8}$/).default("USD"),
  rpm: number2().int().min(1).max(1e7).default(6000),
  tpm: number2().int().min(1).max(1e9).default(1e7),
  concurrency: number2().int().min(1).max(1e6).default(1000)
}).strict();
var keySchema = object({
  name: string2().min(1).max(100),
  models: array(string2().min(1).max(150)).max(1000).default([]),
  operations: array(_enum(operations)).min(1).default([...operations]),
  principal_id: uuid2().optional(),
  role: _enum(["ADMIN", "INVOKER", "BILLING", "VIEWER"]).default("INVOKER"),
  allowed_cidrs: array(string2().min(2).max(60)).max(100).default([]),
  rpm: number2().int().min(1).max(1e7).optional(),
  tpm: number2().int().min(1).max(1e9).optional(),
  concurrency: number2().int().min(1).max(1e6).optional(),
  expires_at: exports_iso.datetime().optional()
}).strict();
var providerSchema = object({
  name: string2().min(1).max(100),
  kind: _enum(providerKinds),
  base_url: url().max(1000).describe("HTTPS origin; a path, query, fragment or userinfo is rejected"),
  api_key: string2().min(1).max(16384),
  concurrency: number2().int().min(1).max(1e5).default(1000),
  rpm: number2().int().min(1).max(1e7).default(1e6)
}).strict();
var modelSchema = object({
  name: string2().regex(/^[A-Za-z0-9][A-Za-z0-9_.:/-]{0,149}$/),
  operations: array(_enum(operations)).min(1),
  routing_strategy: _enum(["WEIGHTED", "ROUND_ROBIN", "LEAST_LATENCY"]).default("WEIGHTED"),
  max_output_tokens: number2().int().min(1).max(1e7).default(32768)
}).strict();
var usageSchema = partialRecord(_enum([...dimensions, "reasoning_tokens"]), string2().regex(/^(0|[1-9][0-9]{0,37})(\.[0-9]{1,18})?$/)).superRefine((value, context) => {
  for (const [key, quantity] of Object.entries(value))
    if (quantity.includes(".") && key !== "audio_seconds" && key !== "video_seconds")
      context.addIssue({ code: "custom", message: "Counters must be integers", path: [key] });
  if (value.cache_write_tokens !== undefined && value.cache_write_5m_tokens !== undefined && value.cache_write_1h_tokens !== undefined && [value.cache_write_tokens, value.cache_write_5m_tokens, value.cache_write_1h_tokens].every((q) => /^(0|[1-9][0-9]{0,37})$/.test(q)) && BigInt(value.cache_write_tokens) !== BigInt(value.cache_write_5m_tokens) + BigInt(value.cache_write_1h_tokens))
    context.addIssue({ code: "custom", message: "Provider cache write partitions disagree" });
});
var upstreamCostConfigurationSchema = object({ pricing: pricingSchema, ceilings: usageSchema }).strict().superRefine((value, context) => {
  for (const dimension of Object.keys(value.pricing.rates))
    if (!Object.hasOwn(value.ceilings, dimension))
      context.addIssue({
        code: "custom",
        message: "Every upstream rate requires an explicit reservation ceiling",
        path: ["ceilings", dimension]
      });
  if (!Object.keys(value.pricing.rates).length)
    context.addIssue({
      code: "custom",
      message: "Upstream pricing must explicitly declare at least one rate"
    });
});
var routeSchema = object({
  provider_id: uuid2(),
  upstream_model: string2().min(1).max(200),
  operations: array(_enum(operations)).min(1),
  priority: number2().int().min(0).max(1000).default(0),
  weight: number2().min(0.001).max(1000).default(1),
  pricing: pricingSchema,
  ceilings: usageSchema,
  request_policy: requestPolicySchema.optional()
}).strict().superRefine((value, context) => {
  const result = upstreamCostConfigurationSchema.safeParse({
    pricing: value.pricing,
    ceilings: value.ceilings
  });
  if (!result.success)
    for (const issue of result.error.issues)
      context.addIssue({ ...issue });
});
var routePatchSchema = object({
  enabled: boolean2().optional(),
  priority: number2().int().min(0).max(1000).optional(),
  weight: number2().min(0.001).max(1000).optional(),
  pricing: pricingSchema.optional(),
  ceilings: usageSchema.optional(),
  request_policy: requestPolicySchema.optional()
}).strict().superRefine((value, context) => {
  if (value.pricing !== undefined || value.ceilings !== undefined) {
    const result = upstreamCostConfigurationSchema.safeParse({
      pricing: value.pricing,
      ceilings: value.ceilings
    });
    if (!result.success)
      for (const issue of result.error.issues)
        context.addIssue({ ...issue });
  }
});
var quotaFields = {
  rpm: number2().int().min(1).max(1e7).optional(),
  tpm: number2().int().min(1).max(1e9).optional(),
  concurrency: number2().int().min(1).max(1e6).optional()
};
var principalRoles = ["OWNER", "ADMIN", "MEMBER", "BILLING", "VIEWER"];
var organizationSchema = object({
  external_ref: string2().min(1).max(200),
  name: string2().min(1).max(100),
  ...quotaFields
}).strict();
var organizationPatchSchema = object({ enabled: boolean2().optional(), ...quotaFields }).strict();
var principalSchema = object({
  external_ref: string2().min(1).max(200),
  role: _enum(principalRoles),
  ...quotaFields
}).strict();
var principalPatchSchema = object({
  enabled: boolean2().optional(),
  role: _enum(principalRoles).optional(),
  ...quotaFields
}).strict();
var projectPatchSchema = object({
  enabled: boolean2().optional(),
  name: string2().min(1).max(100).optional(),
  billing_currency: string2().regex(/^[A-Z]{3,8}$/).optional(),
  rpm: number2().int().min(1).max(1e7).optional(),
  tpm: number2().int().min(1).max(1e9).optional(),
  concurrency: number2().int().min(1).max(1e6).optional()
}).strict();
var modelPatchSchema = object({
  enabled: boolean2().optional(),
  operations: array(_enum(operations)).min(1).optional(),
  max_output_tokens: number2().int().min(1).max(1e7).optional(),
  routing_strategy: _enum(["WEIGHTED", "ROUND_ROBIN", "LEAST_LATENCY"]).optional()
}).strict();
var keyPatchSchema = object({
  models: array(string2().min(1).max(150)).max(1000).optional(),
  operations: array(_enum(operations)).min(1).optional(),
  allowed_cidrs: array(string2().min(2).max(60)).max(100).optional(),
  role: _enum(["ADMIN", "INVOKER", "BILLING", "VIEWER"]).optional(),
  ...quotaFields,
  expires_at: exports_iso.datetime().optional()
}).strict();
// packages/contracts/src/billing.ts
var currencySchema = string2().regex(/^[A-Z]{3,8}$/);
var atomsSchema = string2().regex(/^(0|[1-9][0-9]{0,37})$/);
var positiveAtomsSchema = string2().regex(/^[1-9][0-9]{0,37}$/);
var creditPolicySchema = object({
  external_ref: string2().min(1).max(200),
  expected_version: atomsSchema,
  credit_limit_atoms: atomsSchema
}).strict();
var creditSchema = object({
  currency: currencySchema,
  external_ref: string2().min(1).max(200),
  amount_atoms: positiveAtomsSchema,
  kind: _enum(["CASH", "GIFT"]),
  priority: number2().int().min(0).max(1e5).default(100),
  expires_at: exports_iso.datetime().optional(),
  models: array(string2().min(1).max(150)).max(1000).default([]),
  operations: array(_enum(operations)).default([])
}).strict().superRefine((value, context) => {
  if (value.kind === "CASH" && (value.expires_at || value.models.length || value.operations.length))
    context.addIssue({
      code: "custom",
      message: "Cash cannot expire or have model/operation scopes"
    });
});
var tariffSchema = object({
  model: string2().min(1).max(150),
  operation: _enum(operations),
  provider_id: uuid2().optional(),
  pricing: pricingSchema,
  ceilings: usageSchema,
  basis: _enum(["PROVIDER_USAGE", "INPUT_CHARACTERS", "REQUEST_COMPLETION"]).default("PROVIDER_USAGE")
}).strict().superRefine((value, context) => {
  for (const dimension of Object.keys(value.pricing.rates))
    if (!Object.hasOwn(value.ceilings, dimension))
      context.addIssue({
        code: "custom",
        message: "Every rate requires an explicit reservation ceiling",
        path: ["ceilings", dimension]
      });
  if (!Object.keys(value.pricing.rates).length)
    context.addIssue({
      code: "custom",
      message: "A tariff must explicitly declare at least one rate"
    });
  if (value.basis === "INPUT_CHARACTERS" && Object.keys(value.pricing.rates).some((d) => !["characters", "requests"].includes(d)))
    context.addIssue({
      code: "custom",
      message: "Input character pricing only supports characters and requests"
    });
  if (value.basis === "REQUEST_COMPLETION" && Object.keys(value.pricing.rates).some((d) => d !== "requests"))
    context.addIssue({
      code: "custom",
      message: "Request completion pricing only supports requests"
    });
});
var refundSchema = object({
  external_ref: string2().min(1).max(200),
  amount_atoms: positiveAtomsSchema,
  reason: _enum(["CUSTOMER_REFUND", "ADMIN_CORRECTION", "PROVIDER_RECONCILIATION"]).default("CUSTOMER_REFUND")
}).strict();
var adjustmentSchema = object({
  external_ref: string2().min(1).max(200),
  target_atoms: atomsSchema,
  reason: _enum(["ADMIN_CORRECTION", "PROVIDER_RECONCILIATION"])
}).strict();
var resolutionSchema = object({
  external_ref: string2().min(1).max(200),
  action: _enum(["RELEASE", "SETTLE"]),
  usage: usageSchema.default({}),
  pricing_id: uuid2().optional(),
  reason: _enum(["PROVIDER_INVOICE", "ADMIN_WRITE_OFF", "EVIDENCE_RECONCILIATION"])
}).strict().superRefine((value, context) => {
  if (value.action === "SETTLE" && !value.pricing_id)
    context.addIssue({
      code: "custom",
      message: "Settlement resolution requires the captured pricing version"
    });
});
// packages/contracts/src/enterprise.ts
var digestSchema = string2().regex(/^[a-f0-9]{64}$/);
var opaqueResourceIdSchema = string2().regex(/^[A-Za-z0-9_:/.-]{1,500}$/).refine((value) => !value.includes("://") && !value.split("/").some((part) => part === "." || part === ".."), "Expected a stable opaque resource identity");
var batchManifestSchema = object({
  items: number2().int().min(1).max(Number.MAX_SAFE_INTEGER),
  idsSha256: digestSchema,
  images: number2().int().min(1).max(Number.MAX_SAFE_INTEGER).optional()
}).strict();
var batchResourceMetadataSchema = object({
  endpoint: string2().refine((value) => [
    "/v1/chat/completions",
    "/v1/responses",
    "/v1/embeddings",
    "/v1/completions",
    "/v1/moderations",
    "/v1/images/generations",
    "/v1/images/edits"
  ].includes(value), "Unsupported batch endpoint"),
  upstreamModel: string2().min(1).max(200),
  manifest: batchManifestSchema.optional()
}).strict();
var commandEnvelopeSchema = object({
  command_id: uuid2(),
  body_digest: digestSchema,
  caller_incarnation: uuid2(),
  deadline_at: exports_iso.datetime(),
  trace_id: string2().min(1).max(200),
  contract_version: literal(1)
}).strict();
var pluginBindingSchema = object({
  id: uuid2(),
  channel_id: uuid2(),
  plugin_version_id: uuid2(),
  package_digest: digestSchema,
  config_digest: digestSchema,
  config_revision: atomsSchema
}).strict();
var resourceCommitSchema = object({
  public_id: string2().regex(/^[A-Za-z0-9_-]{1,200}$/),
  remote_id: opaqueResourceIdSchema,
  kind: _enum(["file", "batch", "video", "response", "operation"]),
  project_id: uuid2(),
  channel_id: uuid2(),
  attempt_id: uuid2().optional(),
  model: string2().min(1).max(200).optional(),
  binding_id: uuid2(),
  state: _enum(["ACTIVE", "PENDING_USAGE", "COMPLETED", "CANCELLED", "FAILED", "DELETED"]),
  batch: batchResourceMetadataSchema.optional()
}).strict();
// packages/contracts/src/upstream-funding.ts
function normalizeFundingTimestamp(value) {
  const match = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,6}))?Z$/.exec(value);
  if (!match)
    throw new RangeError("Expected a UTC timestamp with at most six fractional digits");
  const milliseconds = Date.parse(`${match[1]}Z`);
  if (!Number.isFinite(milliseconds) || match[1].startsWith("0000-") || new Date(milliseconds).toISOString().slice(0, 19) !== match[1])
    throw new RangeError("Invalid UTC calendar timestamp");
  return `${match[1]}.${(match[2] ?? "").padEnd(6, "0")}Z`;
}
var fundingTimestampSchema = string2().transform((value, context) => {
  try {
    return normalizeFundingTimestamp(value);
  } catch {
    context.addIssue({
      code: "custom",
      message: "Expected a valid UTC timestamp at microsecond precision"
    });
    return NEVER;
  }
});
var upstreamRechargeSchema = object({
  external_ref: string2().min(1).max(200),
  payment_currency: currencySchema,
  payment_atoms: positiveAtomsSchema,
  credited_currency: currencySchema,
  credited_atoms: positiveAtomsSchema,
  voucher_id: uuid2().transform((value) => value.toLowerCase()),
  voucher_digest: digestSchema,
  completed_at: fundingTimestampSchema,
  reason: string2().trim().min(1).max(2000)
}).strict();
var financialVoucherRegistrationSchema = object({
  content: _instanceof(Uint8Array).refine((value) => value.byteLength > 0 && value.byteLength <= 5242880),
  content_type: _enum(["image/png", "image/jpeg", "application/pdf"]),
  digest: digestSchema,
  expires_at: fundingTimestampSchema
}).strict();
var financialVoucherUploadSchema = strictObject({
  content_base64: string2().max(7 << 20),
  content_type: _enum(["image/png", "image/jpeg", "application/pdf"]),
  digest: string2().regex(/^[a-f0-9]{64}$/),
  expires_at: string2()
});
var signedAtomsSchema = string2().regex(/^-?[1-9][0-9]{0,37}$/);
var voucherReference = {
  voucher_id: uuid2().transform((value) => value.toLowerCase()).optional(),
  voucher_digest: digestSchema.optional()
};
var pairedVoucher = (value) => value.voucher_id === undefined === (value.voucher_digest === undefined);
var upstreamAdjustmentSchema = object({
  external_ref: string2().min(1).max(200),
  currency: currencySchema,
  delta_atoms: signedAtomsSchema,
  expected_revision: atomsSchema,
  reason: string2().trim().min(1).max(2000),
  ...voucherReference
}).strict().refine(pairedVoucher, { message: "Voucher id and digest must be provided together" });
var upstreamReconciliationSchema = object({
  currency: currencySchema,
  expected_revision: atomsSchema,
  observed_atoms: atomsSchema.optional(),
  invoice_atoms: atomsSchema.optional(),
  adjustment_operation_id: uuid2().transform((value) => value.toLowerCase()).optional(),
  resume: boolean2().default(false),
  reason: string2().trim().min(1).max(2000),
  ...voucherReference
}).strict().refine(pairedVoucher, { message: "Voucher id and digest must be provided together" });
var supplierBrandSchema = object({ name: string2().min(1).max(100) }).strict();
var supplierBrandPatchSchema = object({ enabled: boolean2() }).strict();
var upstreamAccountSchema = object({ brand_id: uuid2(), name: string2().min(1).max(200) }).strict();
var upstreamAccountPatchSchema = object({ state: _enum(["ACTIVE", "DISABLED"]), reason: string2().trim().min(1).max(2000) }).strict();
// packages/contracts/src/internal-identity.ts
var internalServiceSchema = _enum(["gateway", "core-api", "core-worker"]);
var internalUuidSchema = string2().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
var internalInstantSchema = string2().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/).refine((v) => Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v);
var internalInstanceSchema = string2().regex(/^[A-Za-z0-9_-]{1,100}$/);
var nonce = string2().regex(/^[A-Za-z0-9_-]{43}$/);
var internalSignatureSchema = string2().regex(/^[A-Za-z0-9_-]{86}$/);
var revision = string2().regex(/^[1-9][0-9]{0,37}$/);
var startupChallengeRequestSchema = strictObject({
  registration_id: internalUuidSchema,
  public_key_spki: string2().regex(/^[A-Za-z0-9_-]{59}$/),
  boot_nonce: nonce,
  contract_version: literal(1)
});
var startupChallengeSchema = strictObject({
  challenge_id: internalUuidSchema,
  registration_id: internalUuidSchema,
  audience: string2().regex(/^[A-Za-z0-9_.-]{1,100}\/core-api$/),
  service: internalServiceSchema,
  instance_id: internalInstanceSchema,
  certificate_sha256: digestSchema,
  public_key_sha256: digestSchema,
  boot_nonce: nonce,
  server_nonce: nonce,
  challenge_expires_at: internalInstantSchema
});
var startupRegistrationRequestSchema = strictObject({
  challenge_id: internalUuidSchema,
  registration_id: internalUuidSchema,
  signature: internalSignatureSchema,
  contract_version: literal(1)
});
var startupReceiptSchema = strictObject({
  session_id: internalUuidSchema,
  incarnation_id: internalUuidSchema,
  service: internalServiceSchema,
  instance_id: internalInstanceSchema,
  certificate_sha256: digestSchema,
  public_key_sha256: digestSchema,
  expires_at: internalInstantSchema
});
var startupRegistrationResponseSchema = strictObject({
  receipt: startupReceiptSchema,
  current: boolean2(),
  replayed: boolean2()
});
var internalProofSchema = strictObject({
  session_id: internalUuidSchema,
  incarnation_id: internalUuidSchema,
  command_type: _enum([
    "identity_current_v1",
    "execution_context_v1",
    "execution_admit_v1",
    "execution_next_v1",
    "execution_begin_v1",
    "execution_abort_v1",
    "execution_query_v1",
    "execution_quota_v1",
    "execution_quota_recovery_v1",
    "execution_abort_recovery_v1",
    "execution_resource_commit_v1",
    "execution_resource_v1",
    "execution_resource_list_v1",
    "execution_resource_claim_v1",
    "execution_resource_poll_v1",
    "execution_resource_release_v1",
    "plugin_package_v1"
  ]),
  command_id: internalUuidSchema,
  deadline_at: internalInstantSchema,
  trace_id: string2().regex(/^[A-Za-z0-9_-]{1,100}$/),
  contract_version: literal(1),
  raw_body_sha256: digestSchema,
  signature: internalSignatureSchema
});
var internalCurrentRequestSchema = strictObject({
  envelope: strictObject({
    command_id: internalUuidSchema,
    body_digest: digestSchema,
    caller_incarnation: internalUuidSchema,
    deadline_at: internalInstantSchema,
    trace_id: string2().regex(/^[A-Za-z0-9_-]{1,100}$/),
    contract_version: literal(1)
  }),
  data: strictObject({})
});
var internalCurrentResponseSchema = strictObject({
  command_id: internalUuidSchema,
  kind: literal("identity_current_v1"),
  receipt: startupReceiptSchema,
  current: literal(true),
  authorization_revision: revision
});
var executionRejectionCodeSchema = _enum([
  "insufficient_funds",
  "upstream_funds_unavailable",
  "already_accepted",
  "idempotency_conflict",
  "proposed_id_conflict",
  "context_stale",
  "context_invalid",
  "candidate_stale",
  "cost_unbounded",
  "cost_ceiling",
  "estimate_invalid",
  "quote_invalid",
  "request_mismatch",
  "execution_closed",
  "retry_quota_exceeded",
  "retry_conflict",
  "retry_quote_exceeded",
  "permit_not_reserved",
  "begin_precondition",
  "internal_request_invalid",
  "abort_closure_conflict",
  "prep_binding_invalid",
  "amount_overflow",
  "billing_ceiling",
  "tariff_unavailable",
  "invalid_tariff",
  "quota_budget_exceeded",
  "output_bound",
  "invalid_request",
  "recovery_not_reserved",
  "recovery_not_eligible"
]);
var internalErrorSchema = strictObject({
  code: union([
    executionRejectionCodeSchema,
    _enum([
      "internal_proof_invalid",
      "internal_session_invalid",
      "internal_peer_forbidden",
      "internal_owner_mismatch",
      "internal_identity_revoked",
      "internal_request_invalid",
      "registration_conflict",
      "startup_key_reused",
      "startup_boot_conflict",
      "internal_deadline",
      "internal_body_too_large",
      "internal_capacity",
      "identity_busy",
      "identity_store_unavailable",
      "command_conflict",
      "quota_unavailable",
      "quota_limited",
      "channel_capacity",
      "quota_release_denied",
      "candidate_stale",
      "cost_unbounded",
      "customer_forbidden",
      "context_invalid",
      "plugin_package_unavailable",
      "no_route",
      "resource_not_found",
      "resource_rate_limited",
      "resource_provider_mismatch"
    ])
  ]),
  category: _enum(["AUTHENTICATION", "VALIDATION", "DEPENDENCY"]),
  retryability: _enum(["NONE", "SAME_COMMAND", "STATUS_ONLY"]),
  command_state: _enum(["NOT_ATTEMPTED", "UNKNOWN", "REJECTED"]),
  request_id: internalUuidSchema.optional(),
  attempt_id: internalUuidSchema.optional(),
  message: string2().max(100)
});
var candidateRefV1Schema = strictObject({
  route_id: internalUuidSchema,
  channel_id: internalUuidSchema,
  binding_id: internalUuidSchema,
  plugin_version_id: internalUuidSchema,
  package_digest: digestSchema,
  config_revision: revision,
  config_digest: digestSchema,
  cost_version_id: internalUuidSchema,
  customer_price_id: internalUuidSchema,
  candidate_digest: digestSchema
});
var dispatchAuthSchema = discriminatedUnion("type", [
  strictObject({ type: literal("none") }),
  strictObject({ type: literal("bearer") }),
  strictObject({ type: literal("google-oauth") }),
  strictObject({ type: literal("aws-sigv4"), service: _enum(["bedrock"]) }),
  strictObject({
    type: literal("api-key"),
    header: _enum(["api-key", "x-api-key", "x-goog-api-key"])
  })
]);
var dispatchProjectionV1Schema = strictObject({
  version: literal(1),
  proposed_request_id: internalUuidSchema,
  proposed_attempt_id: internalUuidSchema,
  origin: string2().max(250).refine((value) => {
    try {
      const u = new URL(value);
      return u.protocol === "https:" && u.origin === value && !u.username && !u.password;
    } catch {
      return false;
    }
  }),
  method: _enum(["GET", "POST", "DELETE"]),
  operation: _enum(operations),
  request_target_sha256: digestSchema,
  final_headers_digest: digestSchema,
  final_body_sha256: digestSchema,
  candidate_ref: candidateRefV1Schema,
  auth: dispatchAuthSchema,
  credential_ciphertext_sha256: digestSchema,
  billable_manifest_sha256: digestSchema,
  deadline_at: internalInstantSchema
});
var executionRuntimeV1Schema = strictObject({
  version: literal(1),
  kind: _enum(["wasm", "builtin-worker"]),
  artifact_digest: digestSchema
});
var executionRuntimesSchema = record(digestSchema, array(executionRuntimeV1Schema).max(17)).refine((value) => Object.keys(value).length <= 128);
var dispatchProjectionV2Schema = dispatchProjectionV1Schema.extend({
  version: literal(2),
  execution: executionRuntimeV1Schema
});
// packages/contracts/src/core-execution.ts
var executionKinds = [
  "execution_context_v1",
  "execution_admit_v1",
  "execution_next_v1",
  "execution_begin_v1",
  "execution_abort_v1",
  "execution_query_v1",
  "execution_quota_v1",
  "execution_quota_recovery_v1",
  "execution_abort_recovery_v1",
  "execution_resource_commit_v1",
  "execution_resource_v1",
  "execution_resource_list_v1",
  "execution_resource_claim_v1",
  "execution_resource_poll_v1",
  "execution_resource_release_v1"
];
var resourceKinds = ["response", "file", "batch", "video"];
var resourceActions = [
  "get",
  "delete",
  "cancel",
  "content",
  "input_items",
  "files"
];
var batchEndpoints = {
  "/v1/chat/completions": "chat",
  "/v1/responses": "responses",
  "/v1/embeddings": "embeddings",
  "/v1/completions": "completions",
  "/v1/moderations": "moderations",
  "/v1/images/generations": "images",
  "/v1/images/edits": "image_edits"
};
var batchEndpointSchema = _enum(Object.keys(batchEndpoints));
var publicResourceIdSchema = string2().regex(/^(response|file|batch|video)_[0-9a-f]{32}$/);
var routeTicketMaxBytes = 16384;
var routeTicketSchema = string2().max(routeTicketMaxBytes).regex(/^[A-Za-z0-9+/]+={0,2}$/);
var customerCredential = {
  customer_token: string2().min(1).max(16384),
  ip: string2().max(64).regex(/^[0-9a-fA-F:.]{2,64}$/)
};
var executionKindSchema = _enum(executionKinds);
var executionEnvelopeSchema = strictObject({
  command_id: internalUuidSchema,
  body_digest: digestSchema,
  caller_incarnation: internalUuidSchema,
  deadline_at: internalInstantSchema,
  trace_id: string2().regex(/^[A-Za-z0-9_-]{1,100}$/),
  contract_version: literal(1)
});
var normalizedBillableUsageSchema = usageSchema.transform((value) => {
  const result = { ...value };
  for (const key of Object.keys(result)) {
    const quantity = result[key];
    if (quantity?.includes("."))
      result[key] = quantity.replace(/0+$/, "").replace(/\.$/, "");
  }
  return result;
});
var billableManifestV1Schema = strictObject({
  version: literal(1),
  operation: _enum(operations),
  model: string2().min(1).max(150),
  upstream_model: string2().min(1).max(200),
  stream: boolean2(),
  input_bytes: number2().int().min(0).max(16 << 20),
  ceilings: normalizedBillableUsageSchema,
  quantities: normalizedBillableUsageSchema,
  input_characters: atomsSchema.optional(),
  images: atomsSchema.optional(),
  resource_ids: array(internalUuidSchema).max(128)
});
var prep = { prep_session_id: internalUuidSchema, prep_binding_digest: digestSchema };
var dispatch = {
  context_id: internalUuidSchema,
  dispatch_projection: dispatchProjectionV2Schema,
  dispatched_digest: digestSchema,
  manifest: billableManifestV1Schema,
  ...prep
};
var executionDataSchemas = {
  execution_abort_recovery_v1: strictObject({ attempt_id: internalUuidSchema }),
  execution_quota_recovery_v1: strictObject({ limit: number2().int().min(1).max(100) }),
  execution_context_v1: strictObject({
    ...customerCredential,
    route_projection: literal(true).optional(),
    operation: _enum(operations),
    model: string2().min(1).max(150).optional(),
    fingerprint: digestSchema,
    resource_ids: array(string2().regex(/^(response|file)_[0-9a-f]{32}$/)).min(1).max(16).optional()
  }).refine((value) => value.operation === "batches" ? value.model === undefined && value.resource_ids?.length === 1 : value.model !== undefined || value.operation === "files"),
  execution_admit_v1: strictObject({
    ...dispatch,
    project_id: internalUuidSchema,
    key_id: internalUuidSchema,
    intent_digest: digestSchema.nullable(),
    fingerprint: digestSchema,
    customer_currency: currencySchema
  }),
  execution_next_v1: strictObject({
    ...dispatch,
    request_id: internalUuidSchema,
    previous_attempt_id: internalUuidSchema,
    expected_ordinal: number2().int().min(2).max(5),
    visible_output: literal(false)
  }),
  execution_begin_v1: strictObject({
    attempt_id: internalUuidSchema,
    permit_epoch: atomsSchema,
    authorization_plan_digest: digestSchema,
    dispatched_digest: digestSchema,
    ...prep
  }),
  execution_abort_v1: strictObject({
    attempt_id: internalUuidSchema,
    permit_epoch: atomsSchema,
    reason: _enum(["CANCELLED", "PREPARE_DISPOSED", "DEADLINE", "QUOTA_EXPIRED"]),
    close_request: boolean2().default(false)
  }),
  execution_query_v1: strictObject({
    kind: _enum([
      "execution_admit_v1",
      "execution_next_v1",
      "execution_begin_v1",
      "execution_abort_v1",
      "execution_quota_v1",
      "execution_abort_recovery_v1"
    ]),
    command_id: internalUuidSchema
  }),
  execution_quota_v1: strictObject({
    attempt_id: internalUuidSchema,
    permit_epoch: atomsSchema,
    action: _enum(["ADOPT", "RENEW", "CLOSE", "RELEASE", "OBSERVE"]),
    reason: _enum(["COMPLETED", "FAILED", "CANCELLED", "DRAINED"]).optional(),
    observation: strictObject({
      channel_id: internalUuidSchema,
      outcome: _enum(["SUCCESS", "FAILURE", "NOT_SENT"]),
      latency_ms: number2().int().min(0).max(3600000)
    }).optional()
  }).refine((value) => value.action === "OBSERVE" === (value.observation !== undefined)),
  execution_resource_commit_v1: strictObject({
    attempt_id: internalUuidSchema,
    permit_epoch: atomsSchema,
    kind: _enum(resourceKinds),
    remote_id: opaqueResourceIdSchema,
    state: _enum(["ACTIVE", "COMPLETED", "FAILED", "CANCELLED"]),
    batch: strictObject({
      endpoint: batchEndpointSchema,
      upstream_model: string2().min(1).max(200),
      items: number2().int().min(1).max(50000),
      ids_sha256: digestSchema,
      ceilings: usageSchema,
      images: number2().int().min(1).max(Number.MAX_SAFE_INTEGER).optional()
    }).optional(),
    input_file_id: publicResourceIdSchema.optional()
  }),
  execution_resource_v1: strictObject({
    ...customerCredential,
    resource_id: publicResourceIdSchema,
    action: _enum(resourceActions),
    auth: dispatchAuthSchema.optional(),
    granted_command_id: internalUuidSchema.optional(),
    remote_ids: array(opaqueResourceIdSchema).min(1).max(3).optional()
  }).refine((value) => value.action === "files" === (value.remote_ids !== undefined)),
  execution_resource_list_v1: strictObject({
    ...customerCredential,
    kind: _enum(resourceKinds),
    limit: number2().int().min(1).max(100),
    after: publicResourceIdSchema.optional()
  }),
  execution_resource_claim_v1: strictObject({ limit: number2().int().min(1).max(16) }),
  execution_resource_poll_v1: strictObject({
    resource_id: publicResourceIdSchema,
    lease_epoch: atomsSchema,
    auth: dispatchAuthSchema
  }),
  execution_resource_release_v1: strictObject({
    resource_id: publicResourceIdSchema,
    lease_epoch: atomsSchema,
    state: _enum(["ACTIVE", "COMPLETED", "FAILED", "CANCELLED"]),
    retry: boolean2()
  })
};
var pluginPackageDataSchema = strictObject({ digest: digestSchema });
var hostAuthorizationPlanV1Schema = strictObject({
  version: literal(1),
  owner: strictObject({
    service: literal("gateway"),
    instance_id: string2().regex(/^[A-Za-z0-9_-]{1,100}$/),
    session_id: internalUuidSchema,
    incarnation_id: internalUuidSchema
  }),
  attempt_id: internalUuidSchema,
  permit_epoch: atomsSchema,
  dispatched_digest: digestSchema,
  dispatch_projection: dispatchProjectionV1Schema
});
var hostAuthorizationPlanV2Schema = hostAuthorizationPlanV1Schema.extend({
  version: literal(2),
  dispatch_projection: dispatchProjectionV2Schema
});
var hostAuthorizationPlanSchema = discriminatedUnion("version", [
  hostAuthorizationPlanV1Schema,
  hostAuthorizationPlanV2Schema
]);
var quotaRecoveryResultSchema = strictObject({
  released: number2().int().min(0).max(100),
  pending: number2().int().min(0).max(100),
  failed: number2().int().min(0).max(100),
  expired: number2().int().min(0).max(100),
  expiry_more: boolean2()
}).refine((result) => result.released + result.failed === result.pending);
var executionReceiptSchema = strictObject({
  command_state: _enum(["COMMITTED", "REJECTED", "NOT_FOUND"]),
  code: string2().regex(/^[a-z_]{1,80}$/).optional(),
  request_id: internalUuidSchema.optional(),
  attempt_id: internalUuidSchema.optional(),
  ordinal: number2().int().positive().optional(),
  state: _enum(["RESERVED", "SEND_GRANTED", "ABORTED", "UNKNOWN", "TERMINAL"]).optional(),
  permit_epoch: atomsSchema.optional(),
  deadline_at: internalInstantSchema.optional(),
  customer_atoms: atomsSchema.optional(),
  customer_currency: currencySchema.optional(),
  supplier_atoms: atomsSchema.optional(),
  supplier_currency: currencySchema.optional(),
  quota_lease_ids: array(digestSchema).max(5).optional(),
  authorization_plan: hostAuthorizationPlanSchema.optional(),
  authorization_plan_digest: digestSchema.optional()
});
var transientSendSchema = strictObject({
  grant_id: internalUuidSchema,
  owner_session_id: internalUuidSchema,
  incarnation_id: internalUuidSchema,
  attempt_id: internalUuidSchema,
  permit_epoch: atomsSchema,
  authorization_plan_digest: digestSchema,
  deadline_at: internalInstantSchema,
  remaining_ms: number2().int().positive().max(30000),
  auth_material: discriminatedUnion("type", [
    strictObject({ type: literal("none") }),
    strictObject({ type: literal("bearer"), value: string2().max(4096) }),
    strictObject({
      type: literal("aws-sigv4"),
      service: _enum(["bedrock"]),
      access_key_id: string2().regex(/^[A-Za-z0-9]{1,128}$/),
      session_token: string2().regex(/^[\x21-\x7e]{1,16384}$/).optional(),
      region: string2().regex(/^[a-z]{2}(?:-[a-z]+)+-\d$/),
      amz_date: string2().regex(/^\d{8}T\d{6}Z$/),
      signing_key: string2().regex(/^[0-9a-f]{64}$/)
    }),
    strictObject({
      type: literal("api-key"),
      header: _enum(["api-key", "x-api-key", "x-goog-api-key"]),
      value: string2().max(4096)
    })
  ])
});
var candidateMetadataSchema = strictObject({
  ref: candidateRefV1Schema,
  origin: string2().max(250),
  upstream_model: string2().max(200),
  credential_ciphertext_sha256: digestSchema,
  config: record(string2(), unknown()),
  cost_currency: currencySchema,
  cost_rates: record(string2(), unknown()),
  cost_ceilings: usageSchema,
  customer_currency: currencySchema,
  customer_rates: record(string2(), unknown()),
  customer_ceilings: usageSchema,
  customer_basis: _enum(["PROVIDER_USAGE", "INPUT_CHARACTERS", "REQUEST_COMPLETION"]),
  request_policy: record(string2(), unknown()),
  routing: strictObject({ priority: number2().int(), weight: number2().positive() }),
  channel_limits: strictObject({
    rpm: number2().int().positive(),
    concurrency: number2().int().positive()
  })
});
var executionContextResponseSchema = strictObject({
  owner: hostAuthorizationPlanV1Schema.shape.owner,
  route_ticket: routeTicketSchema.optional(),
  context_id: internalUuidSchema,
  project_id: internalUuidSchema,
  key_id: internalUuidSchema,
  customer_currency: currencySchema,
  expires_at: internalInstantSchema,
  operation: _enum(operations),
  model: string2().min(1).max(150),
  max_output_tokens: number2().int().positive().max(Number.MAX_SAFE_INTEGER),
  routing_strategy: _enum(["WEIGHTED", "ROUND_ROBIN", "LEAST_LATENCY"]),
  execution_budget: strictObject({ max_attempts: number2().int().min(1).max(5) }),
  scopes: array(strictObject({
    kind: _enum(["organization", "principal", "project", "key"]),
    id: internalUuidSchema,
    rpm: number2().int().positive(),
    tpm: number2().int().positive().max(Number.MAX_SAFE_INTEGER),
    concurrency: number2().int().positive()
  })),
  candidates: array(candidateMetadataSchema).max(5),
  execution_runtimes: executionRuntimesSchema,
  resources: array(strictObject({ resource_id: publicResourceIdSchema, remote_id: opaqueResourceIdSchema })).max(16).optional(),
  batch: strictObject({
    endpoint: batchEndpointSchema,
    ceilings: usageSchema,
    items: number2().int().min(1).max(50000)
  }).optional()
});
var executionReplySchema = strictObject({
  receipt: executionReceiptSchema,
  transient_send: transientSendSchema.optional()
});
var evidenceSources = [
  "execution",
  "execution_outcome",
  "recovery_interruption",
  "async_partial",
  "async_final",
  "batch_completed",
  "batch_cancelled",
  "batch_failed",
  "provider_invoice"
];
var evidenceRevisionSchema = string2().regex(/^[1-9][0-9]{0,37}$/);
var evidenceEventFields = {
  event_id: internalUuidSchema,
  attempt_id: internalUuidSchema,
  origin_identity: string2().regex(/^gateway:[A-Za-z0-9_-]{1,100}$/),
  origin_incarnation: internalUuidSchema,
  origin_session_id: internalUuidSchema,
  permit_epoch: evidenceRevisionSchema,
  source: _enum(evidenceSources),
  source_revision: evidenceRevisionSchema,
  finality: _enum(["FINAL", "PARTIAL", "UNKNOWN", "ESTIMATED", "NOT_EXECUTED"]),
  usage: usageSchema,
  final_dimensions: array(string2()).max(15),
  attempt_state: _enum(["SUCCEEDED", "FAILED", "UNKNOWN", "PARTIAL", "NOT_EXECUTED"]).optional(),
  request_state: _enum(["SUCCEEDED", "FAILED", "CANCELLED", "UNKNOWN"]).optional(),
  error_code: string2().regex(/^[a-z][a-z0-9_]{0,79}$/).optional(),
  provider_request_id: string2().regex(/^[A-Za-z0-9._:/-]{1,256}$/).optional()
};
function refineEvidenceEvent(value, context) {
  const finals = new Set(value.final_dimensions);
  if (finals.size !== value.final_dimensions.length)
    context.addIssue({ code: "custom", message: "Duplicate final dimension" });
  for (const dimension of finals)
    if (!(dimension in value.usage))
      context.addIssue({ code: "custom", message: "Final dimension lacks a quantity" });
  if ((value.finality === "UNKNOWN" || value.finality === "ESTIMATED") && finals.size > 0)
    context.addIssue({ code: "custom", message: "Non-factual evidence cannot be final" });
  if (value.finality === "NOT_EXECUTED" && (Object.keys(value.usage).length > 0 || finals.size > 0 || (value.attempt_state ?? "NOT_EXECUTED") !== "NOT_EXECUTED"))
    context.addIssue({ code: "custom", message: "NOT_EXECUTED carries no quantities" });
}
var coreEvidenceEventV1Schema = strictObject(evidenceEventFields).superRefine(refineEvidenceEvent);
var signedCoreEvidenceEventV1Schema = strictObject({ ...evidenceEventFields, signature: string2().regex(/^[A-Za-z0-9_-]{86}$/) }).superRefine(refineEvidenceEvent);
var coreEvidenceGroupV1Schema = strictObject({
  events: array(signedCoreEvidenceEventV1Schema).min(1).max(64)
});
var coreEvidenceBatchV1Schema = strictObject({
  version: literal(1),
  groups: array(coreEvidenceGroupV1Schema).min(1).max(128)
});
var coreEvidenceGroupResultSchema = discriminatedUnion("status", [
  strictObject({
    status: literal("COMMITTED"),
    receipts: array(strictObject({
      event_id: internalUuidSchema,
      receipt_id: internalUuidSchema,
      outcome: _enum([
        "ACCEPTED",
        "STALE",
        "ESTIMATED",
        "REVISION_REPLAY",
        "CONFLICT",
        "OVERFLOW",
        "QUARANTINED"
      ]),
      duplicate: boolean2()
    })),
    billing: record(string2(), unknown())
  }),
  strictObject({ status: literal("REJECTED"), error: string2() }),
  strictObject({ status: literal("ERROR"), error: string2() })
]);
var resourceCommitResponseSchema = strictObject({ resource_id: publicResourceIdSchema });
var resourceResolutionSchema = strictObject({
  resource_id: publicResourceIdSchema,
  kind: _enum(resourceKinds),
  remote_id: opaqueResourceIdSchema,
  model: string2().min(1).max(150).nullable(),
  state: string2().max(40),
  channel_id: internalUuidSchema,
  package_digest: digestSchema,
  config: record(string2(), unknown()),
  origin: string2().max(250),
  deadline_at: internalInstantSchema,
  batch: strictObject({
    endpoint: batchEndpointSchema,
    items: number2().int().min(1).max(50000),
    ids_sha256: digestSchema
  }).nullable().optional()
});
var resourcePermitResponseSchema = strictObject({
  resolution: resourceResolutionSchema,
  state: _enum(["RESOLVED", "GRANTED", "REPLAYED", "DELETED"]),
  auth_material: transientSendSchema.shape.auth_material.optional(),
  files: record(opaqueResourceIdSchema, publicResourceIdSchema).optional()
});
var resourceClaimResponseSchema = strictObject({
  leases: array(strictObject({
    resource_id: publicResourceIdSchema,
    attempt_id: internalUuidSchema,
    permit_epoch: atomsSchema,
    lease_epoch: atomsSchema,
    resolution: resourceResolutionSchema
  })).max(16)
});
var resourcePollResponseSchema = strictObject({
  auth_material: transientSendSchema.shape.auth_material
});
var resourceListResponseSchema = strictObject({
  data: array(strictObject({
    id: publicResourceIdSchema,
    state: string2().max(40),
    created_at: number2().int().min(0)
  })).max(101)
});
// packages/plugin-sdk/src/abi.ts
var hooks = [
  "describe",
  "prepare",
  "response",
  "error",
  "stream_open",
  "stream_feed",
  "stream_drain",
  "stream_finish",
  "stream_dispose",
  "resource_prepare",
  "resource_response",
  "balance_prepare",
  "balance_parse"
];
var adapterFailureCodes = [
  "invalid_json",
  "json_limit",
  "invalid_object",
  "numeric_limit",
  "invalid_numeric_literal",
  "invalid_upstream_usage",
  "integer_limit",
  "invalid_base64",
  "abi_invalid",
  "usage_alias_conflict",
  "usage_regressed",
  "invalid_finish_reason",
  "incomplete_tool_call",
  "unsupported_semantics",
  "invalid_request",
  "inspection_missing",
  "scalar_budget",
  "invalid_messages",
  "model_unavailable",
  "unsupported_choice_count",
  "invalid_stream",
  "input_ceiling",
  "conflicting_output_ceiling",
  "invalid_output_ceiling",
  "usage_required",
  "invalid_stream_options",
  "upstream_error",
  "invalid_choices",
  "empty_response",
  "invalid_utf8",
  "stream_frame_budget",
  "output_budget",
  "data_after_terminal",
  "premature_terminal",
  "data_after_finish",
  "invalid_content",
  "invalid_tool_call",
  "tool_budget",
  "duplicate_finish",
  "terminal_budget",
  "unsupported_capability",
  "invalid_model",
  "stream_state",
  "stream_truncated",
  "batch_input_budget",
  "drain_input"
];
var base64Schema = string2().regex(/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/);
var identity = string2().min(1).max(200);
var sessionSchema = object({
  id: uuid2(),
  tenant: identity,
  attempt: identity,
  incarnation: uuid2(),
  plugin: digestSchema,
  config: digestSchema,
  sequence: number2().int().min(0).max(Number.MAX_SAFE_INTEGER)
}).strict();
var inputSchema = object({
  abi_version: literal(1),
  hook: _enum(hooks),
  session: sessionSchema,
  config: record(string2(), unknown()),
  payload: base64Schema,
  output_budget: number2().int().min(1).max(16 << 20)
}).strict();
var jsonMetadataSchema = object({
  protocol: _enum(protocols).optional(),
  operation: _enum(operations).optional(),
  model: identity.optional(),
  stream: boolean2().optional(),
  content: literal("multipart").optional(),
  action: _enum(["get", "delete", "cancel", "input_items"]).optional(),
  input_characters: string2().regex(/^(0|[1-9][0-9]{0,37})$/).optional(),
  resource_id: string2().regex(/^(response|file|batch|video)_[0-9a-f]{32}$/).optional()
}).strict().refine((value) => value.model !== undefined || value.action !== undefined);
var capabilitiesSchema = object({
  operations: array(_enum(operations)).min(1).max(32),
  dimensions: array(_enum([...dimensions, "reasoning_tokens"])).max(32),
  protocols: array(_enum(["chat", "responses", "messages", "gemini"])).max(4),
  hooks: array(_enum(hooks)).min(1).max(32),
  auth: array(_enum(["none", "bearer", "api-key", "google-oauth", "aws-sigv4"])).min(1).max(5),
  resources: boolean2(),
  balance: boolean2(),
  stream_codec: _enum(["sse", "aws-eventstream", "none"])
}).strict();
var headerSchema = record(string2().regex(/^(?:content-type|accept|openai-beta|anthropic-version|x-[a-z0-9-]{1,60})$/), string2().max(1024).refine((s) => !/[\r\n\0]/.test(s)));
var editPlanSchema = object({
  document: uuid2(),
  edits: array(discriminatedUnion("op", [
    object({
      op: literal("set"),
      pointer: string2().max(2048),
      value: string2().max(4096)
    }).strict(),
    object({ op: literal("remove"), pointer: string2().max(2048) }).strict()
  ])).max(32)
}).strict();
var composePlanSchema = object({
  document: uuid2(),
  compose: object({
    template: string2().max(256 << 10),
    slots: array(union([
      object({
        at: string2().min(1).max(2048),
        from: string2().max(2048),
        mode: _enum(["value", "parse", "stringify"])
      }).strict(),
      object({
        at: string2().min(1).max(2048),
        sources: array(string2().max(2048)).min(1).max(256),
        mode: literal("concat")
      }).strict()
    ])).max(4096)
  }).strict()
}).strict();
var jsonPlanSchema = union([editPlanSchema, composePlanSchema]);
var framePlanSchema = object({
  handle: uuid2(),
  disposition: _enum(["emit", "hold", "drop"]),
  body: jsonPlanSchema.optional(),
  data_only: literal(true).optional(),
  extra: array(string2().min(1).max(4096).refine((s) => !/[\r\n\0]/.test(s))).max(4).optional()
}).strict();
var preparedSchema = object({
  method: _enum(["GET", "POST", "DELETE"]),
  path: string2().min(1).max(2048).refine((s) => /^\/(?!\/)[A-Za-z0-9_./?=&%:-]*$/.test(s) && !/%(?:2f|5c|2e)/i.test(s) && !s.split(/[/?]/).some((x) => x === "." || x === "..") && !s.includes("://")),
  headers: headerSchema,
  body: jsonPlanSchema,
  body_format: _enum(["json", "multipart"]).optional(),
  binary: object({ usage: usageSchema.optional() }).strict().optional(),
  auth: discriminatedUnion("type", [
    object({ type: literal("none") }).strict(),
    object({ type: literal("bearer") }).strict(),
    object({ type: literal("google-oauth") }).strict(),
    object({ type: literal("aws-sigv4"), service: _enum(["bedrock"]) }).strict(),
    object({
      type: literal("api-key"),
      header: _enum(["api-key", "x-api-key", "x-goog-api-key"])
    }).strict()
  ]),
  manifest: object({
    operation: _enum(operations),
    model: identity,
    upstream_model: identity,
    stream: boolean2(),
    ceilings: usageSchema,
    images: string2().regex(/^[1-9][0-9]{0,15}$/).optional(),
    quantities: usageSchema.optional(),
    input_bytes: number2().int().min(0).max(16 << 20)
  }).strict()
}).strict();
var resourceRequestSchema = preparedSchema.pick({ method: true, path: true, headers: true, auth: true }).strict();
var terminalSchema = object({ kind: _enum(["complete", "incomplete", "pending"]), bytes: base64Schema }).strict();
var resultSchema = discriminatedUnion("kind", [
  object({
    abi_version: literal(1),
    kind: literal("buffer_append"),
    target: uuid2().optional(),
    document: uuid2(),
    pointers: array(string2().max(2048)).min(1).max(16)
  }).strict(),
  object({
    abi_version: literal(1),
    kind: literal("buffer_check"),
    handles: array(uuid2()).min(1).max(16),
    seal: boolean2()
  }).strict(),
  object({
    abi_version: literal(1),
    kind: literal("inspect"),
    document: uuid2(),
    pointers: array(string2().max(2048)).min(1).max(16)
  }).strict(),
  object({
    abi_version: literal(1),
    kind: literal("description"),
    sdk_version: literal("1.0.0"),
    capabilities: capabilitiesSchema
  }).strict(),
  object({ abi_version: literal(1), kind: literal("prepared"), request: preparedSchema }).strict(),
  object({
    abi_version: literal(1),
    kind: literal("resource_request"),
    request: resourceRequestSchema
  }).strict(),
  object({
    abi_version: literal(1),
    kind: literal("output"),
    consumed: number2().int().min(0).max(16 << 20),
    chunks: array(base64Schema).max(128),
    body: jsonPlanSchema.optional(),
    frame: framePlanSchema.optional(),
    usage: usageSchema.optional(),
    finality: _enum(["FINAL", "PARTIAL", "UNKNOWN", "ESTIMATED"]),
    terminal: terminalSchema.optional(),
    needs_input: boolean2(),
    resource: object({
      kind: _enum(["response", "file", "batch", "video"]),
      remote_id: opaqueResourceIdSchema
    }).strict().optional()
  }).strict(),
  object({ abi_version: literal(1), kind: literal("disposed") }).strict(),
  object({
    abi_version: literal(1),
    kind: literal("failure"),
    status: union([literal(400), literal(413), literal(422), literal(502)]),
    code: _enum(adapterFailureCodes),
    usage: usageSchema.optional(),
    finality: _enum(["FINAL", "PARTIAL", "UNKNOWN", "ESTIMATED"]).optional()
  }).strict()
]);
function sha256(bytes) {
  return new Bun.CryptoHasher("sha256").update(bytes).digest("hex");
}
// packages/plugin-sdk/src/config.ts
var scalar = discriminatedUnion("type", [
  object({
    type: literal("string"),
    maxLength: number2().int().min(1).max(2048),
    enum: array(string2().max(200)).min(1).max(100).optional()
  }).strict(),
  object({
    type: literal("integer"),
    minimum: number2().int().min(0),
    maximum: number2().int().max(Number.MAX_SAFE_INTEGER)
  }).strict(),
  object({ type: literal("boolean") }).strict()
]);
var map = object({
  type: literal("object"),
  maxProperties: number2().int().min(1).max(1000),
  additionalProperties: scalar
}).strict();
var configSchemaSchema = object({
  type: literal("object"),
  additionalProperties: literal(false),
  required: array(string2().regex(/^[a-z][a-z0-9_]{0,63}$/)).max(32),
  properties: record(string2().regex(/^[a-z][a-z0-9_]{0,63}$/), union([scalar, map]))
}).strict();
function validateConfig(schema, value) {
  const source = record(string2(), unknown()).parse(value);
  for (const key of schema.required)
    if (!Object.hasOwn(source, key))
      throw new Error("CONFIG_REQUIRED");
  function validate(rule, v) {
    if (rule.type === "string") {
      if (typeof v !== "string" || v.length > rule.maxLength || rule.enum && !rule.enum.includes(v))
        throw new Error("CONFIG_VALUE");
    } else if (rule.type === "integer") {
      if (!Number.isSafeInteger(v) || v < rule.minimum || v > rule.maximum)
        throw new Error("CONFIG_VALUE");
    } else if (rule.type === "boolean") {
      if (typeof v !== "boolean")
        throw new Error("CONFIG_VALUE");
    } else {
      const entries = Object.entries(record(string2().min(1).max(200), unknown()).parse(v));
      if (entries.length > rule.maxProperties)
        throw new Error("CONFIG_VALUE");
      for (const [, child] of entries)
        validate(rule.additionalProperties, child);
    }
  }
  if (Object.keys(schema.properties).length > 32 || schema.required.some((key) => !Object.hasOwn(schema.properties, key)))
    throw new Error("CONFIG_SCHEMA");
  for (const [key, child] of Object.entries(source)) {
    const rule = schema.properties[key];
    if (!rule || /^(?:secret|credential|password|authorization|api_key|access_token|session_token|refresh_token)(?:_|$)/i.test(key))
      throw new Error("CONFIG_FIELD");
    validate(rule, child);
  }
  return JSON.parse(JSON.stringify(source));
}
// packages/plugin-sdk/src/package.ts
import { verify } from "crypto";

// packages/plugin-sdk/src/fixtures.ts
var expected = record(string2(), unknown()).refine((value) => typeof value.kind === "string" && Object.keys(value).length > 1);
var fixtureSuiteSchema = object({
  format: literal(1),
  config: record(string2(), unknown()),
  cases: array(object({
    name: string2().min(1).max(200),
    steps: array(discriminatedUnion("action", [
      object({
        action: literal("invoke"),
        hook: _enum(hooks),
        input: base64Schema,
        expected
      }).strict(),
      object({
        action: literal("json"),
        hook: _enum(["prepare", "response", "error", "resource_response"]),
        metadata: record(string2(), unknown()),
        body: base64Schema,
        expected,
        expected_body: base64Schema.optional()
      }).strict(),
      object({
        action: literal("cancel"),
        hook: _enum(hooks),
        input: base64Schema,
        expected_error: literal("CALL_CANCELLED")
      }).strict()
    ])).min(1).max(1000)
  }).strict()).min(1).max(1000)
}).strict();
// node_modules/.bun/lossless-json@4.3.3/node_modules/lossless-json/lib/esm/utils.js
function isInteger(value) {
  return INTEGER_REGEX.test(value);
}
var INTEGER_REGEX = /^-?[0-9]+$/;
function isNumber(value) {
  return NUMBER_REGEX.test(value);
}
var NUMBER_REGEX = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/;
function isSafeNumber(value, config) {
  if (isInteger(value)) {
    return Number.isSafeInteger(Number.parseInt(value, 10));
  }
  const num = Number.parseFloat(value);
  if (Number.isInteger(num) && !Number.isSafeInteger(num)) {
    return false;
  }
  const parsed = String(num);
  if (value === parsed) {
    return true;
  }
  const valueDigits = extractSignificantDigits(value);
  const parsedDigits = extractSignificantDigits(parsed);
  if (valueDigits === parsedDigits) {
    return true;
  }
  if (config?.approx === true) {
    const requiredDigits = 14;
    if (parsedDigits.length >= requiredDigits && valueDigits.startsWith(parsedDigits.substring(0, requiredDigits))) {
      return true;
    }
  }
  return false;
}
var UnsafeNumberReason = /* @__PURE__ */ function(UnsafeNumberReason) {
  UnsafeNumberReason["underflow"] = "underflow";
  UnsafeNumberReason["overflow"] = "overflow";
  UnsafeNumberReason["truncate_integer"] = "truncate_integer";
  UnsafeNumberReason["truncate_float"] = "truncate_float";
  return UnsafeNumberReason;
}({});
function getUnsafeNumberReason(value) {
  if (isSafeNumber(value, {
    approx: false
  })) {
    return;
  }
  if (isInteger(value)) {
    return UnsafeNumberReason.truncate_integer;
  }
  const num = Number.parseFloat(value);
  if (!Number.isFinite(num)) {
    return UnsafeNumberReason.overflow;
  }
  if (num === 0) {
    return UnsafeNumberReason.underflow;
  }
  return UnsafeNumberReason.truncate_float;
}
function extractSignificantDigits(value) {
  const {
    start,
    end
  } = getSignificantDigitRange(value);
  const digits = value.substring(start, end);
  const dot = digits.indexOf(".");
  if (dot === -1) {
    return digits;
  }
  return digits.substring(0, dot) + digits.substring(dot + 1);
}
function getSignificantDigitRange(value) {
  let start = 0;
  if (value[0] === "-") {
    start++;
  }
  while (value[start] === "0" || value[start] === ".") {
    start++;
  }
  let end = value.lastIndexOf("e");
  if (end === -1) {
    end = value.lastIndexOf("E");
  }
  if (end === -1) {
    end = value.length;
  }
  while ((value[end - 1] === "0" || value[end - 1] === ".") && end > start) {
    end--;
  }
  return {
    start,
    end
  };
}

// node_modules/.bun/lossless-json@4.3.3/node_modules/lossless-json/lib/esm/LosslessNumber.js
var losslessNumberMarker = Symbol.for("lossless-json.LosslessNumber");

class LosslessNumber {
  value;
  isLosslessNumber = true;
  get [losslessNumberMarker]() {
    return true;
  }
  constructor(value) {
    if (!isNumber(value)) {
      throw new Error(`Invalid number (value: "${value}")`);
    }
    this.value = value;
  }
  valueOf() {
    const unsafeReason = getUnsafeNumberReason(this.value);
    if (unsafeReason === undefined || unsafeReason === UnsafeNumberReason.truncate_float) {
      return Number.parseFloat(this.value);
    }
    if (isInteger(this.value)) {
      return BigInt(this.value);
    }
    throw new Error(`Cannot safely convert to number: the value '${this.value}' would ${unsafeReason} and become ${Number.parseFloat(this.value)}`);
  }
  toString() {
    return this.value;
  }
}
// packages/plugin-sdk/src/guest.ts
class AdapterFailure extends Error {
  status;
  code;
  constructor(status, code) {
    super(code);
    this.status = status;
    this.code = code;
  }
}
function exactParse(source, status = 502, numericMode = "lossless") {
  let cursor = 0, fields = 0;
  const number = /-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/y;
  function space() {
    while (cursor < source.length && /[\x20\t\r\n]/.test(source[cursor]))
      cursor++;
  }
  function string() {
    const start = cursor++;
    for (;; ) {
      const end = source.indexOf('"', cursor);
      if (end < 0)
        throw 0;
      let slashes = 0;
      for (let i = end - 1;i >= start && source[i] === "\\"; i--)
        slashes++;
      cursor = end + 1;
      if (slashes % 2 === 0)
        return JSON.parse(source.slice(start, cursor));
    }
  }
  function value(depth) {
    if (depth > 64 || ++fields > 1e5)
      throw new AdapterFailure(status, "json_limit");
    space();
    if (source[cursor] === '"')
      return string();
    if (source[cursor] === "{" || source[cursor] === "[") {
      const array = source[cursor++] === "[", end = array ? "]" : "}";
      const result = array ? [] : Object.create(null);
      const seen = new Set;
      space();
      if (source[cursor] === end) {
        cursor++;
        return result;
      }
      for (;; ) {
        space();
        if (array)
          result.push(value(depth + 1));
        else {
          if (source[cursor] !== '"')
            throw 0;
          const key = string();
          if (seen.has(key))
            throw 0;
          seen.add(key);
          space();
          if (source[cursor++] !== ":")
            throw 0;
          result[key] = value(depth + 1);
        }
        space();
        const next = source[cursor++];
        if (next === end)
          return result;
        if (next !== ",")
          throw 0;
      }
    }
    for (const [keyword, literal] of [
      ["true", true],
      ["false", false],
      ["null", null]
    ])
      if (source.startsWith(keyword, cursor)) {
        cursor += keyword.length;
        return literal;
      }
    number.lastIndex = cursor;
    const match = number.exec(source);
    if (!match)
      throw 0;
    cursor = number.lastIndex;
    if (match[0].length > 200)
      throw new AdapterFailure(status, "numeric_limit");
    return numericMode === "number" ? Number(match[0]) : new LosslessNumber(match[0]);
  }
  try {
    const result = value(0);
    space();
    if (cursor !== source.length)
      throw 0;
    return result;
  } catch (error) {
    if (error instanceof AdapterFailure)
      throw error;
    throw new AdapterFailure(status, "invalid_json");
  }
}

// packages/plugin-sdk/src/module.ts
var modules = new WeakMap;
function adoptPluginModule(bytes, hash) {
  const module = Object.freeze({});
  modules.set(module, { bytes, info: Object.freeze({ hash, byteLength: bytes.byteLength }) });
  return module;
}
function ownPluginModule(bytes) {
  const owned = new Uint8Array(bytes);
  return adoptPluginModule(owned, sha256(owned));
}
function record2(module) {
  const owned = modules.get(module);
  if (!owned)
    throw new Error("MODULE_NOT_OWNED");
  return owned;
}
function pluginModuleInfo(module) {
  return record2(module).info;
}
function pluginModuleBase64(module) {
  return Buffer.from(record2(module).bytes).toString("base64");
}

// packages/plugin-sdk/src/package.ts
var manifestSchema = object({
  format: literal(1),
  id: string2().regex(/^[a-z][a-z0-9.-]{1,100}$/),
  version: string2().regex(/^\d+\.\d+\.\d+$/),
  abi_version: literal(1),
  sdk_version: literal("1.0.0"),
  module: literal("module.wasm"),
  entrypoint: string2().regex(/^[A-Za-z][A-Za-z0-9_]{0,63}$/),
  config_schema: literal("config.schema.json"),
  capabilities: capabilitiesSchema
}).strict();
var envelopeSchema = object({
  format: literal(1),
  files: array(object({ path: string2().min(1).max(200), data: base64Schema }).strict()).min(6).max(128),
  signature: object({
    algorithm: literal("Ed25519"),
    key_id: string2().regex(/^[A-Za-z0-9_.-]{1,100}$/),
    value: base64Schema
  }).strict()
}).strict();
var verified = new WeakMap;
function freezeMetadata(value) {
  if (value && typeof value === "object") {
    for (const child of Object.values(value))
      freezeMetadata(child);
    Object.freeze(value);
  }
  return value;
}
function verifiedPackageRuntime(pkg) {
  const original = verified.get(pkg);
  if (!original)
    throw new Error("PACKAGE_NOT_VERIFIED");
  return original.runtime;
}
function verifiedPackageSnapshot(pkg) {
  const original = verified.get(pkg);
  if (!original)
    throw new Error("PACKAGE_NOT_VERIFIED");
  return structuredClone(original.snapshot);
}
function packageDigest(files) {
  if (files.length < 6 || files.length > 128)
    throw new Error("PACKAGE_FILES");
  const hasher = new Bun.CryptoHasher("sha256").update("gateway-plugin-package-v1\x00");
  const seen = new Set;
  let total = 0, fixtures = 0;
  for (const file of [...files].sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0)) {
    if (!/^[A-Za-z0-9][A-Za-z0-9_./-]{0,199}$/.test(file.path) || file.path.split("/").some((p) => p === "." || p === ".." || !p) || file.path.split("/").length > 4 || seen.has(file.path))
      throw new Error("PACKAGE_PATH");
    seen.add(file.path);
    total += file.bytes.length;
    if (file.path.startsWith("fixtures/"))
      fixtures += file.bytes.length;
    const limit = file.path === "module.wasm" ? 8 << 20 : file.path.startsWith("fixtures/") ? 2 << 20 : 256 << 10;
    if (file.bytes.length > limit || total > 32 << 20 || fixtures > 2 << 20)
      throw new Error("PACKAGE_BUDGET");
    hasher.update(`${new TextEncoder().encode(file.path).length}:${file.path}:${file.bytes.length}:`).update(file.bytes);
  }
  for (const required of [
    "manifest.json",
    "module.wasm",
    "config.schema.json",
    "LICENSE",
    "provenance.json",
    "fixtures/cases.json"
  ])
    if (!seen.has(required))
      throw new Error("PACKAGE_MISSING");
  return hasher.digest("hex");
}
function verifyPackage(bytes, trust) {
  if (bytes.length > 44 << 20)
    throw new Error("PACKAGE_BUDGET");
  const envelope = envelopeSchema.parse(exactParse(new TextDecoder("utf-8", { fatal: true }).decode(bytes), 502, "number"));
  const files = envelope.files.map((file) => ({
    path: file.path,
    bytes: new Uint8Array(Buffer.from(file.data, "base64"))
  }));
  const digest = packageDigest(files);
  const key = trust.get(envelope.signature.key_id);
  if (!key || key.type !== "public" || key.asymmetricKeyType !== "ed25519" || !verify(null, Buffer.from(digest, "hex"), key, Buffer.from(envelope.signature.value, "base64")))
    throw new Error("PACKAGE_SIGNATURE");
  const get = (path) => files.find((f) => f.path === path).bytes;
  const decode = (path) => exactParse(new TextDecoder("utf-8", { fatal: true }).decode(get(path)), 502, "number");
  const manifest = manifestSchema.parse(decode("manifest.json"));
  const configSchema = configSchemaSchema.parse(decode("config.schema.json"));
  object({
    source: string2().min(1).max(2048),
    tools: record(string2(), string2().max(2048)),
    licenses: array(string2().min(1).max(200)).min(1).max(20)
  }).strict().parse(decode("provenance.json"));
  fixtureSuiteSchema.parse(decode("fixtures/cases.json"));
  if (!get("LICENSE").length)
    throw new Error("PACKAGE_LICENSE");
  const module = get("module.wasm");
  if (module.length < 8 || !module.slice(0, 8).every((n, i) => n === [0, 97, 115, 109, 1, 0, 0, 0][i]))
    throw new Error("PACKAGE_MODULE");
  const result = {
    digest,
    signingKeyId: envelope.signature.key_id,
    moduleHash: sha256(module),
    module,
    manifest,
    configSchema,
    files
  };
  const snapshot = structuredClone(result);
  const runtime = Object.freeze({
    digest: snapshot.digest,
    signingKeyId: snapshot.signingKeyId,
    signingKeyDigest: sha256(key.export({ format: "der", type: "spki" })),
    module: adoptPluginModule(snapshot.module, snapshot.moduleHash),
    manifest: freezeMetadata(snapshot.manifest),
    configSchema: freezeMetadata(snapshot.configSchema)
  });
  verified.set(result, { snapshot, runtime });
  return result;
}
// packages/plugin-sdk/src/release-policy.ts
import { createPublicKey } from "crypto";
var openAIChatReleaseId = "gateway.openai-chat-1.9.2";
var anthropicMessagesReleaseId = "gateway.anthropic-messages-1.2.0";
var bedrockAnthropicReleaseId = "gateway.bedrock-anthropic-1.1.0";
var geminiGenerateReleaseId = "gateway.gemini-generate-1.2.0";
var minimaxMusicReleaseId = "gateway.minimax-music-1.0.0";
var bundledReleaseIds = [
  openAIChatReleaseId,
  anthropicMessagesReleaseId,
  geminiGenerateReleaseId,
  bedrockAnthropicReleaseId,
  minimaxMusicReleaseId
];
var digest = string2().regex(/^[a-f0-9]{64}$/);
var keyId = string2().regex(/^[A-Za-z0-9_.-]{1,100}$/);
var publisherNamespaceSchema = string2().regex(/^[a-z][a-z0-9-]{1,40}$/).refine((value) => value !== "gateway");
var releasePolicySchema = object({
  format: literal(1),
  expires_at: exports_iso.datetime(),
  revoked: boolean2(),
  keys: array(object({
    id: keyId,
    public_key: string2().min(1).max(4096),
    not_before: exports_iso.datetime(),
    expires_at: exports_iso.datetime(),
    revoked: boolean2(),
    purposes: array(_enum(["package", "release"])).min(1),
    release_ids: array(_enum(bundledReleaseIds)).min(1)
  }).strict()).min(1).max(100),
  releases: array(object({
    release_id: _enum(bundledReleaseIds),
    descriptor_digest: digest,
    package_digest: digest,
    abi_version: literal(1),
    config_schema_digest: digest,
    fixture_digest: digest,
    validation_policy_digest: digest,
    runtime_digest: digest,
    revoked: boolean2()
  }).strict()).min(1).max(100),
  publishers: array(object({
    id: keyId,
    public_key: string2().min(1).max(4096),
    not_before: exports_iso.datetime(),
    expires_at: exports_iso.datetime(),
    revoked: boolean2(),
    namespace: publisherNamespaceSchema
  }).strict()).max(100).default([])
}).strict();
function publisherAdmits(publisher, manifest) {
  return manifest.id.startsWith(`${publisher.namespace}.`);
}
function packageTrust(policy, now = Date.now()) {
  if (policy.revoked || Date.parse(policy.expires_at) <= now)
    throw new Error("RELEASE_POLICY_EXPIRED");
  const ids = [...policy.keys, ...policy.publishers].map((k) => k.id);
  if (new Set(ids).size !== ids.length || new Set(policy.releases.map((r) => r.release_id)).size !== policy.releases.length)
    throw new Error("RELEASE_POLICY_DUPLICATE");
  const usable = policy.keys.filter((key) => !key.revoked && key.purposes.includes("package") && Date.parse(key.not_before) <= now && Date.parse(key.expires_at) > now);
  const publicKeys = new Map;
  const periods = new Map;
  const policyUntil = Date.parse(policy.expires_at);
  for (const key of usable) {
    const publicKey = createPublicKey(key.public_key);
    if (publicKey.asymmetricKeyType !== "ed25519")
      throw new Error("RELEASE_KEY_TYPE");
    publicKeys.set(key.id, publicKey);
    periods.set(key.id, {
      from: Date.parse(key.not_before),
      until: Date.parse(key.expires_at),
      digest: sha256(publicKey.export({ format: "der", type: "spki" }))
    });
  }
  const byDigest = new Map;
  for (const release of policy.releases) {
    if (release.revoked)
      continue;
    const keys = byDigest.get(release.package_digest) ?? new Map;
    for (const key of usable)
      if (key.release_ids.includes(release.release_id))
        keys.set(key.id, publicKeys.get(key.id));
    byDigest.set(release.package_digest, keys);
  }
  const publishers = new Map;
  for (const publisher of policy.publishers) {
    if (publisher.revoked || Date.parse(publisher.not_before) > now || Date.parse(publisher.expires_at) <= now)
      continue;
    const publicKey = createPublicKey(publisher.public_key);
    if (publicKey.asymmetricKeyType !== "ed25519")
      throw new Error("RELEASE_KEY_TYPE");
    publishers.set(publisher.id, { key: publicKey, namespace: publisher.namespace });
  }
  return Object.assign((packageDigest) => {
    const keys = new Map(byDigest.get(packageDigest));
    for (const [id, publisher] of publishers)
      keys.set(id, publisher.key);
    return keys;
  }, {
    isPlatform(pkg, at = Date.now()) {
      const original = verifiedPackageRuntime(pkg);
      const period = periods.get(original.signingKeyId);
      return byDigest.get(original.digest)?.has(original.signingKeyId) === true && period !== undefined && period.digest === original.signingKeyDigest && at >= period.from && at < Math.min(policyUntil, period.until);
    },
    admits(pkg) {
      if (byDigest.get(pkg.digest)?.has(pkg.signingKeyId))
        return true;
      const publisher = publishers.get(pkg.signingKeyId);
      return publisher !== undefined && publisherAdmits(publisher, pkg.manifest);
    }
  });
}
// packages/plugin-sdk/src/builtin-artifact.ts
var digest2 = string2().regex(/^[a-f0-9]{64}$/);
var sourcePath = string2().max(1000).refine((path) => /^(?:packages\/|scripts\/|package\.json$|tsconfig\.json$|bun\.lock$|\$dependency\/|\$generated-entry$)/.test(path) && !path.includes("\\") && !path.split("/").some((part) => part === ".." || part === "." || !part));
var sources = record(sourcePath, digest2).refine((value) => Object.keys(value).length <= 4096);
var record3 = strictObject({
  release_id: string2().regex(/^gateway\.[a-z-]+-\d+\.\d+\.\d+$/),
  package_digest: digest2,
  module_hash: digest2,
  manifest_digest: digest2,
  config_schema_digest: digest2,
  sources,
  verification_runs: tuple([digest2, digest2, digest2])
}).refine((value) => value.verification_runs.every((run) => run === value.module_hash));
var common = {
  format: literal(1),
  abi_version: literal(1),
  state_version: literal(1),
  runtime: literal("1.4.4"),
  worker_digest: digest2,
  sources,
  compiler_digest: digest2,
  binaryen_archive_digest: digest2,
  records: array(record3).min(1).max(16)
};
var builtinWorkerRegistrySchema = strictObject({
  ...common,
  runtime_digest: digest2,
  artifact_digest: digest2
});
var builtinWorkerProofSchema = strictObject({
  ...common,
  worker_base64: string2().min(1).max(24 << 20)
});
function builtinWorkerArtifactDigest(worker, runtime) {
  return sha256(JSON.stringify(["stg.internal.builtin-worker-artifact", "1", worker, runtime, "1", "1"]));
}
function parseBuiltinWorkerArtifact(input, code, runtimeDigest) {
  const result = builtinWorkerRegistrySchema.safeParse(input);
  if (!result.success || code.length > 16 << 20 || result.data.worker_digest !== sha256(code) || result.data.runtime_digest !== runtimeDigest || result.data.artifact_digest !== builtinWorkerArtifactDigest(result.data.worker_digest, runtimeDigest))
    throw new Error("BUILTIN_ARTIFACT_INVALID");
  return result.data;
}
// packages/plugin-host/src/supervisor.ts
class PluginHostError extends Error {
  code;
  diagnostics;
  constructor(code, diagnostics) {
    super(code);
    this.code = code;
    this.diagnostics = diagnostics;
    this.name = "PluginHostError";
  }
}
function createPluginSupervisor(options) {
  if (!isAbsolute(options.executable) || !["darwin", "linux"].includes(process.platform))
    throw new PluginHostError("CONFIG_INVALID");
  const native = { ...options.native, queue: 0 };
  const bounds = {
    slots: [1, 64],
    queue: [0, 0],
    maxBufferedOutputBytes: [4096, 256 << 20],
    maxPendingBytes: [4096, 256 << 20],
    maxFrameBytes: [4096, 48 << 20],
    maxModuleBytes: [8, 32 << 20],
    maxCacheBytes: [8, 256 << 20],
    maxModules: [1, 32],
    maxInputBytes: [1, 16 << 20],
    maxOutputBytes: [1, 16 << 20],
    maxStateBytes: [1, 1 << 20],
    memoryPages: [64, 1024],
    tableElements: [1, 65536],
    compileMs: [1, 30000],
    callMs: [1, 30000],
    writeMs: [1, 30000],
    startupMs: [1, 30000],
    maxTotalRssBytes: [32 << 20, 8 * 1024 ** 3],
    maxWorkerRssBytes: [32 << 20, 4 * 1024 ** 3],
    goMemoryBytes: [16 << 20, 2 * 1024 ** 3]
  };
  for (const [key, value] of Object.entries(options.native ?? {})) {
    const range = bounds[key];
    if (!range || !Number.isSafeInteger(value) || value < range[0] || value > range[1])
      throw new PluginHostError("CONFIG_INVALID");
  }
  if ((native.maxCacheBytes ?? 32 << 20) < (native.maxModuleBytes ?? 8 << 20) || (native.maxTotalRssBytes ?? 1024 ** 3) < (native.maxWorkerRssBytes ?? 512 << 20))
    throw new PluginHostError("CONFIG_INVALID");
  for (const size of [
    native.maxModuleBytes ?? 8 << 20,
    (native.maxInputBytes ?? 256 << 10) + (native.maxStateBytes ?? 256 << 10),
    (native.maxOutputBytes ?? 256 << 10) + (native.maxStateBytes ?? 256 << 10)
  ])
    if ((native.maxFrameBytes ?? 12 << 20) < Math.ceil(size / 3) * 4 + 4096)
      throw new PluginHostError("CONFIG_INVALID");
  const limits = {
    maxPending: options.maxPending ?? 32,
    maxPendingBytes: options.maxPendingBytes ?? 64 << 20,
    maxWriteBytes: options.maxWriteBytes ?? 16 << 20,
    maxFrameBytes: options.maxFrameBytes ?? native.maxFrameBytes ?? 12 << 20,
    queueMs: options.queueMs ?? 1000,
    heartbeatMs: options.heartbeatMs ?? 3000,
    closeMs: options.closeMs ?? 2000,
    maxRestarts: options.maxRestarts ?? 2
  };
  for (const [key, value] of Object.entries(limits))
    if (!Number.isSafeInteger(value) || value < (key === "maxRestarts" ? 0 : 1))
      throw new PluginHostError("CONFIG_INVALID");
  if (limits.maxFrameBytes > 48 << 20 || limits.maxWriteBytes > 256 << 20 || limits.maxPendingBytes > 256 << 20 || limits.maxPending > 1024 || limits.queueMs > 30000 || limits.closeMs > 30000 || limits.maxRestarts > 10 || limits.heartbeatMs < 1200 || limits.heartbeatMs > 30000)
    throw new PluginHostError("CONFIG_INVALID");
  let connection, starts = 0, closed = false;
  const retirements = new Set;
  const listeners = new Set;
  const slots = native.slots ?? 8;
  function killGroup(c) {
    if (c.process.pid)
      try {
        process.kill(-c.process.pid, "SIGKILL");
      } catch (error) {
        if (error.code !== "ESRCH")
          c.process.kill("SIGKILL");
      }
  }
  function diagnostic(c, cmd) {
    const elapsed = (start, end = performance.now()) => Math.min(60000, Math.max(0, Math.round(end - start)));
    return {
      phase: c.readyAt === undefined ? "startup" : cmd?.phase ?? "idle",
      ...cmd ? { op: cmd.op } : {},
      frameBytes: c.inflight?.cmd.bytes ?? 0,
      startupMs: elapsed(c.started, c.readyAt),
      writeMs: c.inflight ? elapsed(c.inflight.started) : 0,
      connection: c.id
    };
  }
  function settle(c, cmd, reply, error) {
    if (!c.pending.delete(cmd.id))
      return;
    clearTimeout(cmd.timer);
    if (cmd.abort && cmd.signal)
      cmd.signal.removeEventListener("abort", cmd.abort);
    c.pendingBytes -= cmd.bytes;
    const queued = c.queue.indexOf(cmd);
    if (queued >= 0)
      c.queue.splice(queued, 1);
    const writing = c.writes.indexOf(cmd);
    if (writing >= 0) {
      c.writes.splice(writing, 1);
      c.writeBytes -= cmd.frame.length;
    }
    if (c.inflight?.cmd !== cmd)
      cmd.frame = Buffer.alloc(0);
    if (!["startup", "queued"].includes(cmd.phase) && cmd.execution)
      c.active--;
    if (error)
      cmd.reject(new PluginHostError(error, c.failure ?? diagnostic(c, cmd)));
    else
      cmd.resolve(reply);
    pump(c);
  }
  function fail(c, code) {
    if (c.retire)
      return c.retire;
    c.failure = diagnostic(c, c.inflight?.cmd ?? c.pending.values().next().value);
    c.failureCode = code;
    c.dead = true;
    clearTimeout(c.startup);
    delete c.startup;
    clearInterval(c.watch);
    delete c.watch;
    clearTimeout(c.inflight?.timer);
    delete c.inflight;
    for (const cmd of c.pending.values())
      settle(c, cmd, undefined, code);
    c.queue.length = 0;
    c.writes.length = 0;
    c.buffer = Buffer.alloc(0);
    c.loaded.clear();
    c.writeBytes = 0;
    killGroup(c);
    c.process.stdin.destroy();
    c.process.stdout.destroy();
    c.process.stderr.destroy();
    c.retire = c.exit.then(() => {
      killGroup(c);
      c.process.removeAllListeners();
      c.process.stdin.removeAllListeners();
      c.process.stdout.removeAllListeners();
      c.process.stderr.removeAllListeners();
    });
    retirements.add(c.retire);
    c.retire.finally(() => retirements.delete(c.retire));
    for (const listener of listeners) {
      try {
        listener(c.id);
      } catch {}
    }
    return c.retire;
  }
  function read(c, chunk) {
    if (c.dead)
      return;
    let offset = 0;
    while (offset < chunk.length) {
      const end = chunk.indexOf(10, offset);
      const length = (end < 0 ? chunk.length : end + 1) - offset;
      if (c.buffer.length + length > limits.maxFrameBytes) {
        fail(c, "FRAME_BUDGET");
        return;
      }
      const part = chunk.subarray(offset, offset + length);
      const frame = c.buffer.length ? Buffer.concat([c.buffer, part]) : part;
      if (end < 0) {
        c.buffer = Buffer.from(frame);
        return;
      }
      const line = frame.subarray(0, frame.length - 1);
      c.buffer = Buffer.alloc(0);
      offset = end + 1;
      let r;
      try {
        r = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(line));
        if (!r || typeof r !== "object" || r.version !== 2 || typeof r.id !== "string" || Object.keys(r).some((k) => !["version", "id", "error", "output", "state", "stats", "event"].includes(k)))
          throw 0;
        if (r.event !== undefined) {
          if (r.id !== "" || Object.keys(r).length !== 3)
            throw 0;
          if (r.event === "ready" && c.readyAt === undefined) {
            if (performance.now() - c.started >= (native.startupMs ?? 5000) || [...c.pending.values()].some((cmd) => performance.now() >= cmd.deadline)) {
              fail(c, "STARTUP_TIMEOUT");
              return;
            }
            c.readyAt = performance.now();
            clearTimeout(c.startup);
            delete c.startup;
            c.heartbeat = c.readyAt;
            c.watch = setInterval(() => {
              if (performance.now() - c.heartbeat > limits.heartbeatMs)
                fail(c, "HEARTBEAT_TIMEOUT");
            }, Math.min(500, limits.heartbeatMs / 2));
            for (const cmd of c.queue) {
              if (!c.pending.has(cmd.id))
                continue;
              cmd.phase = "queued";
              cmd.queuedAt = c.readyAt;
              clearTimeout(cmd.timer);
              cmd.timer = setTimeout(() => timeout(c, cmd, performance.now() >= cmd.deadline ? "CALL_TIMEOUT" : "QUEUE_TIMEOUT"), Math.min(limits.queueMs, Math.max(0, cmd.deadline - performance.now())));
            }
            pump(c);
            continue;
          }
          if (r.event !== "heartbeat" || c.readyAt === undefined)
            throw 0;
          c.heartbeat = performance.now();
          continue;
        }
        if (c.readyAt === undefined || !/^[A-Za-z0-9_.:-]{1,96}$/.test(r.id) || r.error !== undefined && (typeof r.error !== "string" || !/^[A-Z_]{1,64}$/.test(r.error)))
          throw 0;
        if (r.output !== undefined)
          base64Schema.parse(r.output);
        if (r.state !== undefined)
          base64Schema.parse(r.state);
        if (r.stats !== undefined && (!r.stats || typeof r.stats !== "object" || Array.isArray(r.stats)))
          throw 0;
      } catch {
        fail(c, "PROTOCOL_INVALID");
        return;
      }
      const cmd = c.pending.get(r.id);
      if (!cmd)
        continue;
      c.heartbeat = performance.now();
      if (cmd.phase === "startup" || cmd.phase === "queued") {
        fail(c, "PROTOCOL_INVALID");
        return;
      }
      if (!cmd.cancelCode && performance.now() >= cmd.deadline)
        timeout(c, cmd, "CALL_TIMEOUT");
      if (!c.pending.has(cmd.id))
        continue;
      if (cmd.cancelCode) {
        cmd.cancelReply = true;
        if (cmd.cancelAck)
          settle(c, cmd, undefined, cmd.cancelCode);
      } else
        settle(c, cmd, r, r.error);
    }
  }
  function write(c) {
    if (c.dead || c.readyAt === undefined || c.inflight)
      return;
    const cmd = c.writes.shift();
    if (!cmd)
      return;
    c.writeBytes -= cmd.frame.length;
    if (!c.pending.has(cmd.id)) {
      write(c);
      return;
    }
    if (performance.now() >= cmd.deadline) {
      timeout(c, cmd, "CALL_TIMEOUT");
      write(c);
      return;
    }
    cmd.phase = "writing";
    const inflight = {
      cmd,
      started: performance.now(),
      timer: setTimeout(() => {
        if (c.inflight === inflight)
          fail(c, "WRITE_TIMEOUT");
      }, native.writeMs ?? 2000)
    };
    c.inflight = inflight;
    c.process.stdin.write(cmd.frame, (error) => {
      if (c.dead || c.inflight !== inflight)
        return;
      clearTimeout(inflight.timer);
      delete c.inflight;
      if (error) {
        fail(c, "HELPER_FAILED");
        return;
      }
      if (c.pending.has(cmd.id))
        cmd.phase = "running";
      write(c);
    });
  }
  function pump(c) {
    if (c.dead || c.readyAt === undefined)
      return;
    for (let i = 0;i < c.queue.length; ) {
      const cmd = c.queue[i];
      if (!c.pending.has(cmd.id)) {
        c.queue.splice(i, 1);
        continue;
      }
      if (performance.now() >= cmd.deadline) {
        timeout(c, cmd, "CALL_TIMEOUT");
        if (c.dead)
          return;
        continue;
      }
      if (cmd.queuedAt !== undefined && performance.now() - cmd.queuedAt >= limits.queueMs) {
        settle(c, cmd, undefined, "QUEUE_TIMEOUT");
        continue;
      }
      if (cmd.execution && c.active >= slots) {
        i++;
        continue;
      }
      c.queue.splice(i, 1);
      if (c.writeBytes + cmd.frame.length > limits.maxWriteBytes) {
        settle(c, cmd, undefined, "WRITE_BUDGET");
        continue;
      }
      clearTimeout(cmd.timer);
      cmd.phase = "running";
      if (cmd.execution)
        c.active++;
      cmd.timer = setTimeout(() => timeout(c, cmd, "CALL_TIMEOUT"), Math.max(0, cmd.deadline - performance.now()));
      c.writes.push(cmd);
      c.writeBytes += cmd.frame.length;
    }
    write(c);
  }
  function timeout(c, cmd, code) {
    if (!c.pending.has(cmd.id) || cmd.cancelCode)
      return;
    if (cmd.phase === "startup") {
      if (code !== "CALL_CANCELLED") {
        fail(c, "STARTUP_TIMEOUT");
        return;
      }
      settle(c, cmd, undefined, code);
      if (!c.pending.size)
        fail(c, code);
      return;
    }
    if (cmd.phase === "writing" || !cmd.execution) {
      fail(c, code);
      return;
    }
    if (cmd.phase === "queued") {
      settle(c, cmd, undefined, code);
      return;
    }
    cmd.cancelCode = code;
    clearTimeout(cmd.timer);
    cmd.timer = setTimeout(() => {
      fail(c, "CANCEL_FAILED");
    }, 200);
    if (cmd.abort && cmd.signal)
      cmd.signal.removeEventListener("abort", cmd.abort);
    send(c, "cancel", { target: cmd.id }, 200, undefined, false).then(() => {
      cmd.cancelAck = true;
      if (cmd.cancelReply)
        settle(c, cmd, undefined, code);
    }, (error) => {
      if (error instanceof PluginHostError && error.code === "COMMAND_MISSING") {
        cmd.cancelAck = true;
        if (cmd.cancelReply)
          settle(c, cmd, undefined, code);
      } else
        fail(c, "CANCEL_FAILED");
    });
  }
  function start() {
    if (closed)
      throw new PluginHostError("HOST_CLOSED");
    if (connection && !connection.dead)
      return connection;
    if (options.expectedExecutableDigest !== undefined) {
      try {
        if (!/^[a-f0-9]{64}$/.test(options.expectedExecutableDigest) || pluginExecutableDigest(options.executable) !== options.expectedExecutableDigest)
          throw new Error("PLUGIN_EXECUTABLE_CHANGED");
      } catch {
        throw new PluginHostError("EXECUTABLE_CHANGED");
      }
    }
    if (starts > limits.maxRestarts)
      throw new PluginHostError("RESTART_BUDGET");
    starts++;
    const child = spawn(options.executable, ["--config", Buffer.from(JSON.stringify(native)).toString("base64")], {
      detached: true,
      stdio: ["pipe", "pipe", "pipe"],
      env: { GOMEMLIMIT: String(native.goMemoryBytes ?? 256 << 20), GOMAXPROCS: "2" }
    });
    let finish;
    const exit = new Promise((resolve) => {
      finish = resolve;
    });
    const c = {
      process: child,
      id: crypto.randomUUID(),
      sequence: 0,
      pending: new Map,
      queue: [],
      writes: [],
      active: 0,
      pendingBytes: 0,
      writeBytes: 0,
      started: performance.now(),
      buffer: Buffer.alloc(0),
      heartbeat: performance.now(),
      dead: false,
      loaded: new Map,
      exit
    };
    child.on("error", () => {
      finish();
      fail(c, "HELPER_FAILED");
    });
    child.on("exit", () => {
      finish();
      fail(c, "HELPER_EXITED");
    });
    child.stdout.on("readable", () => {
      while (!c.dead) {
        const chunk = child.stdout.read(Math.min(child.stdout.readableLength, limits.maxFrameBytes));
        if (!chunk)
          break;
        read(c, chunk);
      }
    });
    child.stdout.on("error", () => {
      fail(c, "HELPER_FAILED");
    });
    child.stdout.on("end", () => {
      fail(c, "HELPER_EOF");
    });
    child.stdin.on("error", () => {
      fail(c, "HELPER_FAILED");
    });
    child.stderr.on("data", () => {
      fail(c, "HELPER_STDERR");
    });
    child.stderr.on("error", () => {
      fail(c, "HELPER_FAILED");
    });
    c.startup = setTimeout(() => {
      fail(c, "STARTUP_TIMEOUT");
    }, native.startupMs ?? 5000);
    connection = c;
    return c;
  }
  function send(c, op, fields, timeoutMs, signal, execution = true) {
    if (c.dead)
      return Promise.reject(new PluginHostError("HELPER_FAILED"));
    if (signal?.aborted)
      return Promise.reject(new PluginHostError("CALL_CANCELLED"));
    const id = `${c.id}:${++c.sequence}`;
    const frame = Buffer.from(JSON.stringify({ version: 2, id, op, ...fields }) + `
`);
    if (frame.length >= limits.maxFrameBytes)
      return Promise.reject(new PluginHostError("FRAME_BUDGET"));
    if (c.pending.size >= limits.maxPending + (execution ? 0 : 4) || c.pendingBytes + frame.length > limits.maxPendingBytes)
      return Promise.reject(new PluginHostError("PENDING_BUDGET"));
    return new Promise((resolve, reject) => {
      const cmd = {
        id,
        op,
        deadline: performance.now() + timeoutMs,
        ...c.readyAt === undefined ? {} : { queuedAt: performance.now() },
        frame,
        bytes: frame.length,
        phase: c.readyAt === undefined ? "startup" : "queued",
        execution,
        timer: setTimeout(() => timeout(c, cmd, performance.now() >= cmd.deadline ? "CALL_TIMEOUT" : "QUEUE_TIMEOUT"), c.readyAt === undefined ? timeoutMs : Math.min(limits.queueMs, timeoutMs)),
        resolve,
        reject
      };
      if (signal) {
        cmd.signal = signal;
        cmd.abort = () => timeout(c, cmd, "CALL_CANCELLED");
        signal.addEventListener("abort", cmd.abort, { once: true });
      }
      c.pending.set(id, cmd);
      c.pendingBytes += cmd.bytes;
      c.queue.push(cmd);
      pump(c);
    });
  }
  return {
    onDisconnect(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    async load(module, signal) {
      const byteLength = module instanceof Uint8Array ? module.byteLength : pluginModuleInfo(module).byteLength;
      if (byteLength > (native.maxModuleBytes ?? 8 << 20))
        throw new PluginHostError("MODULE_BUDGET");
      if (signal?.aborted)
        throw new PluginHostError("CALL_CANCELLED");
      const owned = module instanceof Uint8Array ? ownPluginModule(module) : module;
      const hash = pluginModuleInfo(owned).hash;
      const c = start();
      let load = c.loaded.get(hash);
      if (!load) {
        load = { controller: new AbortController, waiters: new Set, ready: false };
        c.loaded.set(hash, load);
        const current = load;
        send(c, "load", { hash, module: pluginModuleBase64(owned) }, (native.compileMs ?? 5000) + 250, current.controller.signal).then(() => {
          if (c.dead) {
            for (const waiter of current.waiters)
              waiter(new PluginHostError(c.failureCode ?? "HELPER_FAILED", c.failure));
            return;
          }
          current.ready = true;
          for (const waiter of current.waiters)
            waiter();
        }, (error) => {
          if (c.loaded.get(hash) === current)
            c.loaded.delete(hash);
          for (const waiter of current.waiters)
            waiter(error);
        });
        while (c.loaded.size > (native.maxModules ?? 4))
          c.loaded.delete(c.loaded.keys().next().value);
      } else {
        c.loaded.delete(hash);
        c.loaded.set(hash, load);
      }
      const current = load;
      if (!current.ready)
        await new Promise((resolve, reject) => {
          const finish = (error) => {
            if (!current.waiters.delete(finish))
              return;
            signal?.removeEventListener("abort", abort);
            if (error)
              reject(error);
            else
              resolve();
          };
          const abort = () => {
            finish(new PluginHostError("CALL_CANCELLED"));
            if (!current.ready && !current.waiters.size) {
              if (c.loaded.get(hash) === current)
                c.loaded.delete(hash);
              current.controller.abort();
            }
          };
          current.waiters.add(finish);
          signal?.addEventListener("abort", abort, { once: true });
        });
      return { hash, connection: c.id };
    },
    async call(hash, input, state, options = {}) {
      const c = start();
      if (!/^[a-f0-9]{64}$/.test(hash))
        throw new PluginHostError("MODULE_HASH");
      const cached = c.loaded.get(hash);
      if (cached) {
        c.loaded.delete(hash);
        c.loaded.set(hash, cached);
      }
      if (input.length > (native.maxInputBytes ?? 256 << 10) || (state?.length ?? 0) > (native.maxStateBytes ?? 256 << 10))
        throw new PluginHostError("INPUT_BUDGET");
      const timeoutMs = Math.min(options.timeoutMs ?? native.callMs ?? 1000, native.callMs ?? 1000);
      if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1)
        throw new PluginHostError("DEADLINE");
      const r = await send(c, "call", {
        hash,
        function: options.function ?? "invoke",
        input: Buffer.from(input).toString("base64"),
        ...state ? { state: Buffer.from(state).toString("base64") } : {},
        timeoutMs
      }, timeoutMs + 200, options.signal).catch((error) => {
        c.loaded.delete(hash);
        throw error;
      });
      if (r.output === undefined || r.state === undefined) {
        await fail(c, "PROTOCOL_INVALID");
        throw new PluginHostError("PROTOCOL_INVALID");
      }
      const output = new Uint8Array(Buffer.from(r.output, "base64")), next = new Uint8Array(Buffer.from(r.state, "base64"));
      if (output.length > (native.maxOutputBytes ?? 256 << 10) || next.length > (native.maxStateBytes ?? 256 << 10)) {
        await fail(c, "OUTPUT_BUDGET");
        throw new PluginHostError("OUTPUT_BUDGET");
      }
      return { output, state: next };
    },
    async stats() {
      return (await send(start(), "stats", {}, 1000, undefined, false)).stats;
    },
    snapshot() {
      const c = connection;
      return {
        starts,
        observers: listeners.size,
        pid: c?.process.pid,
        connection: c?.id,
        pending: c?.pending.size ?? 0,
        pendingBytes: c?.pendingBytes ?? 0,
        writeBytes: c?.writeBytes ?? 0,
        dead: c?.dead ?? true,
        closed,
        loaded: c ? [...c.loaded.values()].filter((load) => load.ready).length : 0,
        loading: c ? [...c.loaded.values()].filter((load) => !load.ready).length : 0,
        waiters: c ? [...c.loaded.values()].reduce((n, load) => n + load.waiters.size, 0) : 0,
        queued: c?.queue.filter((cmd) => c.pending.has(cmd.id)).length ?? 0,
        active: c?.active ?? 0,
        inflight: c?.inflight ? 1 : 0,
        timers: c ? c.pending.size + Number(!!c.startup) + Number(!!c.watch) + Number(!!c.inflight) : 0,
        ready: c?.readyAt !== undefined && !c.dead,
        diagnostics: c ? c.failure ?? diagnostic(c, c.inflight?.cmd ?? c.pending.values().next().value) : undefined
      };
    },
    async close(drain = false) {
      if (closed) {
        await Promise.all(retirements);
        listeners.clear();
        return;
      }
      closed = true;
      const c = connection;
      if (c && !c.dead) {
        if (drain && c.readyAt !== undefined) {
          const deadline = performance.now() + limits.closeMs;
          while (c.pending.size && !c.dead && performance.now() < deadline)
            await new Promise((resolve) => setTimeout(resolve, 5));
          if (c.pending.size) {
            await fail(c, "DRAIN_TIMEOUT");
            await Promise.all(retirements);
            listeners.clear();
            return;
          }
        }
        if (c.readyAt !== undefined)
          try {
            await send(c, drain ? "drain" : "close", {}, limits.closeMs, undefined, false);
          } catch {}
        await fail(c, "HOST_CLOSED");
      }
      await Promise.all(retirements);
      listeners.clear();
    }
  };
}
// packages/plugin-host/src/json-documents.ts
function createJSONDocuments(maxBytes = 256 << 20) {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1024 || maxBytes > 1024 ** 3)
    throw new PluginHostError("CONFIG_INVALID");
  const documents = new Map, outputs = new Map;
  const external = new Map;
  let retained = 0, peakBytes = 0;
  function reserve(bytes) {
    if (retained + bytes > maxBytes)
      throw new PluginHostError("JSON_MEMORY_BUDGET");
    retained += bytes;
    peakBytes = Math.max(peakBytes, retained);
  }
  function pointer(value) {
    if (value.length > 2048 || value !== "" && !value.startsWith("/") || /~(?![01])/.test(value))
      throw new PluginHostError("JSON_POINTER");
    return value === "" ? [] : value.slice(1).split("/").map((part) => part.replace(/~1/g, "/").replace(/~0/g, "~"));
  }
  function lookup(root, parts) {
    let node = root;
    for (const key of parts) {
      if (!node)
        return;
      if (node.kind === "object")
        node = node.children.get(key);
      else if (node.kind === "array") {
        if (!/^(?:0|[1-9]\d*)$/.test(key) || key.length > 10)
          throw new PluginHostError("JSON_POINTER");
        node = node.items[Number(key)];
      } else
        return;
    }
    return node;
  }
  function index(bytes, charge) {
    let i = 0, nodes = 0;
    new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    function space() {
      while (i < bytes.length && [32, 9, 10, 13].includes(bytes[i]))
        i++;
    }
    function string() {
      if (bytes[i++] !== 34)
        throw new PluginHostError("JSON_INVALID");
      while (i < bytes.length) {
        const ch = bytes[i++];
        if (ch === 34)
          return;
        if (ch < 32)
          throw new PluginHostError("JSON_INVALID");
        if (ch === 92) {
          const escape = bytes[i++];
          if (escape === 117) {
            for (let n = 0;n < 4; n++) {
              const hex = bytes[i++];
              if (hex === undefined || !/[0-9a-fA-F]/.test(String.fromCharCode(hex)))
                throw new PluginHostError("JSON_INVALID");
            }
          } else if (escape === undefined || ![34, 92, 47, 98, 102, 110, 114, 116].includes(escape))
            throw new PluginHostError("JSON_INVALID");
        }
      }
      throw new PluginHostError("JSON_INVALID");
    }
    function value(depth) {
      if (depth > 64 || ++nodes > 1e5)
        throw new PluginHostError("JSON_LIMIT");
      charge(1024);
      space();
      const start = i, ch = bytes[i];
      if (ch === 123 || ch === 91) {
        const array = ch === 91, end = array ? 93 : 125;
        const node = {
          kind: array ? "array" : "object",
          start,
          end: 0,
          ...array ? { items: [] } : { children: new Map }
        };
        i++;
        space();
        if (bytes[i] === end) {
          node.end = ++i;
          return node;
        }
        for (;; ) {
          space();
          if (array)
            node.items.push(value(depth + 1));
          else {
            const keyStart = i;
            string();
            charge((i - keyStart) * 2);
            const key = JSON.parse(bytes.subarray(keyStart, i).toString("utf8"));
            if (node.children.has(key))
              throw new PluginHostError("JSON_DUPLICATE_KEY");
            space();
            if (bytes[i++] !== 58)
              throw new PluginHostError("JSON_INVALID");
            const child = value(depth + 1);
            child.memberStart = keyStart;
            node.children.set(key, child);
          }
          space();
          const next = bytes[i++];
          if (next === end) {
            node.end = i;
            return node;
          }
          if (next !== 44)
            throw new PluginHostError("JSON_INVALID");
        }
      }
      if (ch === 34) {
        string();
        return { kind: "string", start, end: i };
      }
      for (const [keyword, kind] of [
        ["true", "boolean"],
        ["false", "boolean"],
        ["null", "null"]
      ]) {
        if (bytes.subarray(i, i + keyword.length).toString("utf8") === keyword) {
          i += keyword.length;
          return { kind, start, end: i };
        }
      }
      let end = i;
      while (end < bytes.length && ![32, 9, 10, 13, 44, 93, 125].includes(bytes[end]))
        end++;
      if (end - i > 200)
        throw new PluginHostError("JSON_NUMERIC_LIMIT");
      const literal = bytes.subarray(i, end).toString("utf8");
      if (!/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(literal))
        throw new PluginHostError("JSON_INVALID");
      i = end;
      return { kind: "number", start, end };
    }
    const root = value(0);
    space();
    if (i !== bytes.length)
      throw new PluginHostError("JSON_INVALID");
    return root;
  }
  function get(owner, handle) {
    const document = documents.get(handle);
    if (!document || document.owner !== owner || document.consumed)
      throw new PluginHostError("JSON_HANDLE");
    return document;
  }
  function drop(handle, doc) {
    if (documents.delete(handle))
      retained -= doc.charge;
  }
  function publish(owner, handle, doc, bytes) {
    index(Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength), () => {});
    const digest = sha256(bytes), output = crypto.randomUUID();
    doc.consumed = true;
    drop(handle, doc);
    reserve(bytes.length);
    outputs.set(output, { owner, bytes });
    return {
      bytes,
      digest,
      release() {
        if (outputs.delete(output))
          retained -= bytes.length;
      }
    };
  }
  function compose(doc, plan) {
    const template = Buffer.from(plan.template);
    if (template.length > 256 << 10 || plan.slots.length > 4096)
      throw new PluginHostError("JSON_PLAN_BUDGET");
    const charge = (amount) => {
      reserve(amount);
      doc.charge += amount;
    };
    charge(template.length * 7);
    const root = index(template, charge);
    const patches = [];
    let added = 0;
    for (const slot of plan.slots) {
      if (!["value", "parse", "stringify", "concat"].includes(slot.mode))
        throw new PluginHostError("JSON_PLAN");
      const target = lookup(root, pointer(slot.at));
      if (!slot.at || target?.kind !== "null")
        throw new PluginHostError("JSON_PLAN");
      if (slot.mode === "concat") {
        if (!slot.sources.length || slot.sources.length > 256)
          throw new PluginHostError("JSON_PLAN");
        let text = "";
        for (const from of slot.sources) {
          const part = lookup(doc.root, pointer(from));
          if (part?.kind !== "string")
            throw new PluginHostError("JSON_PLAN");
          charge((part.end - part.start) * 6);
          text += JSON.parse(doc.bytes.subarray(part.start, part.end).toString("utf8"));
        }
        const bytes = Buffer.from(JSON.stringify(text));
        added += bytes.length;
        if (added > (16 << 20) + (64 << 10))
          throw new PluginHostError("JSON_OUTPUT_BUDGET");
        patches.push({ start: target.start, end: target.end, bytes });
        continue;
      }
      const source = lookup(doc.root, pointer(slot.from));
      if (!source)
        throw new PluginHostError("JSON_PLAN");
      let bytes = doc.bytes.subarray(source.start, source.end);
      if (slot.mode === "parse") {
        if (source.kind !== "string")
          throw new PluginHostError("JSON_PLAN");
        const decoded = Buffer.from(JSON.parse(bytes.toString("utf8")));
        charge(decoded.length * 7);
        try {
          index(decoded, charge);
        } catch (error) {
          if (error instanceof PluginHostError && error.code.startsWith("JSON_"))
            throw new PluginHostError("JSON_COMPOSE_SOURCE");
          throw error;
        }
        bytes = decoded;
      } else if (slot.mode === "stringify")
        bytes = Buffer.from(JSON.stringify(bytes.toString("utf8")));
      added += bytes.length;
      if (added > (16 << 20) + (64 << 10))
        throw new PluginHostError("JSON_OUTPUT_BUDGET");
      patches.push({ start: target.start, end: target.end, bytes });
    }
    patches.sort((a, b) => a.start - b.start);
    for (let i = 1;i < patches.length; i++)
      if (patches[i].start === patches[i - 1].start)
        throw new PluginHostError("JSON_PLAN_OVERLAP");
    const size = patches.reduce((n, p) => n + p.bytes.length - (p.end - p.start), template.length);
    if (size > doc.bytes.length + template.length + (64 << 10) || size > (16 << 20) + (320 << 10))
      throw new PluginHostError("JSON_OUTPUT_BUDGET");
    const parts = [];
    let cursor = 0;
    for (const patch of patches) {
      parts.push(template.subarray(cursor, patch.start), patch.bytes);
      cursor = patch.end;
    }
    parts.push(template.subarray(cursor));
    return new Uint8Array(Buffer.concat(parts, size));
  }
  return {
    register(owner, source, selectedHandle) {
      if (source.length > 16 << 20)
        throw new PluginHostError("JSON_BODY_BUDGET");
      let charge = source.length * 7 + (128 << 10);
      reserve(charge);
      try {
        const bytes = Buffer.from(source), root = index(bytes, (amount) => {
          reserve(amount);
          charge += amount;
        });
        const handle = selectedHandle ?? crypto.randomUUID();
        if (documents.has(handle))
          throw new PluginHostError("JSON_HANDLE");
        documents.set(handle, { owner, bytes, root, charge, consumed: false });
        return { handle, bytes: bytes.length };
      } catch (error) {
        retained -= charge;
        throw error;
      }
    },
    inspect(owner, handle, paths) {
      const doc = get(owner, handle);
      if (paths.length > 16 || new Set(paths).size !== paths.length)
        throw new PluginHostError("JSON_INSPECTION_BUDGET");
      const facts = Object.create(null);
      const concrete = [];
      for (const path of paths) {
        const parts = pointer(path);
        if (!parts.includes("*")) {
          concrete.push(path);
          continue;
        }
        let prefixes = [[]];
        for (const part of parts) {
          if (part !== "*") {
            prefixes = prefixes.map((prefix) => [...prefix, part]);
            continue;
          }
          const next = [];
          for (const prefix of prefixes) {
            const node = lookup(doc.root, prefix);
            const keys = node?.kind === "array" ? node.items.map((_, n) => String(n)) : node?.kind === "object" ? [...node.children.keys()] : [];
            for (const key of keys) {
              next.push([...prefix, key]);
              if (next.length > 4096)
                throw new PluginHostError("JSON_INSPECTION_BUDGET");
            }
          }
          prefixes = next;
        }
        for (const prefix of prefixes)
          concrete.push("/" + prefix.map((part) => part.replace(/~/g, "~0").replace(/\//g, "~1")).join("/"));
      }
      if (concrete.length > 4096)
        throw new PluginHostError("JSON_INSPECTION_BUDGET");
      for (const path of concrete) {
        if (Object.hasOwn(facts, path))
          continue;
        const node = lookup(doc.root, pointer(path));
        if (!node) {
          facts[path] = { kind: "missing", bytes: 0 };
          continue;
        }
        const bytes = node.end - node.start;
        let stringInfo;
        if (node.kind === "string") {
          const guard = bytes * 6 + 512;
          reserve(guard);
          try {
            const text = JSON.parse(doc.bytes.subarray(node.start, node.end).toString("utf8"));
            stringInfo = { utf16_units: text.length, digest: sha256(Buffer.from(text, "utf16le")) };
          } finally {
            retained -= guard;
          }
        }
        facts[path] = {
          kind: node.kind,
          bytes,
          ...stringInfo ? { string_info: stringInfo } : {},
          ...node.kind === "object" ? { count: node.children.size } : node.kind === "array" ? { count: node.items.length } : {},
          ...node.kind === "string" ? { empty: bytes === 2 } : {},
          ...!["object", "array"].includes(node.kind) && bytes <= 4096 ? { literal: doc.bytes.subarray(node.start, node.end).toString("utf8") } : {}
        };
      }
      if (Buffer.byteLength(JSON.stringify(facts)) > 256 << 10)
        throw new PluginHostError("JSON_INSPECTION_BUDGET");
      return facts;
    },
    materialize(owner, plan) {
      const doc = get(owner, plan.document);
      if ("compose" in plan)
        return publish(owner, plan.document, doc, compose(doc, plan.compose));
      if (plan.edits.length > 32)
        throw new PluginHostError("JSON_PLAN_BUDGET");
      let replacementBytes = 0;
      const edits = plan.edits.map((edit) => {
        const parts = pointer(edit.pointer);
        if (!parts.length || edit.op !== "set" && edit.op !== "remove" || edit.op === "remove" && edit.value !== undefined || edit.op === "set" && edit.value === undefined)
          throw new PluginHostError("JSON_PLAN");
        const parent = lookup(doc.root, parts.slice(0, -1)), key = parts.at(-1);
        if (!parent || !["object", "array"].includes(parent.kind))
          throw new PluginHostError("JSON_PLAN");
        if (edit.op === "set") {
          const bytes = Buffer.from(edit.value);
          replacementBytes += bytes.length;
          if (bytes.length > 4096 || replacementBytes > 64 << 10)
            throw new PluginHostError("JSON_PLAN_BUDGET");
          index(bytes, (amount) => {
            reserve(amount);
            doc.charge += amount;
          });
        }
        const existing = lookup(doc.root, parts);
        if (parent.kind === "array" && !existing || edit.op === "remove" && !existing)
          throw new PluginHostError("JSON_PLAN");
        return { ...edit, parts, parent, key, existing };
      });
      for (let i = 0;i < edits.length; i++)
        for (let j = i + 1;j < edits.length; j++) {
          const a = edits[i].parts, b = edits[j].parts;
          if (a.slice(0, Math.min(a.length, b.length)).every((part, n) => part === b[n]))
            throw new PluginHostError("JSON_PLAN_OVERLAP");
        }
      const patches = [];
      const insertions = new Map;
      for (const edit of edits) {
        if (!edit.existing) {
          const items = insertions.get(edit.parent) ?? [];
          items.push(edit);
          insertions.set(edit.parent, items);
          continue;
        }
        if (edit.op === "set") {
          patches.push({
            start: edit.existing.start,
            end: edit.existing.end,
            bytes: Buffer.from(edit.value)
          });
          continue;
        }
        const siblings = edit.parent.kind === "array" ? edit.parent.items : [...edit.parent.children.values()];
        const position = siblings.indexOf(edit.existing);
        if (siblings.length === 1)
          patches.push({
            start: edit.parent.start + 1,
            end: edit.parent.end - 1,
            bytes: Buffer.alloc(0)
          });
        else if (position === 0)
          patches.push({
            start: edit.parent.start + 1,
            end: siblings[1].memberStart ?? siblings[1].start,
            bytes: Buffer.alloc(0)
          });
        else {
          const previous = siblings[position - 1];
          let start = previous.end;
          while (doc.bytes[start] !== 44 && start < edit.existing.start)
            start++;
          patches.push({ start, end: edit.existing.end, bytes: Buffer.alloc(0) });
        }
      }
      for (const [parent, items] of insertions) {
        if (parent.kind !== "object")
          throw new PluginHostError("JSON_PLAN");
        const bytes = Buffer.from((parent.children.size ? "," : "") + items.map((item) => `${JSON.stringify(item.key)}:${item.value}`).join(","));
        patches.push({ start: parent.end - 1, end: parent.end - 1, bytes });
      }
      patches.sort((a, b) => a.start - b.start || a.end - b.end);
      for (let i = 1;i < patches.length; i++)
        if (patches[i].start < patches[i - 1].end || patches[i].start === patches[i - 1].start)
          throw new PluginHostError("JSON_PLAN_OVERLAP");
      const size = patches.reduce((n, p) => n + p.bytes.length - (p.end - p.start), doc.bytes.length);
      if (size > (16 << 20) + (64 << 10) || size > doc.bytes.length + (64 << 10))
        throw new PluginHostError("JSON_OUTPUT_BUDGET");
      const parts = [];
      let cursor = 0;
      for (const patch of patches) {
        parts.push(doc.bytes.subarray(cursor, patch.start), patch.bytes);
        cursor = patch.end;
      }
      parts.push(doc.bytes.subarray(cursor));
      return publish(owner, plan.document, doc, new Uint8Array(Buffer.concat(parts, size)));
    },
    discard(owner, handle) {
      const doc = documents.get(handle);
      if (doc && doc.owner === owner)
        drop(handle, doc);
    },
    stringValue(owner, handle, path) {
      const doc = get(owner, handle), node = lookup(doc.root, pointer(path));
      if (!node || node.kind !== "string")
        throw new PluginHostError("STRING_POINTER");
      try {
        return JSON.parse(doc.bytes.subarray(node.start, node.end).toString("utf8"));
      } catch {
        throw new PluginHostError("STRING_POINTER");
      }
    },
    adjust(owner, delta) {
      const value = external.get(owner) ?? 0;
      if (!Number.isSafeInteger(delta) || value + delta < 0)
        throw new PluginHostError("JSON_MEMORY_ACCOUNTING");
      if (delta > 0)
        reserve(delta);
      else
        retained += delta;
      if (value + delta)
        external.set(owner, value + delta);
      else
        external.delete(owner);
    },
    dispose(owner) {
      for (const [handle, doc] of documents)
        if (doc.owner === owner)
          drop(handle, doc);
      for (const [id, output] of outputs)
        if (output.owner === owner) {
          retained -= output.bytes.length;
          outputs.delete(id);
        }
      retained -= external.get(owner) ?? 0;
      external.delete(owner);
    },
    snapshot: () => ({
      documents: documents.size,
      outputs: outputs.size,
      bytes: retained,
      peakBytes,
      maxBytes
    })
  };
}
function rewriteJSON(body, edits) {
  const documents = createJSONDocuments(), owner = crypto.randomUUID();
  try {
    const document = documents.register(owner, body);
    const output = documents.materialize(owner, { document: document.handle, edits });
    output.release();
    return output.bytes;
  } finally {
    documents.dispose(owner);
  }
}

// packages/plugin-host/src/sse-frames.ts
function createSSEFrames(charge, limits = {}) {
  const maxEvent = limits.maxEventBytes ?? 1048576, maxFrames = limits.maxReadyFrames ?? 256, maxReady = limits.maxReadyBytes ?? 8 << 20;
  if (![maxEvent, maxFrames, maxReady].every((n) => Number.isSafeInteger(n) && n > 0) || maxEvent < 1024 || maxEvent > 16 << 20 || maxFrames > 1024 || maxReady > 64 << 20)
    throw new PluginHostError("CONFIG_INVALID");
  const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }), queue = [];
  let blocks = [], used = 0, lineStart = 0, lineBytes = 0, eventBytes = 0, pendingCR = false, lines = [], reserved = 0, ordinal = 0, queuedBytes = 0, firstLine = true, seen = 0, bom = [];
  function adjust(n) {
    charge(n);
    reserved += n;
  }
  function range(start, end) {
    const out = Buffer.allocUnsafe(end - start);
    let offset = 0;
    while (start < end) {
      const index = Math.floor(start / 16384), within = start % 16384, n = Math.min(end - start, 16384 - within);
      blocks[index].copy(out, offset, within, within + n);
      offset += n;
      start += n;
    }
    return out;
  }
  function raw(value) {
    if (used + value.length > 2 * maxEvent)
      throw new PluginHostError("SSE_WIRE_BUDGET");
    let offset = 0;
    while (offset < value.length) {
      const block = Math.floor(used / 16384), within = used % 16384;
      if (!blocks[block]) {
        adjust(16384 * 12);
        blocks.push(Buffer.allocUnsafe(16384));
      }
      const n = Math.min(value.length - offset, 16384 - within);
      blocks[block].set(value.subarray(offset, offset + n), within);
      used += n;
      offset += n;
    }
  }
  function reset() {
    blocks = [];
    used = 0;
    lineStart = 0;
    lineBytes = 0;
    eventBytes = 0;
    pendingCR = false;
    lines = [];
    reserved = 0;
  }
  function finishLine(end) {
    let line = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(range(lineStart, end));
    if (firstLine) {
      line = line.replace(/^\uFEFF/, "");
      firstLine = false;
    }
    eventBytes += Buffer.byteLength(line) + 1;
    if (eventBytes > maxEvent)
      throw new PluginHostError("SSE_EVENT_BUDGET");
    lineBytes = 0;
    lineStart = used;
    if (line) {
      adjust(256);
      lines.push(line);
      return;
    }
    if (!lines.length) {
      charge(-reserved);
      reset();
      return;
    }
    let event = "message", id = "";
    const data = [];
    for (const current of lines) {
      const colon = current.indexOf(":"), name = colon < 0 ? current : current.slice(0, colon), rawValue = colon < 0 ? "" : current.slice(colon + 1), value = rawValue.startsWith(" ") ? rawValue.slice(1) : rawValue;
      if (name === "data")
        data.push(value);
      if (name === "event")
        event = value;
      if (name === "id" && !value.includes("\x00"))
        id = value;
    }
    const wire = new TextEncoder().encode(lines.join(`
`) + `

`), body = new TextEncoder().encode(data.join(`
`));
    if (queuedBytes + used > maxReady)
      throw new PluginHostError("SSE_QUEUE_BUDGET");
    queue.push({
      handle: crypto.randomUUID(),
      dataHandle: crypto.randomUUID(),
      ordinal: ++ordinal,
      lines,
      event,
      id,
      data: body,
      wire,
      rawBytes: used,
      charge: reserved
    });
    queuedBytes += used;
    reset();
  }
  function lineGrowth(n) {
    const omitted = firstLine && bom.length === 3 && bom[0] === 239 && bom[1] === 187 && bom[2] === 191 ? 3 : 0;
    if (eventBytes + lineBytes + n - omitted > maxEvent)
      throw new PluginHostError("SSE_EVENT_BUDGET");
    lineBytes += n;
  }
  return {
    feed(input) {
      let offset = 0;
      while (offset < input.length && queue.length < maxFrames) {
        if (pendingCR) {
          if (input[offset] === 10) {
            raw(input.subarray(offset, offset + 1));
            offset++;
            finishLine(used - 2);
          } else
            finishLine(used - 1);
          pendingCR = false;
          if (queue.length >= maxFrames)
            break;
          if (offset >= input.length)
            break;
        }
        let end = offset;
        while (end < input.length && input[end] !== 10 && input[end] !== 13)
          end++;
        if (seen < 3) {
          const n = Math.min(end - offset, 3 - seen);
          for (let i = 0;i < n; i++)
            bom.push(input[offset + i]);
          seen += n;
        }
        if (end > offset) {
          lineGrowth(end - offset);
          raw(input.subarray(offset, end));
          offset = end;
        }
        if (offset === input.length)
          break;
        const ch = input[offset];
        if (eventBytes + lineBytes + 1 > maxEvent + (firstLine && bom.join(",") === "239,187,191" ? 3 : 0))
          throw new PluginHostError("SSE_EVENT_BUDGET");
        raw(input.subarray(offset, offset + 1));
        offset++;
        if (ch === 13)
          pendingCR = true;
        else
          finishLine(used - 1);
      }
      decoder.decode(input.subarray(0, offset), { stream: true });
      return offset;
    },
    finish() {
      decoder.decode();
      if (pendingCR) {
        finishLine(used - 1);
        pendingCR = false;
      }
      if (used || lines.length)
        throw new PluginHostError("SSE_TRUNCATED");
    },
    peek: () => queue[0],
    consume(frame) {
      if (queue[0] !== frame)
        throw new PluginHostError("SSE_FRAME");
      queue.shift();
      queuedBytes -= frame.rawBytes;
      charge(-frame.charge);
    },
    snapshot: () => ({
      ready: queue.length,
      readyBytes: queuedBytes,
      partialBytes: used,
      incomplete: used > 0 || lines.length > 0
    }),
    dispose() {
      charge(-reserved);
      for (const frame of queue)
        charge(-frame.charge);
      queue.length = 0;
      queuedBytes = 0;
      reset();
    }
  };
}

// packages/plugin-host/src/sse-stream.ts
function createSSEStream(options) {
  const { owner, documents } = options, adjust = (n) => documents.adjust(owner, n), framer = createSSEFrames(adjust, options.maxEventBytes === undefined ? {} : { maxEventBytes: options.maxEventBytes });
  const buffers = new Map, appendTokens = new Set, leases = new Map;
  let finalized = false;
  let current, indexed = false, inspection = {}, operation, latest, declaredResource, held = [], heldCharge = 0, heldBytes = 0, bufferMetered = 0, appendOps = 0, lastAppend = 0, tokenCharge = 0, ended = false, opened = false, running = false, closed = false, batchCharge = 0;
  let backlog = new Uint8Array(0);
  const metadata = (value) => ({
    bytes: Buffer.byteLength(value),
    ...Buffer.byteLength(value) <= 4096 ? { value } : {}
  });
  function output(usage = latest?.usage, finality = latest?.finality ?? "UNKNOWN") {
    return {
      abi_version: 1,
      kind: "output",
      consumed: 0,
      chunks: [],
      ...usage ? { usage } : {},
      finality,
      needs_input: true
    };
  }
  function clearFrame() {
    appendTokens.clear();
    if (tokenCharge) {
      adjust(-tokenCharge);
      tokenCharge = 0;
    }
    if (current) {
      documents.discard(owner, current.dataHandle);
      framer.consume(current);
    }
    current = undefined;
    indexed = false;
    inspection = {};
    operation = undefined;
  }
  function ensureIndex(frame) {
    if (!indexed) {
      documents.register(owner, frame.data, frame.dataHandle);
      indexed = true;
    }
  }
  function append(frame, result) {
    if (result.document !== frame.dataHandle || options.sequence() <= lastAppend)
      throw new PluginHostError("SSE_FRAME");
    ensureIndex(frame);
    if (++appendOps > 65536)
      throw new PluginHostError("STRING_OPERATION_BUDGET");
    let buffer = result.target ? buffers.get(result.target) : undefined;
    if (result.target && (!buffer || buffer.sealed))
      throw new PluginHostError("STRING_HANDLE");
    const handle = result.target ?? crypto.randomUUID();
    if (!buffer) {
      if (buffers.size >= 128)
        throw new PluginHostError("STRING_COUNT_BUDGET");
      adjust(512);
      buffer = { parts: [], metered: 0, charge: 512, sealed: false };
      buffers.set(handle, buffer);
    }
    for (const path of result.pointers) {
      const token = `${frame.handle}:${path}`;
      if (appendTokens.has(token))
        throw new PluginHostError("STRING_REPLAY");
      const fact = documents.inspect(owner, frame.dataHandle, [path])[path];
      if (fact.kind !== "string")
        throw new PluginHostError("STRING_POINTER");
      const guard = fact.bytes * 6 + 512;
      adjust(guard);
      let value;
      try {
        value = documents.stringValue(owner, frame.dataHandle, path);
      } catch (error) {
        adjust(-guard);
        throw error;
      }
      const size = Buffer.byteLength(value);
      if (bufferMetered + size > 1048576) {
        adjust(-guard);
        throw new PluginHostError("STRING_BYTE_BUDGET");
      }
      const charge = value.length * 4 + size * 2 + 256;
      adjust(charge - guard);
      buffer.charge += charge;
      buffer.parts.push(value);
      buffer.metered += size;
      bufferMetered += size;
      const tokenBytes = token.length * 2 + 256;
      adjust(tokenBytes);
      tokenCharge += tokenBytes;
      appendTokens.add(token);
    }
    lastAppend = options.sequence();
    return { appended: { handle, bytes: buffer.metered } };
  }
  function check(result) {
    const checked = [];
    for (const handle of result.handles) {
      const buffer = buffers.get(handle);
      if (!buffer)
        throw new PluginHostError("STRING_HANDLE");
      const units = buffer.parts.reduce((n, s) => n + s.length, 0), guard = units * 6 + 512;
      adjust(guard);
      let document;
      try {
        const text = buffer.parts.join(""), raw = new TextEncoder().encode(text);
        document = documents.register(owner, raw);
        const fact = documents.inspect(owner, document.handle, [""])[""];
        checked.push({
          handle,
          valid: true,
          kind: fact.kind,
          metered_bytes: buffer.metered,
          utf8_bytes: raw.length,
          utf16_units: units
        });
      } catch (error) {
        if (error instanceof PluginHostError && ["JSON_INVALID", "JSON_DUPLICATE_KEY", "JSON_LIMIT", "JSON_NUMERIC_LIMIT"].includes(error.code))
          checked.push({ handle, valid: false, metered_bytes: buffer.metered, utf16_units: units });
        else
          throw error;
      } finally {
        if (document)
          documents.discard(owner, document.handle);
        adjust(-guard);
      }
      if (result.seal)
        buffer.sealed = true;
    }
    return { checked };
  }
  function render(frame, body, dataOnly = false) {
    const data = new TextDecoder("utf-8", { fatal: true }).decode(body).split(`
`).map((line) => `data: ${line}`), lines = [];
    let inserted = false;
    for (const line of frame.lines) {
      const colon = line.indexOf(":"), name = colon < 0 ? line : line.slice(0, colon);
      if (name === "data") {
        if (!inserted) {
          lines.push(...data);
          inserted = true;
        }
      } else if (!dataOnly)
        lines.push(line);
    }
    if (!inserted)
      throw new PluginHostError("SSE_FRAME");
    return new TextEncoder().encode(lines.join(`
`) + `

`);
  }
  function hold(bytes) {
    if (heldBytes + bytes.length > 8 << 20 || held.length >= 256)
      throw new PluginHostError("SSE_HELD_BUDGET");
    const charge = bytes.length * 8 + 256;
    adjust(charge);
    heldCharge += charge;
    heldBytes += bytes.length;
    held.push(bytes);
  }
  function encoded(bytes) {
    const charge = bytes.length * 4 + 256;
    adjust(charge);
    batchCharge += charge;
    return Buffer.from(bytes).toString("base64");
  }
  function release(id) {
    const value = leases.get(id);
    if (!value)
      return false;
    leases.delete(id);
    adjust(-value.charge);
    return true;
  }
  async function invoke(hook, payload, signal, observeUsage) {
    if (closed || options.disposed())
      throw new PluginHostError("ATTEMPT_CLOSED");
    if (running)
      throw new PluginHostError("BATCH_CONCURRENT");
    running = true;
    if (hook !== "stream_open" && hook !== "stream_dispose" && !opened) {
      running = false;
      throw new PluginHostError("STREAM_NOT_OPEN");
    }
    if (hook === "stream_open" && opened) {
      running = false;
      throw new PluginHostError("STREAM_ALREADY_OPEN");
    }
    let pendingHeld, publicationFailed = false;
    async function recordHeld() {
      const result = pendingHeld;
      pendingHeld = undefined;
      if (!result || !observeUsage)
        return;
      try {
        await observeUsage(result);
      } catch (error) {
        publicationFailed = true;
        throw error;
      }
    }
    async function recordBeforeContinuing() {
      await recordHeld();
      if (signal?.aborted)
        throw new PluginHostError("CALL_CANCELLED");
      if (options.disposed())
        throw new PluginHostError("ATTEMPT_CLOSED");
    }
    let declared, chunks = [], candidate, consumed = 0;
    try {
      if (signal?.aborted)
        throw new PluginHostError("CALL_CANCELLED");
      if (payload.length > options.maxInputBytes)
        throw new PluginHostError("INPUT_BUDGET");
      if (finalized && hook !== "stream_dispose")
        throw new PluginHostError("STREAM_FINISHED");
      if (hook === "stream_open") {
        if (opened)
          throw new PluginHostError("STREAM_ALREADY_OPEN");
        const result = await options.call(hook, payload, signal);
        if (result.kind === "output") {
          latest = result;
          opened = true;
        }
        return result;
      }
      if (hook === "stream_dispose") {
        const result = await options.call(hook, payload, signal);
        options.dispose();
        return result;
      }
      if (!opened)
        throw new PluginHostError("STREAM_NOT_OPEN");
      if (hook === "stream_feed") {
        if (latest?.terminal)
          throw new PluginHostError("SSE_AFTER_TERMINAL");
        if (ended)
          throw new PluginHostError("STREAM_FINISHED");
        if (options.decoder) {
          if (backlog.length)
            consumed = 0;
          else {
            const decoded = options.decoder.feed(payload);
            backlog = decoded.subarray(framer.feed(decoded));
            consumed = payload.length;
          }
        } else
          consumed = framer.feed(payload);
      } else if (payload.length)
        throw new PluginHostError("INPUT_BUDGET");
      if (hook === "stream_finish" && !ended) {
        if (backlog.length)
          throw new PluginHostError("SSE_TRUNCATED");
        options.decoder?.finish();
        framer.finish();
        ended = true;
      }
      const entry = latest;
      let steps = 0, queries = 0, frames = 0;
      while (steps++ < 32 && frames < 128) {
        if (!current && backlog.length)
          backlog = backlog.subarray(framer.feed(backlog));
        current ??= framer.peek();
        if (!current)
          break;
        const frame = current;
        const message = {
          frame: {
            handle: frame.handle,
            ordinal: frame.ordinal,
            event: metadata(frame.event),
            id: metadata(frame.id),
            data: {
              handle: frame.dataHandle,
              bytes: frame.data.length,
              ...frame.data.length <= 4096 ? { preview: new TextDecoder().decode(frame.data) } : {}
            }
          },
          document: { handle: frame.dataHandle, bytes: frame.data.length },
          inspection,
          operation
        };
        const result = await options.call(hook === "stream_feed" ? "stream_feed" : "stream_drain", new TextEncoder().encode(JSON.stringify(message)), signal, { handle: frame.dataHandle, bytes: frame.data.length }, true);
        operation = undefined;
        if (result.kind === "failure") {
          if (pendingHeld)
            await recordHeld();
          const enriched = {
            abi_version: result.abi_version,
            kind: result.kind,
            status: result.status,
            code: result.code,
            ...latest?.usage ? { usage: latest.usage, finality: latest.finality } : {}
          };
          options.dispose();
          return enriched;
        }
        if (result.kind === "inspect") {
          if (++queries > 4)
            throw new PluginHostError("JSON_INSPECTION_BUDGET");
          if (result.document !== frame.dataHandle || result.pointers.some((p) => Object.hasOwn(inspection, p)))
            throw new PluginHostError("JSON_HANDLE");
          ensureIndex(frame);
          Object.assign(inspection, documents.inspect(owner, frame.dataHandle, result.pointers));
          continue;
        }
        if (result.kind === "buffer_append") {
          operation = append(frame, result);
          continue;
        }
        if (result.kind === "buffer_check") {
          operation = check(result);
          continue;
        }
        if (result.kind !== "output" || result.chunks.length || result.body || result.consumed !== 0)
          throw new PluginHostError("ABI_OUTPUT");
        if (!result.frame) {
          if (result.needs_input || result.terminal)
            throw new PluginHostError("SSE_FRAME");
          latest = result;
          if (queries >= 3) {
            inspection = {};
            break;
          }
          continue;
        }
        if (result.frame.handle !== frame.handle || result.frame.body && result.frame.body.document !== frame.dataHandle)
          throw new PluginHostError("SSE_FRAME");
        if (result.terminal && result.frame.disposition !== "hold")
          throw new PluginHostError("ABI_OUTPUT");
        if (result.resource) {
          if (declaredResource || result.frame.disposition === "drop")
            throw new PluginHostError("SSE_FRAME");
          declaredResource = declared = result.resource;
        }
        if (result.terminal && (result.terminal.bytes || framer.snapshot().ready > 1 || framer.snapshot().incomplete))
          throw new PluginHostError("SSE_AFTER_TERMINAL");
        let bytes = frame.wire, materialized, renderCharge = 0;
        try {
          const plan = result.frame;
          if (plan.disposition === "drop" && (plan.body || plan.data_only || plan.extra?.length))
            throw new PluginHostError("ABI_OUTPUT");
          if (plan.body) {
            ensureIndex(frame);
            materialized = documents.materialize(owner, plan.body);
            renderCharge = 8 * (materialized.bytes.length + frame.wire.length) + 512;
            adjust(renderCharge);
            bytes = render(frame, materialized.bytes, plan.data_only === true);
          } else if (plan.data_only)
            bytes = render(frame, frame.data, true);
          if (plan.extra?.length)
            bytes = Buffer.concat([
              bytes,
              ...plan.extra.map((literal) => Buffer.from(`data: ${literal}

`))
            ]);
          if (plan.disposition === "drop")
            bytes = new Uint8Array;
          if (bytes.length > 2 * (options.maxEventBytes ?? 1048576) + (64 << 10))
            throw new PluginHostError("SSE_OUTPUT_BUDGET");
          if (bytes.length)
            options.takeOutput(bytes.length);
          if (result.frame.disposition === "hold")
            hold(bytes);
          else if (bytes.length)
            chunks.push(encoded(bytes));
        } finally {
          materialized?.release();
          if (renderCharge)
            adjust(-renderCharge);
        }
        clearFrame();
        frames++;
        queries = 0;
        latest = result;
        if (pendingHeld && (!result.usage || canonical(pendingHeld.usage) !== canonical(result.usage)))
          await recordBeforeContinuing();
        if (result.terminal) {
          if (result.terminal.bytes || framer.snapshot().ready || framer.snapshot().incomplete)
            throw new PluginHostError("SSE_AFTER_TERMINAL");
          const joined = new Uint8Array(Buffer.concat(held, heldBytes));
          candidate = { kind: result.terminal.kind, bytes: encoded(joined) };
          adjust(-heldCharge);
          held = [];
          heldBytes = 0;
          heldCharge = 0;
          break;
        }
        if (observeUsage && result.usage && (framer.snapshot().ready || backlog.length) && (!entry?.usage || result.finality !== entry.finality || canonical(result.usage) !== canonical(entry.usage))) {
          if (result.frame.disposition !== "hold")
            break;
          pendingHeld = result;
        }
      }
      if (current)
        inspection = {};
      if (ended && !current && !framer.snapshot().ready) {
        const result = await options.call("stream_finish", new Uint8Array, signal, undefined, true);
        if (result.kind === "failure") {
          if (pendingHeld)
            await recordHeld();
          options.dispose();
          return {
            abi_version: result.abi_version,
            kind: result.kind,
            status: result.status,
            code: result.code,
            ...latest?.usage ? { usage: latest.usage, finality: latest.finality } : {}
          };
        }
        if (result.kind !== "output")
          throw new PluginHostError("ABI_OUTPUT");
        latest = result;
        finalized = true;
        for (const b of buffers.values())
          adjust(-b.charge);
        buffers.clear();
        appendTokens.clear();
        if (tokenCharge) {
          adjust(-tokenCharge);
          tokenCharge = 0;
        }
        bufferMetered = 0;
      }
      if (pendingHeld && (!latest?.usage || canonical(pendingHeld.usage) !== canonical(latest.usage)))
        await recordBeforeContinuing();
      const result = {
        ...output(),
        consumed,
        chunks,
        ...declared ? { resource: declared } : {},
        ...candidate ? { terminal: candidate } : {},
        needs_input: !candidate && !current && framer.snapshot().ready === 0 && !backlog.length && !ended
      };
      const size = chunks.reduce((n, s) => n + Buffer.byteLength(s, "base64"), 0) + (candidate ? Buffer.byteLength(candidate.bytes, "base64") : 0);
      if (size > options.maxOutputBytes)
        throw new PluginHostError("OUTPUT_BUDGET");
      if (batchCharge && !options.disposed()) {
        const id = crypto.randomUUID();
        leases.set(id, {
          charge: batchCharge,
          values: [...chunks, ...candidate ? [candidate.bytes] : []]
        });
        batchCharge = 0;
        result.output_id = id;
      }
      return result;
    } catch (error) {
      options.dispose();
      if (publicationFailed)
        throw error;
      if (pendingHeld)
        await recordHeld();
      if (error instanceof TypeError)
        return { abi_version: 1, kind: "failure", status: 502, code: "invalid_utf8" };
      if (error instanceof PluginHostError) {
        const code = {
          SSE_EVENT_BUDGET: "stream_frame_budget",
          SSE_WIRE_BUDGET: "stream_frame_budget",
          SSE_TRUNCATED: "stream_truncated",
          EVENTSTREAM_INVALID: "invalid_stream",
          SSE_AFTER_TERMINAL: "data_after_terminal",
          JSON_INVALID: "invalid_json",
          JSON_DUPLICATE_KEY: "invalid_json",
          JSON_LIMIT: "invalid_json",
          JSON_NUMERIC_LIMIT: "numeric_limit",
          JSON_COMPOSE_SOURCE: "invalid_json",
          STRING_BYTE_BUDGET: "tool_budget"
        };
        if (code[error.code])
          return {
            abi_version: 1,
            kind: "failure",
            status: 502,
            code: code[error.code],
            ...latest?.usage ? { usage: latest.usage, finality: latest.finality } : {}
          };
      }
      throw error;
    } finally {
      running = false;
      if (batchCharge) {
        adjust(-batchCharge);
        batchCharge = 0;
      }
    }
  }
  return {
    invoke,
    release,
    snapshot: () => ({
      ...framer.snapshot(),
      buffers: buffers.size,
      bufferMetered,
      appendOps,
      heldBytes,
      outputs: leases.size
    }),
    dispose() {
      if (closed)
        return;
      closed = true;
      framer.dispose();
      for (const b of buffers.values())
        adjust(-b.charge);
      buffers.clear();
      appendTokens.clear();
      if (tokenCharge) {
        adjust(-tokenCharge);
        tokenCharge = 0;
      }
      bufferMetered = 0;
      for (const id of leases.keys())
        release(id);
      adjust(-heldCharge);
      held = [];
      heldBytes = 0;
      heldCharge = 0;
      if (batchCharge) {
        adjust(-batchCharge);
        batchCharge = 0;
      }
      current = undefined;
      inspection = {};
      operation = undefined;
    }
  };
}

// packages/plugin-host/src/aws-eventstream.ts
var crcTable = Uint32Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0;bit < 8; bit++)
    value = value & 1 ? 3988292384 ^ value >>> 1 : value >>> 1;
  return value >>> 0;
});
function crc32(bytes) {
  let value = 4294967295;
  for (const byte of bytes)
    value = crcTable[(value ^ byte) & 255] ^ value >>> 8;
  return (value ^ 4294967295) >>> 0;
}
var invalid = () => new PluginHostError("EVENTSTREAM_INVALID");
var utf8 = new TextDecoder("utf-8", { fatal: true });
function createAwsEventStreamDecoder(maxEventBytes = 1048576) {
  const maxMessage = maxEventBytes * 2 + 4096;
  let buffer = new Uint8Array(0);
  function message(bytes, view, length, headerLength) {
    const headers = {};
    let at = 12;
    while (at < 12 + headerLength) {
      const nameLength = bytes[at++];
      if (!nameLength || at + nameLength + 3 > 12 + headerLength)
        throw invalid();
      const name = utf8.decode(bytes.subarray(at, at + nameLength));
      at += nameLength;
      if (bytes[at++] !== 7)
        throw invalid();
      const size = view.getUint16(at);
      at += 2;
      if (at + size > 12 + headerLength || Object.hasOwn(headers, name))
        throw invalid();
      headers[name] = utf8.decode(bytes.subarray(at, at + size));
      at += size;
    }
    if (headers[":message-type"] !== "event" || headers[":event-type"] !== "chunk")
      throw invalid();
    const payload = JSON.parse(utf8.decode(bytes.subarray(12 + headerLength, length - 4)));
    if (!payload || typeof payload !== "object" || Array.isArray(payload))
      throw invalid();
    const fields = Object.keys(payload), encoded = payload.bytes;
    if (fields.length !== 1 || typeof encoded !== "string" || !encoded || encoded.length % 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(encoded))
      throw invalid();
    const data = Buffer.from(encoded, "base64");
    if (data.length > maxEventBytes || data.includes(10) || data.includes(13))
      throw invalid();
    const inner = JSON.parse(utf8.decode(data));
    const type = inner && typeof inner === "object" && !Array.isArray(inner) ? inner.type : undefined;
    const event = typeof type === "string" && /^[\x21-\x7e]{1,200}$/.test(type) ? type : "";
    const prefix = event ? `event: ${event}
` : "";
    return Buffer.concat([Buffer.from(`${prefix}data: `), data, Buffer.from(`

`)]);
  }
  return {
    feed(chunk) {
      if (buffer.length + chunk.length > maxMessage * 2)
        throw invalid();
      const merged = new Uint8Array(buffer.length + chunk.length);
      merged.set(buffer);
      merged.set(chunk, buffer.length);
      const output = [];
      let offset = 0;
      try {
        while (merged.length - offset >= 12) {
          const bytes = merged.subarray(offset), view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), length = view.getUint32(0), headerLength = view.getUint32(4);
          if (length < 16 || length > maxMessage || headerLength > length - 16 || crc32(bytes.subarray(0, 8)) !== view.getUint32(8))
            throw invalid();
          if (bytes.length < length)
            break;
          if (crc32(bytes.subarray(0, length - 4)) !== view.getUint32(length - 4))
            throw invalid();
          output.push(message(bytes, view, length, headerLength));
          offset += length;
        }
      } catch (error) {
        buffer = new Uint8Array(0);
        if (error instanceof PluginHostError)
          throw error;
        throw invalid();
      }
      buffer = merged.slice(offset);
      return Buffer.concat(output);
    },
    finish() {
      if (buffer.length)
        throw new PluginHostError("SSE_TRUNCATED");
    }
  };
}

// packages/plugin-host/src/attempts.ts
function createPluginAttempts(supervisor, limits = {}) {
  const maxAttempts = limits.maxAttempts ?? 128, maxStateBytes = limits.maxStateBytes ?? 16 << 20;
  if (!Number.isSafeInteger(maxAttempts) || maxAttempts < 1 || maxAttempts > 1e4 || !Number.isSafeInteger(maxStateBytes) || maxStateBytes < 1 || maxStateBytes > 256 << 20)
    throw new PluginHostError("CONFIG_INVALID");
  const live = new Map;
  const preparing = new Set;
  const connections = new Map;
  const documents = createJSONDocuments(limits.maxJSONBytes);
  if ((limits.additionalExecutors?.length ?? 0) > 16)
    throw new PluginHostError("CONFIG_INVALID");
  const executors = new Set([supervisor, ...limits.additionalExecutors ?? []]);
  const subscriptions = [];
  try {
    for (const executor of executors)
      subscriptions.push(executor.onDisconnect((connection) => {
        for (const [owner, current] of connections)
          if (current === connection)
            live.get(owner)?.();
      }));
  } catch (error) {
    for (const unsubscribe of subscriptions)
      unsubscribe();
    throw error;
  }
  const modules = new Map;
  let retained = 0, reserved = 0, closed = false;
  function checkCapacity() {
    if (closed)
      throw new PluginHostError("HOST_CLOSED");
    if (live.size + preparing.size >= maxAttempts)
      throw new PluginHostError("ATTEMPT_BUDGET");
  }
  function dispose() {
    if (closed)
      return;
    closed = true;
    preparing.clear();
    for (const closeAttempt of live.values())
      closeAttempt();
    for (const unsubscribe of subscriptions)
      unsubscribe();
  }
  return {
    dispose,
    reservePreparation() {
      checkCapacity();
      const release = () => {
        preparing.delete(release);
      };
      preparing.add(release);
      return release;
    },
    create(pkg, options, executor = supervisor) {
      checkCapacity();
      if (!executors.has(executor))
        throw new PluginHostError("CONFIG_INVALID");
      const maxState = options.maxStateBytes ?? 256 << 10, maxOutput = options.maxOutputBytes ?? 64 << 20, batchOutput = options.batchOutputBytes ?? 128 << 10;
      const batchInput = options.maxBatchInputBytes ?? 128 << 10;
      if (![maxState, maxOutput, batchOutput].every((n) => Number.isSafeInteger(n) && n > 0) || maxState > 1 << 20 || batchOutput > 16 << 20 || !Number.isSafeInteger(batchInput) || batchInput < 1 || batchInput > 16 << 20 || maxOutput > 256 << 20 || options.maxEventBytes !== undefined && (!Number.isSafeInteger(options.maxEventBytes) || options.maxEventBytes < 1024 || options.maxEventBytes > 16 << 20) || !Number.isSafeInteger(options.deadlineAt) || options.deadlineAt <= Date.now() || options.deadlineAt - Date.now() > 2147483647)
        throw new PluginHostError("CONFIG_INVALID");
      const trusted = verifiedPackageRuntime(pkg);
      const { hash: moduleHash, byteLength } = pluginModuleInfo(trusted.module);
      const config = validateConfig(trusted.configSchema, options.config);
      const binding = {
        id: crypto.randomUUID(),
        tenant: options.tenant,
        attempt: options.attempt,
        incarnation: options.incarnation,
        plugin: trusted.digest,
        config: sha256(canonical(config))
      };
      sessionSchema.parse({ ...binding, sequence: 0 });
      let code = modules.get(moduleHash);
      if (!code) {
        if (modules.size >= 4 || [...modules.values()].reduce((n, item) => n + item.byteLength, byteLength) > 32 << 20)
          throw new PluginHostError("MODULE_BUDGET");
        code = { module: trusted.module, byteLength, refs: 0 };
        modules.set(moduleHash, code);
      }
      code.refs++;
      const module = code.module, entrypoint = trusted.manifest.entrypoint, capabilities = trusted.manifest.capabilities;
      let state, sequence = 0, outputBytes = 0, busy = false, disposed = false, stream = false, finished = false;
      let jsonBusy = false, operationBusy = false;
      const observers = new Set;
      let sse;
      const controller = new AbortController;
      const deadline = setTimeout(dispose, Math.max(1, options.deadlineAt - Date.now()));
      function dispose() {
        if (disposed)
          return;
        disposed = true;
        controller.abort();
        clearTimeout(deadline);
        retained -= state?.length ?? 0;
        state = undefined;
        live.delete(binding.id);
        connections.delete(binding.id);
        sse?.dispose();
        documents.dispose(binding.id);
        if (--code.refs === 0)
          modules.delete(moduleHash);
        const listeners = [...observers];
        observers.clear();
        for (const listener of listeners)
          try {
            listener();
          } catch {
            continue;
          }
      }
      live.set(binding.id, dispose);
      async function invokeRaw(hook, payload = new Uint8Array, signal, document, frame = false) {
        if (disposed || Date.now() >= options.deadlineAt) {
          dispose();
          throw new PluginHostError("ATTEMPT_CLOSED");
        }
        if (busy || jsonBusy && !document)
          throw new PluginHostError("BATCH_CONCURRENT");
        if (!document && (hook === "prepare" || hook === "response" || hook === "error" || hook === "resource_response"))
          throw new PluginHostError("JSON_DOCUMENT_REQUIRED");
        if (finished && hook !== "stream_dispose" && hook !== "stream_finish")
          throw new PluginHostError("STREAM_FINISHED");
        if ((hook === "stream_feed" || hook === "stream_drain" || hook === "stream_finish") && !stream)
          throw new PluginHostError("STREAM_NOT_OPEN");
        if (hook === "stream_open" && stream)
          throw new PluginHostError("STREAM_ALREADY_OPEN");
        if (payload.length > batchInput)
          throw new PluginHostError("INPUT_BUDGET");
        if (outputBytes >= maxOutput) {
          dispose();
          throw new PluginHostError("OUTPUT_BUDGET");
        }
        if (retained + reserved + maxState > maxStateBytes)
          throw new PluginHostError("STATE_BUDGET");
        const combined = signal ? AbortSignal.any([signal, controller.signal]) : controller.signal;
        if (combined.aborted) {
          dispose();
          throw new PluginHostError("CALL_CANCELLED");
        }
        const input = inputSchema.parse({
          abi_version: 1,
          hook,
          session: { ...binding, sequence },
          config,
          payload: Buffer.from(payload).toString("base64"),
          output_budget: Math.min(batchOutput, maxOutput - outputBytes)
        });
        busy = true;
        reserved += maxState;
        try {
          const loaded = await executor.load(module, combined);
          if (disposed || combined.aborted)
            throw new PluginHostError("CALL_CANCELLED");
          const previousConnection = connections.get(binding.id);
          if (previousConnection && previousConnection !== loaded.connection)
            throw new PluginHostError("HELPER_RESTARTED");
          connections.set(binding.id, loaded.connection);
          const reply = await executor.call(loaded.hash, new TextEncoder().encode(JSON.stringify(input)), state, {
            signal: combined,
            timeoutMs: Math.max(1, options.deadlineAt - Date.now()),
            function: entrypoint
          });
          if (disposed || combined.aborted)
            throw new PluginHostError("CALL_CANCELLED");
          if (reply.state.length > maxState)
            throw new PluginHostError("STATE_BUDGET");
          let result;
          try {
            result = resultSchema.parse(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(reply.output)));
          } catch {
            throw new PluginHostError("ABI_INVALID");
          }
          if ((result.kind === "output" || result.kind === "failure") && result.usage && Object.keys(result.usage).some((key) => !capabilities.dimensions.includes(key)))
            throw new PluginHostError("ABI_OUTPUT");
          if (result.kind === "failure") {
            if (!frame)
              dispose();
            return result;
          }
          const expected = hook === "describe" ? "description" : hook === "resource_prepare" ? "resource_request" : hook === "prepare" || hook === "balance_prepare" ? "prepared" : hook === "stream_dispose" ? "disposed" : "output";
          if (result.kind === "inspect" && (!document || result.document !== document.handle))
            throw new PluginHostError("JSON_HANDLE");
          if (result.kind !== expected && result.kind !== "inspect" && !(frame && (result.kind === "buffer_append" || result.kind === "buffer_check")))
            throw new PluginHostError("ABI_RESULT");
          if (result.kind === "description" && canonical(result.capabilities) !== canonical(capabilities))
            throw new PluginHostError("CAPABILITIES_MISMATCH");
          if (result.kind === "resource_request" && (!capabilities.resources || !capabilities.auth.includes(result.request.auth.type)))
            throw new PluginHostError("PREPARE_INVALID");
          if (result.kind === "prepared") {
            if (!capabilities.operations.includes(result.request.manifest.operation) || !capabilities.auth.includes(result.request.auth.type) || result.request.manifest.input_bytes !== (document?.bytes ?? payload.length) || [
              ...Object.keys(result.request.manifest.quantities ?? {}),
              ...Object.keys(result.request.binary?.usage ?? {})
            ].some((key) => !capabilities.dimensions.includes(key)) || result.request.manifest.images !== undefined && result.request.manifest.ceilings.images !== result.request.manifest.images)
              throw new PluginHostError("PREPARE_INVALID");
            if (["chat", "responses", "messages", "gemini", "completions"].includes(result.request.manifest.operation) && !result.request.manifest.ceilings.output_tokens)
              throw new PluginHostError("OUTPUT_CEILING_REQUIRED");
          }
          if (result.kind === "output") {
            if (result.body && (!document || result.body.document !== document.handle) || document && !frame && (!result.body || result.chunks.length))
              throw new PluginHostError("JSON_HANDLE");
            const bytes = result.chunks.reduce((sum, value) => sum + Buffer.byteLength(value, "base64"), 0) + (result.terminal ? Buffer.byteLength(result.terminal.bytes, "base64") : 0);
            if (result.consumed > payload.length || hook !== "stream_feed" && result.consumed !== 0 || bytes > input.output_budget || result.resource !== undefined && !capabilities.resources || result.terminal?.kind === "pending" && (frame || !result.resource || result.finality === "FINAL") || outputBytes + bytes > maxOutput || result.finality === "FINAL" && (!result.usage || !Object.keys(result.usage).length) || result.usage && Object.keys(result.usage).some((key) => !capabilities.dimensions.includes(key)))
              throw new PluginHostError("ABI_OUTPUT");
            outputBytes += bytes;
            if (result.terminal)
              finished = true;
          }
          retained -= state?.length ?? 0;
          state = reply.state;
          retained += state.length;
          sequence++;
          if (hook === "stream_open")
            stream = true;
          if (hook === "stream_finish" && !frame || hook === "stream_dispose")
            dispose();
          return result;
        } catch (error) {
          dispose();
          throw error;
        } finally {
          reserved -= maxState;
          busy = false;
        }
      }
      function takeOutput(bytes) {
        if (outputBytes + bytes > maxOutput)
          throw new PluginHostError("OUTPUT_BUDGET");
        outputBytes += bytes;
      }
      if (capabilities.stream_codec !== "none")
        sse = createSSEStream({
          owner: binding.id,
          documents,
          call: invokeRaw,
          sequence: () => sequence,
          disposed: () => disposed,
          dispose,
          takeOutput,
          ...options.maxEventBytes ? { maxEventBytes: options.maxEventBytes } : {},
          maxInputBytes: batchInput,
          maxOutputBytes: maxOutput,
          ...capabilities.stream_codec === "aws-eventstream" ? { decoder: createAwsEventStreamDecoder(options.maxEventBytes) } : {}
        });
      return {
        id: binding.id,
        onDispose(listener) {
          if (disposed) {
            listener();
            return () => {};
          }
          if (observers.size >= 16)
            throw new PluginHostError("OBSERVER_BUDGET");
          observers.add(listener);
          return () => {
            observers.delete(listener);
          };
        },
        async invoke(hook, payload, signal, observeUsage) {
          if (operationBusy)
            throw new PluginHostError("BATCH_CONCURRENT");
          operationBusy = true;
          try {
            return await (sse && hook.startsWith("stream_") ? sse.invoke(hook, payload ?? new Uint8Array, signal, observeUsage) : invokeRaw(hook, payload, signal));
          } finally {
            operationBusy = false;
          }
        },
        releaseOutput: (id) => sse?.release(id) ?? false,
        async transformJSON(hook, metadata, body, signal) {
          if (disposed || operationBusy || jsonBusy || busy)
            throw new PluginHostError(disposed ? "ATTEMPT_CLOSED" : "BATCH_CONCURRENT");
          jsonBusy = true;
          operationBusy = true;
          let indexed = false;
          try {
            if (signal?.aborted)
              throw new PluginHostError("CALL_CANCELLED");
            const safeMetadata = jsonMetadataSchema.parse(metadata);
            const document = documents.register(binding.id, body);
            indexed = true;
            const inspection = Object.create(null);
            for (let round = 0;round <= 4; round++) {
              const result = await invokeRaw(hook, new TextEncoder().encode(JSON.stringify({ ...safeMetadata, document, inspection })), signal, document);
              if (result.kind === "inspect") {
                if (round === 4)
                  throw new PluginHostError("JSON_INSPECTION_BUDGET");
                if (result.pointers.some((pointer) => Object.hasOwn(inspection, pointer)))
                  throw new PluginHostError("JSON_INSPECTION_REPEAT");
                Object.assign(inspection, documents.inspect(binding.id, document.handle, result.pointers));
                continue;
              }
              if (result.kind === "failure")
                return { result };
              const plan = result.kind === "prepared" ? result.request.body : result.kind === "output" ? result.body : undefined;
              if (!plan || plan.document !== document.handle)
                throw new PluginHostError("JSON_HANDLE");
              let materialized;
              try {
                materialized = documents.materialize(binding.id, plan);
              } catch (error) {
                if (error instanceof PluginHostError && error.code === "JSON_COMPOSE_SOURCE")
                  return {
                    result: {
                      abi_version: 1,
                      kind: "failure",
                      status: hook === "prepare" ? 400 : 502,
                      code: "invalid_json"
                    }
                  };
                throw error;
              }
              if (Date.now() >= options.deadlineAt || signal?.aborted || disposed)
                throw new PluginHostError("DEADLINE");
              if (outputBytes + materialized.bytes.length > maxOutput)
                throw new PluginHostError("OUTPUT_BUDGET");
              outputBytes += materialized.bytes.length;
              return { result, body: materialized.bytes, bodyDigest: materialized.digest };
            }
            throw new PluginHostError("JSON_INSPECTION_BUDGET");
          } catch (error) {
            dispose();
            if (!indexed && (error instanceof TypeError || error instanceof PluginHostError && [
              "JSON_INVALID",
              "JSON_DUPLICATE_KEY",
              "JSON_NUMERIC_LIMIT",
              "JSON_LIMIT",
              "JSON_BODY_BUDGET"
            ].includes(error.code)))
              return {
                result: {
                  abi_version: 1,
                  kind: "failure",
                  status: error instanceof PluginHostError && error.code === "JSON_BODY_BUDGET" ? 413 : hook === "prepare" ? 400 : 502,
                  code: error instanceof PluginHostError && error.code === "JSON_NUMERIC_LIMIT" ? "numeric_limit" : "invalid_json"
                }
              };
            throw error;
          } finally {
            jsonBusy = false;
            operationBusy = false;
          }
        },
        dispose,
        snapshot: () => ({
          sequence,
          stateBytes: state?.length ?? 0,
          outputBytes,
          disposed,
          busy,
          ...sse ? { stream: sse.snapshot() } : {}
        })
      };
    },
    snapshot: () => ({
      attempts: live.size,
      stateBytes: retained,
      reservedStateBytes: reserved,
      moduleBytes: [...modules.values()].reduce((n, item) => n + item.byteLength, 0),
      json: documents.snapshot(),
      closed
    }),
    async close() {
      dispose();
      const results = await Promise.allSettled([...executors].map((executor) => executor.close()));
      const failure = results.find((result) => result.status === "rejected");
      if (failure?.status === "rejected")
        throw failure.reason;
    }
  };
}
// packages/plugin-host/src/builtin-worker.ts
function createBuiltinWorkerExecutor(options) {
  const limits = {
    slots: options.slots ?? 4,
    maxPending: options.maxPending ?? 128,
    maxPendingBytes: options.maxPendingBytes ?? 16 << 20,
    callMs: options.callMs ?? 1000
  };
  for (const [key, value] of Object.entries(limits))
    if (!Number.isSafeInteger(value) || value < 1 || value > {
      slots: 16,
      maxPending: 1024,
      maxPendingBytes: 256 << 20,
      callMs: 30000
    }[key])
      throw new PluginHostError("CONFIG_INVALID");
  if (options.code.length > 16 << 20)
    throw new PluginHostError("WORKER_ARTIFACT_INVALID");
  const code = new Uint8Array(options.code);
  if (!/^[a-f0-9]{64}$/.test(options.digest) || new Bun.CryptoHasher("sha256").update(code).digest("hex") !== options.digest || !options.modules.length || options.modules.length > 16 || options.modules.some((hash) => !/^[a-f0-9]{64}$/.test(hash)))
    throw new PluginHostError("WORKER_ARTIFACT_INVALID");
  const modules = new Set(options.modules);
  const url = URL.createObjectURL(new Blob([code], { type: "text/javascript" }));
  const slots = new Set;
  const pending = new Map;
  const queue = [];
  const observers = new Set;
  const connection = crypto.randomUUID();
  const starts = [];
  let sequence = 0, started = 0, pendingBytes = 0, closed = false;
  let closing;
  function settle(job, error, value) {
    if (!pending.delete(job.id))
      return;
    pendingBytes -= job.bytes;
    clearTimeout(job.timer);
    job.signal?.removeEventListener("abort", job.abort);
    const at = queue.indexOf(job);
    if (at >= 0)
      queue.splice(at, 1);
    if (job.slot?.job === job)
      delete job.slot.job;
    job.input = new Uint8Array;
    job.state = undefined;
    if (error)
      job.reject(error);
    else
      job.resolve(value);
  }
  function retire(slot, error) {
    if (slot.retiring)
      return;
    slot.retiring = true;
    if (slot.job)
      settle(slot.job, error);
    slot.worker.terminate();
  }
  function createSlot() {
    const now = performance.now();
    while (starts.length && starts[0] <= now - 1000)
      starts.shift();
    if (starts.length >= 16)
      throw new PluginHostError("RESTART_BUDGET");
    starts.push(now);
    started++;
    const worker = new Worker(url, { ref: true, smol: true, env: {} });
    const done = Promise.withResolvers();
    const slot = {
      worker,
      ready: false,
      retiring: false,
      closed: done.promise,
      didClose: done.resolve
    };
    slots.add(slot);
    const onClose = () => {
      if (slot.job)
        settle(slot.job, new PluginHostError("WORKER_EXITED"));
      slots.delete(slot);
      worker.onmessage = null;
      worker.onerror = null;
      worker.removeEventListener("messageerror", onMessageError);
      worker.removeEventListener("close", onClose);
      slot.didClose();
      pump();
    };
    const onMessageError = () => retire(slot, new PluginHostError("PROTOCOL_INVALID"));
    worker.addEventListener("close", onClose);
    worker.addEventListener("messageerror", onMessageError);
    worker.onerror = (event) => {
      event.preventDefault();
      retire(slot, new PluginHostError("WORKER_FAILED"));
    };
    worker.onmessage = ({ data }) => {
      if (slot.retiring)
        return;
      if (data?.version === 1 && data.event === "ready" && !slot.ready) {
        slot.ready = true;
        dispatch(slot);
        return;
      }
      const job = slot.job;
      if (!slot.ready || !job || data?.version !== 1 || data.id !== job.id) {
        retire(slot, new PluginHostError("PROTOCOL_INVALID"));
        return;
      }
      if (performance.now() >= job.deadline) {
        retire(slot, new PluginHostError("CALL_TIMEOUT"));
        return;
      }
      if (data.error === "GUEST_ERROR" || data.error === "OUTPUT_BUDGET") {
        settle(job, new PluginHostError(data.error));
      } else if (!(data.output instanceof Uint8Array) || !(data.state instanceof Uint8Array) || !(data.output.buffer instanceof ArrayBuffer) || !(data.state.buffer instanceof ArrayBuffer) || data.output.buffer.byteLength > 256 << 10 || data.state.buffer.byteLength > 256 << 10 || data.output.length > 256 << 10 || data.state.length > 256 << 10 || data.error !== undefined) {
        retire(slot, new PluginHostError("PROTOCOL_INVALID"));
        return;
      } else {
        settle(job, undefined, {
          output: data.output.byteLength === data.output.buffer.byteLength ? data.output : new Uint8Array(data.output),
          state: data.state.byteLength === data.state.buffer.byteLength ? data.state : new Uint8Array(data.state)
        });
      }
      pump();
    };
    return slot;
  }
  function dispatch(slot) {
    const job = slot.job;
    if (!job || !slot.ready || slot.retiring)
      return;
    if (job.signal?.aborted || performance.now() >= job.deadline) {
      settle(job, new PluginHostError(job.signal?.aborted ? "CALL_CANCELLED" : "CALL_TIMEOUT"));
      pump();
      return;
    }
    try {
      slot.worker.postMessage({
        version: 1,
        id: job.id,
        module: job.hash,
        input: job.input,
        state: job.state
      });
    } catch {
      retire(slot, new PluginHostError("WORKER_FAILED"));
    }
  }
  function pump() {
    if (closed)
      return;
    while (queue.length) {
      let slot = [...slots].find((item) => !item.retiring && !item.job);
      if (!slot && slots.size >= limits.slots)
        return;
      const job = queue.shift();
      if (job.signal?.aborted || performance.now() >= job.deadline) {
        settle(job, new PluginHostError(job.signal?.aborted ? "CALL_CANCELLED" : "CALL_TIMEOUT"));
        continue;
      }
      if (!slot) {
        try {
          slot = createSlot();
        } catch (error) {
          settle(job, error instanceof PluginHostError ? error : new PluginHostError("WORKER_FAILED"));
          continue;
        }
      }
      slot.job = job;
      job.slot = slot;
      dispatch(slot);
    }
  }
  return {
    onDisconnect(listener) {
      if (closed)
        throw new PluginHostError("HOST_CLOSED");
      observers.add(listener);
      return () => observers.delete(listener);
    },
    async load(module, signal) {
      if (closed)
        throw new PluginHostError("HOST_CLOSED");
      if (signal?.aborted)
        throw new PluginHostError("CALL_CANCELLED");
      if (module instanceof Uint8Array && module.length > 8 << 20)
        throw new PluginHostError("MODULE_BUDGET");
      const hash = pluginModuleInfo(module instanceof Uint8Array ? ownPluginModule(module) : module).hash;
      if (!modules.has(hash))
        throw new PluginHostError("MODULE_MISSING");
      return { hash, connection };
    },
    call(hash, input, state, config = {}) {
      if (closed)
        return Promise.reject(new PluginHostError("HOST_CLOSED"));
      if (config.signal?.aborted)
        return Promise.reject(new PluginHostError("CALL_CANCELLED"));
      if (!modules.has(hash))
        return Promise.reject(new PluginHostError("MODULE_MISSING"));
      if (config.function !== undefined && config.function !== "invoke")
        return Promise.reject(new PluginHostError("COMMAND_MISSING"));
      if (input.length > 256 << 10 || (state?.length ?? 0) > 256 << 10)
        return Promise.reject(new PluginHostError("INPUT_BUDGET"));
      const timeoutMs = Math.min(config.timeoutMs ?? limits.callMs, limits.callMs);
      if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1)
        return Promise.reject(new PluginHostError("DEADLINE"));
      const bytes = input.length + (state?.length ?? 0);
      if (pending.size >= limits.maxPending || pendingBytes + bytes > limits.maxPendingBytes)
        return Promise.reject(new PluginHostError("PENDING_BUDGET"));
      return new Promise((resolve, reject) => {
        const job = {
          id: String(++sequence),
          hash,
          input: new Uint8Array(input),
          state: state ? new Uint8Array(state) : undefined,
          bytes,
          deadline: performance.now() + timeoutMs,
          signal: config.signal,
          resolve,
          reject,
          timer: setTimeout(() => cancel("CALL_TIMEOUT"), timeoutMs),
          abort: () => cancel("CALL_CANCELLED")
        };
        function cancel(code) {
          if (!pending.has(job.id))
            return;
          if (job.slot)
            retire(job.slot, new PluginHostError(code));
          else
            settle(job, new PluginHostError(code));
          pump();
        }
        pending.set(job.id, job);
        pendingBytes += bytes;
        config.signal?.addEventListener("abort", job.abort, { once: true });
        queue.push(job);
        pump();
      });
    },
    snapshot: () => ({
      started,
      workers: slots.size,
      retiring: [...slots].filter((slot) => slot.retiring).length,
      active: [...slots].filter((slot) => slot.job).length,
      queued: queue.length,
      pending: pending.size,
      pendingBytes,
      timers: pending.size,
      closed
    }),
    close() {
      if (closing)
        return closing;
      closed = true;
      const done = Promise.withResolvers();
      closing = done.promise;
      for (const job of pending.values())
        settle(job, new PluginHostError("HOST_CLOSED"));
      for (const observer of observers) {
        try {
          observer(connection);
        } catch {}
      }
      observers.clear();
      (async () => {
        try {
          const retiring = [...slots];
          for (const slot of retiring)
            retire(slot, new PluginHostError("HOST_CLOSED"));
          await Promise.all(retiring.map((slot) => slot.closed));
        } finally {
          URL.revokeObjectURL(url);
        }
      })().then(done.resolve, done.reject);
      return closing;
    }
  };
}
// packages/plugin-host/src/artifact-file.ts
import { open as open3 } from "fs/promises";
import { constants as constants2 } from "fs";
async function readPluginArtifact(path, maxBytes, signal) {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > 256 << 20)
    throw new Error("PLUGIN_ARTIFACT_BUDGET_INVALID");
  signal?.throwIfAborted();
  const file = await open3(path, constants2.O_RDONLY | constants2.O_NONBLOCK);
  try {
    const state = await file.stat();
    if (!state.isFile() || state.size < 1 || state.size > maxBytes)
      throw new Error("PLUGIN_ARTIFACT_BUDGET");
    const bytes = new Uint8Array(state.size);
    let at = 0;
    while (at < bytes.length) {
      signal?.throwIfAborted();
      const { bytesRead } = await file.read(bytes, at, Math.min(65536, bytes.length - at), at);
      if (bytesRead === 0)
        throw new Error("PLUGIN_ARTIFACT_CHANGED");
      at += bytesRead;
    }
    if ((await file.read(new Uint8Array(1), 0, 1, at)).bytesRead)
      throw new Error("PLUGIN_ARTIFACT_CHANGED");
    signal?.throwIfAborted();
    return bytes;
  } finally {
    await file.close();
  }
}
// packages/plugin-host/src/fixtures.ts
async function runPluginFixtures(supervisor, pkg) {
  const trusted = verifiedPackageSnapshot(pkg), source = trusted.files.find((file) => file.path === "fixtures/cases.json");
  const suite = fixtureSuiteSchema.parse(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(source.bytes)));
  const host = createPluginAttempts(supervisor);
  function matches(actual, expected, depth = 0) {
    if (depth > 64)
      throw new PluginHostError("FIXTURE_DEPTH");
    if (Array.isArray(expected))
      return Array.isArray(actual) && actual.length === expected.length && expected.every((item, i) => matches(actual[i], item, depth + 1));
    if (expected !== null && typeof expected === "object")
      return actual !== null && typeof actual === "object" && Object.entries(expected).every(([key, value]) => Object.hasOwn(actual, key) && matches(actual[key], value, depth + 1));
    return Object.is(actual, expected);
  }
  let steps = 0;
  try {
    for (const fixture of suite.cases) {
      const attempt = host.create(pkg, {
        tenant: "synthetic-package-fixture",
        attempt: crypto.randomUUID(),
        incarnation: crypto.randomUUID(),
        deadlineAt: Date.now() + 30000,
        config: suite.config
      });
      try {
        for (const step of fixture.steps) {
          steps++;
          if (step.action === "cancel") {
            const controller = new AbortController;
            controller.abort();
            let error;
            try {
              await attempt.invoke(step.hook, new Uint8Array(Buffer.from(step.input, "base64")), controller.signal);
            } catch (caught) {
              error = caught;
            }
            if (!(error instanceof PluginHostError) || error.code !== step.expected_error)
              throw new PluginHostError("FIXTURE_EXPECTATION");
          } else if (step.action === "json") {
            const output = await attempt.transformJSON(step.hook, step.metadata, new Uint8Array(Buffer.from(step.body, "base64")));
            if (!matches(output.result, step.expected) || step.expected_body !== undefined && (!output.body || !Buffer.from(output.body).equals(Buffer.from(step.expected_body, "base64"))))
              throw new PluginHostError("FIXTURE_EXPECTATION");
          } else if (!matches(await attempt.invoke(step.hook, new Uint8Array(Buffer.from(step.input, "base64"))), step.expected))
            throw new PluginHostError("FIXTURE_EXPECTATION");
        }
      } finally {
        attempt.dispose();
      }
    }
  } finally {
    host.dispose();
  }
  return { cases: suite.cases.length, steps, state: host.snapshot() };
}
// packages/plugin-host/src/evidence.ts
function pricedDimensions(usage) {
  return Object.keys(usage).filter((key) => dimensions.includes(key)).sort();
}
function observeAttempt(attempt, binding) {
  let revision = 0n, usage = {}, finality = "UNKNOWN", last = "", finished = false, disposed = false, active = false;
  let pending;
  function open() {
    if (disposed)
      throw new Error("Attempt evidence disposed");
    if (finished)
      throw new Error("Attempt evidence already finished");
  }
  async function operation(run) {
    open();
    if (active)
      throw new Error("Attempt evidence operation already active");
    active = true;
    try {
      const result = await run();
      if (disposed)
        throw new Error("Attempt evidence disposed");
      return result;
    } finally {
      active = false;
    }
  }
  function seal(outcome = {}) {
    revision++;
    return binding.seal({
      event_id: crypto.randomUUID(),
      attempt_id: binding.attemptId,
      permit_epoch: binding.permitEpoch,
      source: "execution",
      source_revision: revision.toString(),
      finality,
      usage: { ...usage },
      final_dimensions: finality === "FINAL" ? pricedDimensions(usage) : [],
      ...outcome
    });
  }
  async function flush() {
    if (!pending)
      return;
    const current = pending;
    await binding.record([current.event]);
    if (pending === current)
      pending = undefined;
  }
  async function emit(defer) {
    if (pending)
      await flush();
    open();
    const event = seal();
    open();
    if (defer && finality === "FINAL")
      pending = { event };
    else
      await binding.record([event]);
  }
  async function terminal(outcome, releasePlugin = false) {
    finished = true;
    try {
      const event = seal(outcome);
      if (disposed)
        throw new Error("Attempt evidence disposed");
      const delivery = binding.record(pending ? [pending.event, event] : [event]);
      if (releasePlugin && pending && binding.delivery === "terminal-group" && outcome?.attempt_state === "SUCCEEDED" && outcome.request_state === "SUCCEEDED")
        attempt.dispose();
      await delivery;
    } finally {
      pending = undefined;
    }
  }
  async function observe(result, defer) {
    open();
    if (result.kind !== "output" && result.kind !== "failure")
      return;
    if (!result.usage)
      return;
    await update({
      usage: { ...result.usage },
      finality: result.kind === "output" ? result.finality : "UNKNOWN"
    }, defer);
  }
  async function update(next, defer) {
    const key = canonical(next);
    if (key === last)
      return;
    usage = next.usage;
    finality = next.finality;
    await emit(defer);
    last = key;
  }
  const progress = binding.delivery === "progressive" ? (result) => observe(result, false) : undefined;
  return {
    async invoke(hook, payload, signal) {
      return operation(async () => {
        const result = await attempt.invoke(hook, payload, signal, progress);
        await observe(result, hook === "response" && binding.delivery === "terminal-group");
        return result;
      });
    },
    async transformJSON(hook, metadata, body, signal) {
      return operation(async () => {
        const transformed = await attempt.transformJSON(hook, metadata, body, signal);
        await observe(transformed.result, hook === "response" && binding.delivery === "terminal-group");
        return transformed;
      });
    },
    async declare(declared) {
      return operation(() => update({ usage: { ...declared }, finality: "FINAL" }, false));
    },
    async finish(outcome, releasePlugin = false) {
      return operation(() => terminal(outcome, releasePlugin));
    },
    async notExecuted(outcome) {
      return operation(async () => {
        if (revision !== 0n)
          throw new Error("Attempt evidence already observed");
        finality = "NOT_EXECUTED";
        await terminal({ ...outcome, attempt_state: "NOT_EXECUTED" });
      });
    },
    flush: () => operation(flush),
    dispose() {
      if (disposed)
        return;
      disposed = true;
      pending = undefined;
      attempt.dispose();
    }
  };
}
export {
  PluginHostError,
  adapterFailureCodes,
  anthropicMessagesReleaseId,
  base64Schema,
  bedrockAnthropicReleaseId,
  builtinWorkerArtifactDigest,
  builtinWorkerProofSchema,
  builtinWorkerRegistrySchema,
  bundledReleaseIds,
  capabilitiesSchema,
  configSchemaSchema,
  createBuiltinWorkerExecutor,
  createPluginAttempts,
  createPluginSupervisor,
  fixtureSuiteSchema,
  framePlanSchema,
  geminiGenerateReleaseId,
  hooks,
  inputSchema,
  jsonMetadataSchema,
  jsonPlanSchema,
  manifestSchema,
  minimaxMusicReleaseId,
  observeAttempt,
  openAIChatReleaseId,
  ownPluginModule,
  packageDigest,
  packageTrust,
  parseBuiltinWorkerArtifact,
  pluginModuleBase64,
  pluginModuleInfo,
  preparedSchema,
  pricedDimensions,
  publishPluginExecutable,
  publisherAdmits,
  publisherNamespaceSchema,
  readPluginArtifact,
  releasePolicySchema,
  resolvePluginExecutable,
  resourceRequestSchema,
  resultSchema,
  rewriteJSON,
  runPluginFixtures,
  sessionSchema,
  sha256,
  terminalSchema,
  validateConfig,
  verifiedPackageRuntime,
  verifiedPackageSnapshot,
  verifyPackage
};
