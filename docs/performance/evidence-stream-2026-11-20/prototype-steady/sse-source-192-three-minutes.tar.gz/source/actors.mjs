import assert from "node:assert/strict";
import { wall,logical,project } from "./common.mjs";
import { createPublicKey, verify, randomUUID } from "node:crypto";
const [kind,path,portText,rateText,secondsText]=Bun.argv.slice(2);
if(kind==="mock"){
  const {SSEParser}=await project("packages/adapters/src/protocol/sse.ts");
  const {createMockApp}=await project("apps/mock-providers/src/app.ts");
  const mode=process.env.SSE_MODE;
  const mock=createMockApp(randomUUID()),app=mock.app,entries=new Map();if(process.env.SSE_MODE==="paced")mock.scenarios.set("synthetic",{repeat:4,chunkBytes:120,chunkDelayMs:50});let duplicates=0;
  if(mode==="burst")mock.scenarios.set("synthetic",{repeat:40});
  const s=Bun.serve({hostname:"127.0.0.1",port:0,async fetch(req){
    const route=new URL(req.url).pathname;
    if(route==="/stop"&&req.headers.get("authorization")===process.env.MOCK_TOKEN){
      const writer=Bun.file(path+".upstream.tsv").writer();writer.write("request_id\tattempt_id\tupstream_received_epoch_ms\tcalls\tprovider_done_epoch_ms\tprovider_eof_epoch_ms\n");
      for(const [id,x] of entries)writer.write([id,x.attempt,x.at,x.calls,x.done,x.eof].join("\t")+"\n");
      await writer.end();setTimeout(()=>s.stop(true),100);return Response.json({requests:entries.size,duplicates});
    }
    if(req.method!=="POST"||route!=="/v1/chat/completions")return new Response("",{status:404});
    const id=req.headers.get("x-probe-id"),attempt=req.headers.get("x-probe-attempt");
    if(!id||!attempt)return new Response("",{status:400});const prior=entries.get(id);
    if(prior){prior.calls++;duplicates++;return new Response("",{status:409});}
    const point={attempt,at:wall(),calls:1};entries.set(id,point);
    const response=await app.fetch(req);response.headers.set("x-probe-id",id);
    assert.equal(response.status,200);assert(response.headers.get("content-type").includes("text/event-stream"));
    const parser=mode==="paced"?new SSEParser(65536):undefined;let injected=false;
    const adapted=parser?response.body.pipeThrough(new TransformStream({transform(chunk,out){
      for(const frame of parser.feed(chunk)){
        let wire=frame.wire;
        if(!injected&&frame.data!=="[DONE]"){const v=JSON.parse(frame.data);if(v.choices?.[0]?.delta?.content){
          v.usage={prompt_tokens:10,prompt_tokens_details:{cached_tokens:3},completion_tokens:1};wire="data: "+JSON.stringify(v)+"\n\n";injected=true;
        }}out.enqueue(new TextEncoder().encode(wire));
      }
    },flush(){assert(!parser.incomplete&&injected);}})):response.body;
    const reader=adapted.getReader();let tail="";
    return new Response(new ReadableStream({async pull(c){const next=await reader.read();if(next.done){point.eof=wall();c.close();return;}
      if(!point.done){const text=tail+Buffer.from(next.value).toString("latin1");if(text.includes("data: [DONE]"))point.done=wall();tail=text.slice(-20);}
      c.enqueue(next.value);
    },cancel:r=>reader.cancel(r)},{highWaterMark:0}),{status:response.status,headers:response.headers});
  }});
  await Bun.write(path+".mock-ready",String(s.port));
}
if(kind==="load"){
  const {SSEParser}=await project("packages/adapters/src/protocol/sse.ts");
  const url="http://127.0.0.1:"+portText+"/v1/chat/completions",rate=Number(rateText),seconds=Number(secondsText),count=rate*seconds;
  const xs=Array.from({length:count},(_,seq)=>({seq,id:randomUUID(),status:0,valid:false}));const pending=new Set();let peak=0,shed=0;const driverLimit=2048;
  await Bun.write(path+".load-ready","ready");while(!await Bun.file(path+".start").exists())await Bun.sleep(5);
  const start=Number(await Bun.file(path+".start").text()),body=JSON.stringify(logical);
  async function send(x){
    x.dispatched=wall();
    try{
      const res=await fetch(url,{method:"POST",headers:{"content-type":"application/json","x-probe-id":x.id,"x-probe-seq":String(x.seq)},body,redirect:"error",signal:AbortSignal.timeout(30000)});
      x.status=res.status;x.headers=wall();assert.equal(x.status,200);assert.equal(res.headers.get("x-probe-id"),x.id);assert(res.headers.get("content-type")?.includes("text/event-stream"));
      const reader=res.body.getReader(),parser=new SSEParser(1048576),expected="Hello, 世界 🌍".repeat(process.env.SSE_MODE==="paced"?4:process.env.SSE_MODE==="burst"?40:1);
      let matched=0,stopped=false,done=false,total=0;
      function events(chunk,flush){for(const frame of parser.feed(chunk,flush)){if(!frame.data)continue;assert(!done);assert.notEqual(frame.event,"error");
        if(frame.data==="[DONE]"){assert(stopped);assert.equal(matched,expected.length);x.done=wall();done=true;continue;}
        const value=JSON.parse(frame.data);assert(!value.error&&value.type!=="error");assert(Array.isArray(value.choices));
        for(const choice of value.choices){x.firstFrame??=wall();if(choice.finish_reason){assert.equal(choice.finish_reason,"stop");assert(!stopped);stopped=true;}
          const content=choice.delta?.content;if(content){assert(!stopped);assert.equal(content,expected.slice(matched,matched+content.length));matched+=content.length;x.firstContent??=wall();}
        }
      }}
      try{for(;;){const next=await reader.read();if(next.done)break;x.firstByte??=wall();total+=next.value.length;assert(total<=1048576);events(next.value,false);}
        events(new Uint8Array(),true);assert(!parser.incomplete&&done&&stopped&&matched===expected.length);x.valid=true;
      }finally{await reader.cancel().catch(()=>undefined);}
    }catch(e){x.error=String(e).replace(/[\t\r\n]/g," ").slice(0,200);}
    x.finish=wall();
  }
  let offered=0;
  while(offered<count){
    const due=Math.min(count,Math.max(0,Math.floor((wall()-start)*rate/1000)+1));
    while(offered<due){
      const x=xs[offered++];x.scheduled=start+x.seq*1000/rate;if(pending.size>=driverLimit){shed++;x.error="client_inflight_limit";x.finish=wall();continue;}const task=send(x);pending.add(task);peak=Math.max(peak,pending.size);void task.finally(()=>pending.delete(task));
    }
    if(offered<count)await Bun.sleep(1);
  }
  await Promise.all(pending);
  const writer=Bun.file(path+".http.tsv").writer();writer.write("seq\trequest_id\tscheduled_epoch_ms\tdispatched_epoch_ms\thttp_validated_epoch_ms\tstatus\tvalid\terror\theaders_epoch_ms\tfirst_byte_epoch_ms\tfirst_frame_epoch_ms\tfirst_content_epoch_ms\tdone_epoch_ms\n");
  for(const x of xs)writer.write([x.seq,x.id,x.scheduled,x.dispatched,x.finish,x.status,Number(x.valid),x.error??"",x.headers,x.firstByte,x.firstFrame,x.firstContent,x.done].join("\t")+"\n");
  await writer.end();await Bun.write(path+".load.json",JSON.stringify({start,seconds,rate,count,peak,shed,driverLimit,valid:xs.filter(x=>x.valid).length}));
}
if(kind==="consumer"){
  const {evidenceProofFields,signedCoreEvidenceEventV1Schema}=await project("packages/contracts/src/core-execution.ts");
  const {canonical}=await project("packages/kernel/src/canonical.ts"),{sha256}=await project("packages/runtime/src/crypto.ts");
  const publicKey=createPublicKey(process.env.PINNED_SIGNER);let verified=0;
  async function send(route,body){
    const res=await fetch("http://127.0.0.1:"+portText+route,{method:"POST",headers:{authorization:"Bearer "+process.env.OBSERVER_TOKEN,"content-type":"application/json"},body:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
    assert.equal(res.status,200,route+" "+res.status);return res.json();
  }
  const writer=Bun.file(path+".ack.tsv").writer();writer.write("request_id\tattempt_id\tevent_id\trevision\tack_observed_epoch_ms\n");
  try{
    for(;;){
      const page=await send("/claim",{});if(page.stop)break;
      if(!page.events.length){await Bun.sleep(3);continue;}
      for(const e of page.events){
        assert.equal(e.customer_atoms,100);assert.equal(e.supplier_atoms,59);assert.deepEqual([e.input_tokens,e.cached_tokens,e.output_tokens,e.reasoning_tokens],[7,3,5,2]);assert(e.revision>=1&&e.revision<=16);assert(["FINAL","PARTIAL"].includes(e.signed_body.finality));
        assert.equal(e.signed_body.event_id,e.event_id);assert.equal(e.signed_body.attempt_id,e.attempt_id);assert.equal(e.signed_body.source_revision,String(e.revision));assert(e.signed_body.signature);
        assert.equal(e.signer,process.env.PINNED_SIGNER);
        const {signature,...body}=signedCoreEvidenceEventV1Schema.parse(e.signed_body);
        if(body.finality==="PARTIAL"&&body.usage.output_tokens==="1"){assert.equal(body.usage.input_tokens,"7");assert.equal(body.usage.cached_input_tokens,"3");assert.equal(body.usage.reasoning_tokens,undefined);}
        else {assert.equal(body.usage.input_tokens,String(e.input_tokens));assert.equal(body.usage.cached_input_tokens,String(e.cached_tokens));assert.equal(body.usage.output_tokens,String(e.output_tokens));assert.equal(body.usage.reasoning_tokens,String(e.reasoning_tokens));}
        assert(verify(null,Buffer.from(JSON.stringify(evidenceProofFields(body,sha256(canonical(body))))),publicKey,Buffer.from(signature,"base64url")));verified++;
      }
      const ids=page.events.map(e=>e.event_id);const ack=await send("/ack",{lease:page.lease,ids});assert.equal(ack.acknowledged,ids.length);const at=wall();
      for(const e of page.events)writer.write([e.request_id,e.attempt_id,e.event_id,e.revision,at].join("\t")+"\n");
      await send("/observed",{at,events:page.events.map(e=>[e.request_id,e.event_id,e.revision])});
    }
  }finally{await writer.end();await Bun.write(path+".consumer.json",JSON.stringify({verified}));}
}
