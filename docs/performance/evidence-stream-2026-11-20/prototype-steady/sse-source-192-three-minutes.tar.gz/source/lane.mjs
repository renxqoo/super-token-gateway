import {createAdapter} from "./adapter.mjs";
let adapter;
async function run({port,x,input,origin}){
  let reader,ack;
  const stop=new AbortController();
  x.events=[];x.trace=[];
  const times=()=>Object.fromEntries(["sent","upHeaders","opened","feedStart","feedEnd","headers","providerDone","verified","released"].filter(k=>x[k]!==undefined).map(k=>[k,x[k]]));
  function publish(kind){
    const ticket=Promise.withResolvers();ack=ticket;
    port.postMessage({type:"fact",kind,event:x.events.at(-1),point:x.trace.at(-1),...times()});return ticket.promise;
  }
  function abort(reason){stop.abort(reason);ack?.reject(reason);return reader?.cancel(reason).catch(()=>undefined);}
  const fail=e=>{port.postMessage({type:"error",error:String(e?.stack??e).slice(0,1800)});};
  port.onmessage=async({data})=>{try{
    if(data.type==="ack"){if(data.terminal)x.terminal=data.terminal;ack?.resolve();ack=undefined;}
    else if(data.type==="reject"){ack?.reject(new Error(data.error));ack=undefined;}
    else if(data.type==="cancel"){await abort(new Error("client_cancelled"));port.close();}
    else if(data.type==="read"){
      const item=await reader.read();
      if(item.done){port.postMessage({type:"end",times:times(),trace:x.trace});port.close();}
      else port.postMessage({type:"chunk",bytes:item.value});
    }
  }catch(e){await abort(e);fail(e);port.close();}};
  try{
    const response=await adapter.invoke(x,input,origin,{progress:()=>publish("progress"),settle:()=>publish("settle"),signal:stop.signal,release:()=>{},failure:()=>{}});
    reader=response.body.getReader();
    port.postMessage({type:"headers",headers:[...response.headers],times:times()});
  }catch(e){fail(e);await abort(e);port.close();}
}
self.onmessage=async({data})=>{
  try{
    if(data.type==="init"){adapter=await createAdapter(data.secret);self.postMessage({type:"ready",artifacts:adapter.artifacts});}
    else if(data.type==="run"){void run(data);}
    else if(data.type==="stats"){self.postMessage({type:"stats",counts:adapter.counts,snapshot:adapter.snapshot()});}
    else if(data.type==="close"){await adapter?.close();self.postMessage({type:"closed"});self.close();}
  }catch(e){self.postMessage({type:"fatal",error:String(e?.stack??e)});}
};

self.postMessage({type:"listening"});
