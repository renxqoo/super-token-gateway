BEGIN;
DO $$
<<probe>>
DECLARE
  request_id uuid:=gen_random_uuid();
  attempt uuid:=gen_random_uuid();
  first_event uuid:=gen_random_uuid();
  final_event uuid:=gen_random_uuid();
  missing_event uuid:=gen_random_uuid();
  signer_key text:='isolated-transaction-check';
  body jsonb;
  common jsonb;
  done int;
BEGIN
  INSERT INTO compact.signer VALUES(signer_key);
  PERFORM compact.grant_batch(ARRAY[request_id],ARRAY[attempt],ARRAY[gen_random_uuid()],ARRAY[1002]);
  common:=jsonb_build_object('attempt_id',attempt,'signature','transaction-test-only','usage',jsonb_build_object(),'origin_identity','transaction-test','origin_incarnation',gen_random_uuid(),'origin_session_id',gen_random_uuid());
  INSERT INTO compact.evidence VALUES(first_event,attempt,1,signer_key,common||jsonb_build_object('event_id',first_event,'source_revision','1'));
  body:=common||jsonb_build_object('event_id',final_event,'source_revision','2');
  BEGIN
    PERFORM compact.settle_with_evidence(ARRAY[request_id],ARRAY[attempt],ARRAY[first_event],ARRAY[final_event],ARRAY[7],ARRAY[3],ARRAY[5],ARRAY[2],signer_key,ARRAY[2]::smallint[],ARRAY[body::text],ARRAY[missing_event,final_event],ARRAY[request_id,request_id],ARRAY[1,2]::smallint[]);
    RAISE EXCEPTION 'expected missing evidence to reject the whole terminal statement';
  EXCEPTION WHEN foreign_key_violation THEN NULL;
  END;
  IF EXISTS(SELECT FROM compact.terminal t WHERE t.first_event=probe.first_event)
    OR EXISTS(SELECT FROM compact.evidence v WHERE v.event_id=final_event)
    OR EXISTS(SELECT FROM compact.outbox o WHERE o.event_id IN (first_event,final_event))
    OR NOT EXISTS(SELECT FROM compact.wallet w WHERE w.id=1002 AND (w.spent,w.reserved)=(0,100))
    OR NOT EXISTS(SELECT FROM compact.evidence v WHERE v.event_id=first_event) THEN
      RAISE EXCEPTION 'rollback changed previous grant/evidence or leaked a terminal mutation';
  END IF;
  done:=compact.settle_with_evidence(ARRAY[request_id],ARRAY[attempt],ARRAY[first_event],ARRAY[final_event],ARRAY[7],ARRAY[3],ARRAY[5],ARRAY[2],signer_key,ARRAY[2]::smallint[],ARRAY[body::text],ARRAY[first_event,final_event],ARRAY[request_id,request_id],ARRAY[1,2]::smallint[]);
  IF done<>1 OR NOT EXISTS(SELECT FROM compact.terminal t WHERE t.first_event=probe.first_event AND t.final_event=probe.final_event AND t.customer_atoms=100 AND t.supplier_atoms=59)
    OR (SELECT count(*) FROM compact.posting pp WHERE pp.request_id=probe.request_id)<>4
    OR (SELECT count(*) FROM compact.outbox o WHERE o.event_id IN (first_event,final_event))<>2 THEN
      RAISE EXCEPTION 'unexpected successful terminal effects';
  END IF;
END $$;
ROLLBACK;
