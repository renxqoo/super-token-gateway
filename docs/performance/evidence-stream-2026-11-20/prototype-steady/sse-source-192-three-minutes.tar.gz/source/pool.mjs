import assert from "node:assert/strict";
import {generateKeyPairSync} from "node:crypto";

export async function createPool(size){
 const keys=generateKeyPairSync("ed25519"),secret=keys.privateKey.export({format:"pem",type:"pkcs8"}),publicKey=keys.publicKey.export({format:"pem",type:"spki"});
 function bounded(promise,tag){let alarm;return Promise.race([promise,new Promise((_,reject)=>{alarm=setTimeout(()=>reject(Error("plugin lane timeout "+tag)),10000);})]).finally(()=>clearTimeout(alarm));}
 const workers=[],counts={},snapshots=[];let artifacts;
 async function add(){
   const worker=new Worker(new URL("./lane.mjs",import.meta.url).href,{ref:true});
   const listening=Promise.withResolvers(),tickets=new Map([["listening",listening]]),active=new Set();
   function command(type,reply,args={}){
     const d=Promise.withResolvers();tickets.set(reply,d);worker.postMessage({type,...args});return bounded(d.promise,reply);
   }
   function lost(err){for(const d of tickets.values())d.reject(err);tickets.clear();for(const fail of active)fail(err);}
   worker.onerror=e=>lost(new Error(e.message));worker.onmessage=({data})=>{if(data.type==="fatal"){lost(Error(data.error));return;}const d=tickets.get(data.type);tickets.delete(data.type);d?.resolve(data);};
   workers.push({worker,command,active});
   await bounded(listening.promise,"listening");const r=await command("init","ready",{secret});assert.equal(r.artifacts.publicKey,publicKey);
   if(artifacts)assert.deepEqual(r.artifacts,artifacts);else artifacts=r.artifacts;
 }
 try{await Promise.all(Array.from({length:size},add));}catch(e){await Promise.all(workers.map(w=>w.worker.terminate()));throw e;}
 async function invoke(x,input,origin,{progress,settle,signal,release,failure}){
   const owner=workers[x.seq%size],{port1:port,port2}=new MessageChannel(),head=Promise.withResolvers();
   let read,closed=false;
   function stop(){
     if(closed)return;closed=true;owner.active.delete(fail);signal.removeEventListener("abort",cancel);port.close();release();
   }
   function fail(e){if(closed)return;failure(e);head.reject(e);read?.reject(e);port.postMessage({type:"cancel"});stop();}
   const cancel=()=>fail(new Error("client_cancelled"));
   port.onmessage=async({data})=>{
     try{
       if(data.type==="fact"){
         const e=data.event;assert.equal(e.attempt_id,x.attempt);assert.equal(+e.source_revision,x.events.length+1);
         x.events.push(e);x.trace.push(data.point);x.first??=e.event_id;
         if(data.kind==="settle"){
           x.final=e.event_id;x.verified=data.verified;const u=e.usage;
           x.input=+u.input_tokens;x.cached=+u.cached_input_tokens;x.output=+u.output_tokens;x.reasoning=+u.reasoning_tokens;
           await settle(x);
         }else await progress(x);
         port.postMessage({type:"ack",terminal:x.terminal});
       }else if(data.type==="headers"){Object.assign(x,data.times);head.resolve(data.headers);}
       else if(data.type==="chunk"){assert(read);const next=read;read=undefined;next.resolve({done:false,value:data.bytes});}
       else if(data.type==="end"){assert(read);Object.assign(x,data.times);x.trace=data.trace;const next=read;read=undefined;next.resolve({done:true});stop();}
       else if(data.type==="error")fail(Error(data.error));
     }catch(e){port.postMessage({type:"reject",error:String(e)});fail(e);}
   };
   owner.active.add(fail);signal.addEventListener("abort",cancel,{once:true});
   owner.worker.postMessage({type:"run",port:port2,x:{id:x.id,attempt:x.attempt,seq:x.seq,granted:x.granted},input,origin},[port2]);if(signal.aborted)cancel();
   const headers=await head.promise;
   return new Response(new ReadableStream({
     async pull(c){if(closed){c.close();return;}assert(!read);read=Promise.withResolvers();port.postMessage({type:"read"});const item=await read.promise;if(item.done)c.close();else c.enqueue(item.value);},
     cancel
   },{highWaterMark:0}),{headers});
 }
 async function collect(){const replies=await Promise.all(workers.map(w=>w.command("stats","stats")));
   for(const [i,r] of replies.entries()){snapshots[i]=r.snapshot;for(const [k,n] of Object.entries(r.counts))counts[k]=(counts[k]??0)+n;}
 }
 async function close(){await Promise.all(workers.map(async w=>{await w.command("close","closed");w.worker.terminate();}));}
 return {invoke,artifacts,publicKey,counts,collect,snapshot:()=>snapshots,close};
}
