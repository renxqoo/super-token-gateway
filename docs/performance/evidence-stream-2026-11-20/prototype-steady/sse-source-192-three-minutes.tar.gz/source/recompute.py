import csv
import hashlib
import itertools
import json
import math
import sys
from contextlib import ExitStack
from pathlib import Path


def recompute(prefix):
    def path(ext):
        return Path(str(prefix) + ext)

    report = json.loads(path(".json").read_text())
    cfg = report["configuration"]
    start = report["accounting"]["startEpochMs"]
    end = start + cfg["seconds"] * 1000
    with ExitStack() as stack:
        def rows(ext):
            return csv.DictReader(stack.enter_context(path(ext).open()), delimiter="\t")

        for ext, expected in report["identitySha256"].items():
            with path(ext).open("rb") as f:
                digest = hashlib.sha256()
                for block in iter(lambda: f.read(1 << 20), b""):
                    digest.update(block)
                assert digest.hexdigest() == expected, ext

        by_provider = {}
        for r in rows(".upstream.tsv"):
            uid = r["request_id"]
            assert uid not in by_provider
            by_provider[uid] = (r["attempt_id"], int(r["calls"]), int(r["upstream_received_epoch_ms"]), int(r["provider_done_epoch_ms"]), int(r["provider_eof_epoch_ms"]))

        by_ack = {}
        for r in rows(".ack.tsv"):
            eid = r["event_id"]
            assert eid not in by_ack
            by_ack[eid] = (r["request_id"], r["attempt_id"], r["revision"], int(r["ack_observed_epoch_ms"]))

        def num(row, name):
            return float(row[name] or 0)

        def ordered(*times):
            return all(a > 0 and b >= a - .0001 for a, b in zip(times, times[1:]))

        latencies = []
        firsts = []
        leads = []
        seen_http = set()
        event_groups = itertools.groupby(rows(".events.tsv"), key=lambda r: r["request_id"])
        events_iter = iter(event_groups)
        def group():
            item = next(events_iter, None)
            return (item[0], list(item[1])) if item else (None, [])
        ident, events = group()
        total_events = 0
        barrier = 0
        within = 0
        valid_http = 0
        observed_ids = set()
        for seq, items in enumerate(itertools.zip_longest(rows(".http.tsv"), rows(".identities.tsv"))):
            h, x = items
            assert int(h["seq"]) == int(x["seq"]) == seq
            uid = h["request_id"]
            assert uid == x["request_id"] and uid not in seen_http
            seen_http.add(uid)
            attempt = x["attempt_id"]
            plan = start + seq * 1000 / cfg["rate"]
            assert abs(float(h["scheduled_epoch_ms"]) - plan) < .001
            assert num(h,"scheduled_epoch_ms") == num(x,"scheduled_epoch_ms") and num(h,"dispatched_epoch_ms") == num(x,"dispatched_epoch_ms")
            valid = h["valid"] == "1" and h["status"] == "200"
            valid_http += valid
            finish = num(h, "http_validated_epoch_ms")
            first = num(h, "first_content_epoch_ms")
            done = num(h, "done_epoch_ms")
            assert first == num(x,"client_first_content_epoch_ms") and done == num(x,"client_done_epoch_ms") and finish == num(x,"http_validated_epoch_ms")
            provider = by_provider.pop(uid, None)
            recs = []
            if ident == uid:
                recs = events
                ident, events = group()
            total_events += len(recs)
            if provider and first and first < provider[3]:
                leads.append(provider[3] - first)
            if not recs and not provider:
                assert not x["complete_epoch_ms"]
                continue
            complete = True
            if not provider:
                complete = False
                provider = (None, 0, 0, 0, 0)
            pa, calls, received, provider_done, provider_eof = provider
            assert provider_done == num(x,"provider_terminal_epoch_ms") and provider_eof == num(x,"provider_eof_epoch_ms") and received == num(x,"upstream_receive_epoch_ms")
            complete &= calls == 1 and pa == attempt
            sent = num(x,"upstream_send_epoch_ms")
            grant = num(x,"grant_witness_epoch_ms")
            arrival = num(x,"public_arrival_epoch_ms")
            dispatched = num(h,"dispatched_epoch_ms")
            eof = num(x,"gateway_eof_epoch_ms")
            settled = num(x,"terminal_witness_epoch_ms")
            released = num(x,"done_release_epoch_ms")
            verified = num(x,"evidence_verified_epoch_ms")
            complete &= ordered(plan,dispatched,arrival,grant,sent,received,provider_done,provider_eof,eof,verified,settled,released,done,finish)
            complete &= ordered(received,num(h,"headers_epoch_ms"),num(h,"first_byte_epoch_ms"),num(h,"first_frame_epoch_ms"),first,done)
            complete &= valid and x["db_matched"] == "1" and int(x["wallet"]) == seq % 1000 and len(recs) >= 2
            if recs:
                complete &= recs[0]["event_id"] == x["first_event"] and recs[-1]["event_id"] == x["final_event"]
                complete &= recs[-1]["outcome"] == "SUCCEEDED" and recs[-1]["finality"] == "FINAL" and recs[-2]["finality"] == "FINAL" if len(recs)>=2 else False
            latest = 0
            previous = 0
            for rev, r in enumerate(recs,1):
                eid = r["event_id"]
                assert eid not in observed_ids
                observed_ids.add(eid)
                signed = int(r["signed_epoch_ms"])
                witness = int(r["durable_witness_epoch_ms"])
                ordinary = num(r,"next_ordinary_output_epoch_ms")
                ack = by_ack.pop(eid,None)
                complete &= r["attempt_id"] == attempt and int(r["revision"]) == rev and previous <= signed
                complete &= ordered(signed,witness,*([ordinary] if ordinary else []),released)
                previous = witness
                if not ack:
                    complete = False
                    continue
                complete &= ack[:3] == (uid,attempt,str(rev)) and int(r["ack_observed_epoch_ms"]) == ack[3] and ack[3]>=signed
                latest = max(latest,ack[3])
                if rev==1 and r["finality"]=="PARTIAL" and ordered(witness,ordinary,first):
                    barrier += 1
            assert latest == num(x,"last_ack_observed_epoch_ms")
            completion = max(finish,settled,latest) if complete else 0
            assert completion == num(x,"complete_epoch_ms"), (seq,uid)
            if completion:
                latencies.append(completion-plan)
                firsts.append(first-plan)
                within += start <= completion < end
        assert not by_provider and not by_ack and ident is None
        assert len(seen_http) == cfg["count"]
    def quantile(xs):
        return round(sorted(xs)[math.ceil(len(xs)*.99)-1],3) if xs else None
    out = {"offers":len(seen_http),"httpValidated":valid_http,"allEvidence":total_events,"intersection":len(latencies),"within":within,"rps":within/cfg["seconds"],"p99Ms":quantile(latencies),"firstContentP99Ms":quantile(firsts),"earlyContent":len(leads),"minimumEarlyLeadMs":min(leads,default=None),"witnessedPartialBeforeContent":barrier}
    assert out["within"] == report["accounting"]["inWindow"] and out["intersection"] == report["accounting"]["complete"]
    assert out["p99Ms"] == report["metrics"]["completeLatencyMs"]["0.99"]
    assert out["earlyContent"] == report["accounting"]["earlyFirstContentBeforeProviderDone"]
    assert out["witnessedPartialBeforeContent"] == report["accounting"]["partialWitnessBeforeFirstContent"]
    return out


if __name__ == "__main__":
    print(json.dumps(recompute(Path(sys.argv[1])),ensure_ascii=False,indent=2))
