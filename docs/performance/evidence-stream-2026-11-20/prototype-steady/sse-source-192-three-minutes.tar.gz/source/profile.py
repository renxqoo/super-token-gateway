import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

prefix = Path(sys.argv[1])
report = json.loads(Path(str(prefix)+".json").read_text())
with open(str(prefix)+".identities.tsv") as f:
    records = {r["request_id"]: r for r in csv.DictReader(f,delimiter="\t") if r["complete_epoch_ms"]}
stages = Path(str(prefix)+".stages.tsv")
if stages.exists():
    with stages.open() as f:
        for r in csv.DictReader(f,delimiter="\t"):
            if r["request_id"] in records:
                records[r["request_id"]].update(r)
pairs = {
    "fetchToIngress":("dispatched_epoch_ms","public_arrival_epoch_ms"),
    "ingressToGrant":("public_arrival_epoch_ms","grant_witness_epoch_ms"),
    "grantToSend":("grant_witness_epoch_ms","upstream_send_epoch_ms"),
    "providerReceiveToEof":("upstream_receive_epoch_ms","provider_eof_epoch_ms"),
    "providerEofToGatewayEof":("provider_eof_epoch_ms","gateway_eof_epoch_ms"),
    "ingressToTerminalRelease":("public_arrival_epoch_ms","done_release_epoch_ms"),
    "upstreamSendToHeaders":("upstream_send_epoch_ms","upstream_headers_ms"),
    "upstreamHeadersToOpen":("upstream_headers_ms","stream_opened_ms"),
    "openToFeed":("stream_opened_ms","first_feed_started_ms"),
    "feedIncludingWitness":("first_feed_started_ms","last_feed_finished_ms"),
    "feedEndToGatewayEof":("last_feed_finished_ms","gateway_eof_epoch_ms"),
    "gatewayEofToOutcomeSignature":("gateway_eof_epoch_ms","evidence_verified_epoch_ms"),
    "signatureToTerminalWitness":("evidence_verified_epoch_ms","terminal_witness_epoch_ms"),
    "doneToClientCompletion":("done_release_epoch_ms","http_validated_epoch_ms"),
}
durations=defaultdict(list)
for r in records.values():
    for k,(a,b) in pairs.items():
        if r.get(a) and r.get(b):
            durations[k].append(float(r[b])-float(r[a]))
out={}
for k,values in durations.items():
    values.sort()
    out[k]={str(q):round(values[math.ceil(q*len(values))-1],3) for q in (.5,.95,.99)}
print(json.dumps({"requests":len(records),"elapsedMs":out,"cpuSeconds":{k:round(v["cpu_seconds"],3) for k,v in report["metrics"]["cpu"].items()}},ensure_ascii=False,indent=2))
