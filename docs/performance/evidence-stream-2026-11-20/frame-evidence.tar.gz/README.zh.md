# 短 Chat SSE 的累计用量与插件 IPC

固定 Bun 1.4.4。每次只创建一条请求，执行真实 OpenAI prepare、流式 worker ABI、Ed25519 源证据签验，正常成功在合成 record 完成后释放终结帧。各组使用相同的 18 种输入，按原始字节取 SHA256。没有网络、PG、资源授权或独立消费者，本实验只测本进程及其一个 worker 线程的已签名插件流处理。原生 WASM、所有 5 个 builtin 的 fixture 一致性另见测试日志。

## 分开应用的改动

宿主补丁 `host-progress-complete.patch` 以仓库 5ce3f35 为基准。代码只给 progressive 证据桥启用。可输出的计量帧在下一帧前交还本轮进度。被保留的前一用量会在被另一数量覆盖或读失败时先交给原来的签证记录器。如果末帧与已保留数量相同，证据仍可直接升级为 FINAL，不为普通短流共包增加一张发票。记录失败、数据不合法和取消都阻止后继终结数据释放。原生 ABI 的未观察调用保留原先行为。对已使用第一版 final 补丁的树，只需追加 `host-progress-incremental.patch`。完整修正 38/38 个定向用例通过，共 2891 项断言。两供应商的红证据和后续 invalid_json 回归红证据均已保留。

`adapter-1.9.2-source.patch` 为独立的试验包。普通非计量文本帧先检查外层结构与 usage 是否存在，在一次检查答复内完成结构判定、模型改写与输出。真实 usage 仍先解析后暴露快照，工具仍穿过原缓冲预算及验证。原生 WASM 构建和 15 次重建验证见日志。候选签包的 ID 为 gateway.openai-chat-1.9.2，合成私钥在进程内生成后销毁，公开 policy 和双签元数据保留。它没有经过产品 Core 中的真实管理批准或部署。旧版 1.9.1 的不可变包不应被替换。

## 读表

`stock-191.json` 是从 HEAD 基线宿主源码另行打包的 1.9.1。`final-old.json` 记录原工作区此前冻结的 1.9.1 构建产物，两个基线均可复现同读批丢失中间用量。`release-host-191.json` 为修复宿主和原 1.9.1。`release-192.json` 使用相同修复宿主和合成 1.9.2，三份结构化报告包含每个输入的字节摘要、发回的字节摘要、观测序列、失败详情、真正的 prepare/stream IPC 次数。普通五帧 short 为 2 次 prepare、23→14 次 stream。64 笔串行短流的进程 CPU 包括当前进程和一个同进程 Worker，不含真实 HTTP、SQL 和客户端。各组全部释放 attempt、worker、文档、输出与计时器。不能将本实验的时间换算为公开网关容量。

## 重放

在两个完整隔离的 checkout 中使用固定工具链和依赖。保留一个 5ce3f35 基线，并为新 checkout 应用完整宿主补丁及 1.9.2 源补丁。使用仓库已有的确定性工具缓存和 native plugin-host。新树先执行 `bun --no-env-file scripts/build-plugins.ts --adapter openai-chat`，再执行 `bun --no-env-file scripts/build-builtin-worker.ts --prove`，然后用仓库构建生成 `dist/plugin-host/index.js`。对每一树运行 `bun --no-env-file probe.mjs <checkout> <output.json> 64`，用 `STG_HOST_REPO=<new-checkout>` 配合原 1.9.1 checkout 可分别检查包与宿主影响。合成测试签发每次生成新密钥，因此签名与 envelope 摘要应随每次重放改变，包内容、WASM 和 worker 身份则由源码与锁定构建控制。
