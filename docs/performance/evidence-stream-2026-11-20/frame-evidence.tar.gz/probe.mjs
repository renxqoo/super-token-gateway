import assert from "node:assert/strict";
import {resolve} from "node:path";
import {pathToFileURL} from "node:url";
import {createHash, generateKeyPairSync, sign, verify} from "node:crypto";
const repo=resolve(process.argv[2]), out=process.argv[3], sample=Number(process.argv[4]??20);
const mod=p=>import(pathToFileURL(resolve(repo,p)).href);
const read=p=>Bun.file(resolve(repo,p)).bytes();
const hostRoot=resolve(process.env.STG_HOST_REPO ?? repo);
const host=await import(pathToFileURL(resolve(hostRoot,"dist/plugin-host/index.js")).href);
const {syntheticChatPackage}=await mod("tests/support/plugin-package.ts");
const {coreEvidenceEventV1Schema,evidenceProofFields,signedCoreEvidenceEventV1Schema}=await mod("packages/contracts/src/core-execution.ts");
const {canonical}=await mod("packages/kernel/src/canonical.ts");
const hash=x=>createHash("sha256").update(x).digest("hex");
const releaseKey=generateKeyPairSync("ed25519");
const signed=await syntheticChatPackage(releaseKey);
const {describeRelease,verifyRelease}=await mod("apps/core-api/src/plugins/releases.ts");
const runtimeDigest=hash(await read(".local/plugin-host"));
const descriptor=describeRelease(signed.pkg.files,signed.bytes,runtimeDigest);
const descriptorDigest=hash(canonical(descriptor));
const testKeyId=signed.envelope.signature.key_id;
const policy={format:1,expires_at:"2100-01-01T00:00:00Z",revoked:false,
  keys:[{id:testKeyId,public_key:releaseKey.publicKey.export({format:"pem",type:"spki"}),not_before:"2000-01-01T00:00:00Z",expires_at:"2100-01-01T00:00:00Z",revoked:false,purposes:["package","release"],release_ids:[descriptor.release_id]}],
  releases:[{release_id:descriptor.release_id,descriptor_digest:descriptorDigest,package_digest:descriptor.package_digest,abi_version:1,config_schema_digest:descriptor.config_schema_digest,fixture_digest:descriptor.fixture_digest,validation_policy_digest:descriptor.validation_policy_digest,runtime_digest:runtimeDigest,revoked:false}]};
const release={descriptor,signature:{algorithm:"Ed25519",key_id:testKeyId,value:sign(null,Buffer.from("gateway-plugin-release-v1\0"+canonical(descriptor)),releaseKey.privateKey).toString("base64")}};
await verifyRelease(signed.bytes,release,policy,runtimeDigest);
await Bun.write(out+".fixture.json",JSON.stringify({release,policy}));
if(process.env.STG_SAVE_ENVELOPE==="1") await Bun.write(out+".package.json",signed.bytes);

const verified=host.verifyPackage(signed.bytes,signed.trust), rt=host.verifiedPackageRuntime(verified);
const code=await read(".local/builtin-adapters/worker.js"), regBytes=await read(".local/builtin-adapters/registry.json");
const bhash=hash(await Bun.file(process.execPath).bytes());
const reg=host.parseBuiltinWorkerArtifact(JSON.parse(Buffer.from(regBytes).toString()),code,bhash), record=reg.records.find(r=>r.package_digest===rt.digest);
assert(record);assert.equal(host.pluginModuleInfo(rt.module).hash,record.module_hash);assert.equal(record.release_id,rt.manifest.id+"-"+rt.manifest.version);
const worker=host.createBuiltinWorkerExecutor({code,digest:reg.worker_digest,modules:reg.records.map(r=>r.module_hash),slots:1,maxPending:4});
const attempts=host.createPluginAttempts(worker,{maxAttempts:2,maxStateBytes:2*(256<<10)});
const config=host.validateConfig(rt.configSchema,{model_map:{logical:"upstream"},max_output_tokens:100,max_input_tokens:4096,auth:"bearer"});
const signing=generateKeyPairSync("ed25519"),identity={origin_identity:"gateway:synthetic-stream-test",origin_incarnation:crypto.randomUUID(),origin_session_id:crypto.randomUUID()};
const proof=e=>Buffer.from(JSON.stringify(evidenceProofFields(e,hash(canonical(e)))));
const req=JSON.stringify({model:"logical",messages:[{role:"user",content:"合成"}],stream:true});
const wire=x=>"data: "+JSON.stringify({model:"upstream",...x})+"\n\n";
const choice=(delta,finish_reason=null)=>({choices:[{index:0,delta,finish_reason}]});
const usage=n=>({prompt_tokens:10,prompt_tokens_details:{cached_tokens:3},completion_tokens:n,...(n>=2?{completion_tokens_details:{reasoning_tokens:2}}:{})});
const role=wire(choice({role:"assistant"})), content=wire(choice({content:"你好🌏"})), finish=wire(choice({},"stop")), final=wire({choices:[],usage:usage(5)}), done="data: [DONE]\n\n";
const tool1=wire({...choice({tool_calls:[{index:0,id:"call1",type:"function",function:{name:"weather",arguments:'{"city":'}}]}),usage:usage(1)});
const tool2=wire(choice({tool_calls:[{index:0,function:{arguments:'"北京"}'}}]})),toolend=wire(choice({},"tool_calls"));
const scenarios={
  short:[role,content,finish,final,done],
  shortBurst:[[role,content,finish,final,done].join("")],
  absent:[role,content,finish,done],
  progressive:[role,wire({...choice({content:"a"}),usage:usage(1)}),wire({...choice({content:"b"}),usage:usage(3)}),finish,final,done],
  toolUsage:[role,tool1,tool2,toolend,final,done],
  badTool:[tool1,toolend,done],
  usageWithError:[wire({error:{message:"upstream"},choices:[],usage:usage(3)})],
  usageWithBadChoice:[wire({choices:17,usage:usage(3)})],
  badUsage:[wire({...choice({content:"x"}),usage:"invalid"})],
  truncated:[role,content,finish,final],
  sliced:[...Buffer.from([role,content,finish,final,done].join(""))].map(v=>new Uint8Array([v])),
  burstMulti:[[role,wire({...choice({content:"a"}),usage:usage(1)}),...Array(5).fill(content),wire({...choice({content:"b"}),usage:usage(3)}),...Array(5).fill(content),finish,final,done].join("")],
  dense:[role+wire({...choice({content:"a"}),usage:usage(1)})+wire({...choice({content:"b"}),usage:usage(3)})+finish+final+done],
  held:[role+content+finish+wire({choices:[],usage:usage(1)})+wire({choices:[],usage:usage(3)})+final+done],
  validThenError:[wire({...choice({content:"cut"}),usage:usage(1)})+wire({error:{message:"fail"},choices:[],usage:usage(3)})],
  heldThenError:[role+content+finish+wire({choices:[],usage:usage(1)})+wire({error:{message:"fail"},choices:[],usage:usage(3)})],
  cancelledAfterUsage:[wire({...choice({content:"cut"}),usage:usage(1)}),content],
  cancelled:[content]
};
const checkpoints=new Set(["short","shortBurst","absent","progressive","toolUsage","sliced","burstMulti","dense","held"]);
async function run(name,keep=true){
  const id=crypto.randomUUID(),one=attempts.create(verified,{tenant:"synthetic-tenant",attempt:id,incarnation:identity.origin_incarnation,deadlineAt:Date.now()+20000,config});
  let received="",terminal,error=null,prepMsgs=0,streamMsgs=0, released=false,releaseCheckpoint,enteredCheckpoint,recorded=0;
  const markers=[], signedEvents=[], controller=new AbortController();
  const atCheckpoint=new Promise(r=>enteredCheckpoint=r), canRelease=new Promise(r=>releaseCheckpoint=r);
  const bridge=host.observeAttempt(one,{attemptId:id,permitEpoch:"1",delivery:"progressive",
    seal(f){const event=coreEvidenceEventV1Schema.parse({...identity,...f});return signedCoreEvidenceEventV1Schema.parse({...event,signature:sign(null,proof(event),signing.privateKey).toString("base64url")});},
    async record(batch){for(const {signature,...e} of batch){assert(verify(null,proof(e),signing.publicKey,Buffer.from(signature,"base64url")));assert.equal(e.attempt_id,id);assert.equal(Number(e.source_revision),recorded+1);recorded++;signedEvents.push([e.finality,e.usage,e.attempt_state??null]);if(e.attempt_state){enteredCheckpoint();await canRelease;}}}
  });
  function accept(r){if(r.kind==="failure"){error={code:r.code,usage:r.usage??null,finality:r.finality??null};return true;}assert.equal(r.kind,"output");for(const c of r.chunks)received+=Buffer.from(c,"base64").toString();assert(!received.includes("[DONE]"));if(r.terminal)terminal=r.terminal;if(r.output_id)one.releaseOutput(r.output_id);return r.needs_input||!!terminal;}
  async function call(hook,payload){return await bridge.invoke(hook,payload,controller.signal);}
  try {
    const prep=await one.transformJSON("prepare",{protocol:"chat",operation:"chat",model:"logical",input_characters:"2"},Buffer.from(req));
    assert.equal(prep.result.kind,"prepared");assert.equal(JSON.parse(Buffer.from(prep.body)).model,"upstream");
    prepMsgs=one.snapshot().sequence;
    accept(await call("stream_open",Buffer.from(JSON.stringify({model:"logical",protocol:"chat"}))));
    for(const input of scenarios[name]){
      const part=Buffer.from(input);
      if(name==="cancelled"||(name==="cancelledAfterUsage"&&recorded))controller.abort();
      if(!terminal)for(let offset=0;offset<part.length;){
        const fed=await call("stream_feed",part.subarray(offset));let stop=accept(fed);
        while(!error&&!stop)stop=accept(await call("stream_drain"));
        if(error)break;
        assert(fed.consumed>0);offset+=fed.consumed;
      }
      if(keep && name!=="sliced")markers.push([received.length,signedEvents.map(e=>e[1]?.output_tokens??null),!!terminal]);
      if(error)break;
    }
    if(!error)accept(await call("stream_finish"));
    if(!error&&checkpoints.has(name)){
      assert.equal(terminal?.kind,"complete");
      const finishing=bridge.finish({attempt_state:"SUCCEEDED",request_state:"SUCCEEDED"},true).then(()=>{released=true;received+=Buffer.from(terminal.bytes,"base64").toString();});
      await atCheckpoint;assert(!released);assert(!received.includes("[DONE]"));releaseCheckpoint();await finishing;assert(received.endsWith(done));assert(!received.includes('"model":"upstream"'));
    }
  }catch(e){if(!name.startsWith("cancelled"))throw e;error={code:e.code??e.message,usage:null,finality:null};}
  finally{streamMsgs=one.snapshot().sequence-prepMsgs;bridge.dispose();one.dispose();assert.equal(attempts.snapshot().attempts,0);assert.equal(attempts.snapshot().stateBytes,0);}
  if(checkpoints.has(name))assert.equal(error,null,name);else assert(error,name);
  if(name==="progressive")assert.deepEqual(signedEvents.map(e=>[e[0],e[1].output_tokens]),[["PARTIAL","1"],["PARTIAL","3"],["PARTIAL","5"],["FINAL","5"],["FINAL","5"]]);
  if(["usageWithBadChoice","usageWithError"].includes(name))assert.equal(error?.usage?.output_tokens,"3");
  return {prepMsgs,streamMsgs,receivedSha256:hash(received),receivedBytes:Buffer.byteLength(received),error,signedEvents,markers,inputSha256:hash(Buffer.concat(scenarios[name].map(x=>Buffer.from(x))))};
}
try {
const cases={};for(const name of Object.keys(scenarios))cases[name]=await run(name);
const ms=[],cpuStart=process.cpuUsage();for(let i=0;i<sample;i++){const start=performance.now();await run("short",false);ms.push(performance.now()-start);}
const sorted=[...ms].sort((a,b)=>a-b), snap={worker:worker.snapshot(),attempts:attempts.snapshot()};
const cpuUs=process.cpuUsage(cpuStart);
await attempts.close();const closed={worker:worker.snapshot(),attempts:attempts.snapshot()};assert.equal(closed.worker.workers,0);assert.equal(closed.worker.pending,0);assert.equal(closed.attempts.attempts,0);
const summary={releaseId:descriptor.release_id,releaseDescriptorSha256:descriptorDigest,releaseVerified:true,runtime:Bun.version,packageDigest:rt.digest,wasm:record.module_hash,registrySha256:hash(regBytes),artifactDigest:reg.artifact_digest,hostSha256:hash(await Bun.file(resolve(hostRoot,"dist/plugin-host/index.js")).bytes()),workerDigest:reg.worker_digest,runtimeDigest:bhash,signedFixtureSha256:hash(signed.bytes),sourceSha256:hash(await read("packages/adapters/openai-chat/plugin.ts")),cases,shortSequential:{n:ms.length,wallMs:ms,cpuUs,cpuMsPerRequest:(cpuUs.user+cpuUs.system)/(1000*sample),medianMs:sorted[Math.floor(ms.length/2)]},snap,closed};
await Bun.write(out,JSON.stringify(summary,null,2)+"\n");console.log(JSON.stringify({out,streamIPC:cases.short.streamMsgs,prepareIPC:cases.short.prepMsgs,medianMs:summary.shortSequential.medianMs,resources:snap}));
}finally{await attempts.close();}
