import { resolve } from "node:path";
const { createMockApp } = await import(resolve("apps/mock-providers/src/app.ts"));
const { startTlsUpstream } = await import(resolve("tests/support/gateway-process.ts"));
const { app, scenarios } = createMockApp("local-diagnostic");
scenarios.set("synthetic", {echoRequestChallenge:true});
const upstream = await startTlsUpstream(app.fetch);
try {
  const response=await fetch(upstream.baseUrl+"/openai/v1/chat/completions",{tls:{ca:await Bun.file(upstream.certificate).text()},method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({model:"synthetic",messages:[{role:"user",content:"capacity"}],max_completion_tokens:30,stream:true,stream_options:{include_usage:true},user:crypto.randomUUID()+"00000001"})});
  const bytes=await response.bytes();
  console.log(JSON.stringify({status:response.status,headers:Object.fromEntries(response.headers),bytes:bytes.length,done:new TextDecoder().decode(bytes).trimEnd().endsWith("data: [DONE]")}));
} finally {await upstream.stop()}
