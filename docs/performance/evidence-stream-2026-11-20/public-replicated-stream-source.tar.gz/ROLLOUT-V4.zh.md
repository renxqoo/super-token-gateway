# 已签短 Chat SSE 的同步终态候选

公开路径仍执行已批准 1.9.1 插件。准入已以同一条命令授予发送权、无资源和协议转换、客户固定按请求完成计价，且原生传输返回未编码的 chunked 或已声明 Content-Length SSE 完整终态时，可合并最初两份 FINAL 签名。SSL/TLS 已认证的首次 grant 响应必须显式声明能力。首次包之前已签 PARTIAL、UNKNOWN 或其他进度，供方冻结价格中有缺少的最终维度，或前端操作不符时，通过普通证据队列提交。可见字节与终态来自同一批时，一起等候指定 PG 副本，然后由下游拉取，从普通增量到尾帧保留预算。已在更早一批产生的无计量内容立即发出。固定长度模式同时等待 HTTP 消息体 EOF 并核对每个已收字节，才准提交终态。HTTP 持久连接可以继续复用。真实原生传输忽略压缩、含多重 transfer-encoding 或无法认证消息边界的响应。计量后客户端取消、末帧后续坏字节、消息不全或读错均以原签名处理并阻止改投其他上游。

## 启用

1. 以已有负责部署角色和授权的账号应用更新后的 `infra/core-terminal-settlement-roles.sql`。新增的只读 view 只投影已发放的初次流式 grant、资金所有者、permit epoch 与供应价格维度。检查两侧 Core 使用同一恢复 Redis 配置、AOF 副本和命名空间。指定物理 PG 从库仍需满足已有 remote_apply 条件。
2. 先升级 Core，显式设置 `terminal_settlement.commit_short_chat_sse: false`。该配置禁止在线提交，启动 SSE 恢复消费者。`core-sse-terminal-recovery` 和原 `core-terminal-recovery` 是不同 scope，旧二进制不会认领 SSE 任务。确认恢复消费就绪、旧队列正常，才能开启新写入。未提供这个字段的旧配置保持原队列集合。
3. 在候选 Core 上启用 `terminal_settlement.commit_short_chat_sse: true`。只有其新鲜已认证流式 grant 会携带 `stream_terminal_v1`。网关在已有 `commit_short_chat` 和复制恢复队列之外，另需显式启用 `commit_short_chat_sse: true`。无声明时使用原普通 AOF 路径。若已声明的 Core 后续明确返回“未尝试且功能禁用”，网关用同样两个原签名等待普通 AOF；身份、签名、SQL、价格或备库拒绝/不确定都不能触发该成功回退。
4. 公开验证可在已有 1.9.1 严格短流命令后增加 `--replicated-stream-terminal`，并保持 `--stream --replicated-short-chat` 及其余参数一致。验收同时检查普通证据、JSON 恢复和 SSE 恢复的 waiting、active、delayed、failed，全部归零。外部消费者独立 ACK 保持原有条件。没有启用新选项的历史负载按其原命令重放。

## 回退

先关闭网关新增选项并排空在途请求，再令新 Core 的字段显式为 false。保留专属恢复消费者、原权限和物理 PG 见证，直到归零 waiting/active/delayed/failed，且既有请求的两侧账、经认证回执与外部 ACK 均可核实。所有旧 Gateway、兼容 Core 和 in-flight 生产者都已停止投递后，才可移除字段或回退二进制。过早删除全部新读者会使任务留在专属持久队列，重启能识别该 scope 的读者后恢复。

## 容量和取消

Gateway 使用已有终态限额，覆盖同批的计量普通字节和尾帧，直至最终拉取或取消。在额度不够时，先向普通证据队列交付原签名 FINAL，才允许输出。已记录用量的坏帧进入失败收口。插件生命期比客户端等待短时，独立预算继续覆盖未拉取数据。请求总时限到达会撤回缓冲的剩余字节并释放额度。

## 验证边界

V3 完整补丁为 `terminal-v3.patch`，相对 V2 的增量为 `terminal-v3-incremental.patch`。使用固定 Bun 1.4.4。三项真实 1.9.1 Worker 回归的修复前失败详见 `v3-output-red.log`，38 位已签 epoch 经过真实 PG 原先返回命令状态不明，见 `v3-native-red.log`。定向测试、类型和实际构建结果分别在 `v3-offline-pinned.log`、`v3-types.log`、`v3-build.log`。PG 主备和 Redis AOF 主备的 117 项断言记录在 `v3-native-pinned.log`，包含 Gateway 实际 HTTP、指定 PG 备库暂停与恢复、单次模拟上游、签名和金额核对、原路径移走 Redis AOF 副本后无 [DONE]。完整公开容量由独立压测审计。

## 固定长度补充

V3 公开测试期间，标准 mock 的原生 TLS 响应携带 Content-Length。精确复制的单请求见 `one-standard-mock.ts` 与 `one-standard-mock.log`。V3 对该形态走普通证据队列。V4 在保留 AOF 默认模式与 chunked 模式的基础上纳入 Content-Length。完整补丁 `terminal-v4.patch`，相对 V3 的增量 `terminal-v4-incremental.patch`。固定长度受控 EOF 的修复前后记录在 `v4-fixed-red.log` 和 `v4-fixed-green.log`。真实主备测试开始前按正式资金夹具给供应账户充值，1 个用例 122 项断言。额外的单个公开请求在普通 worker 启动前经仓库默认 mock、真实插件、3/1/7 费率、认证与签名，正文含该笔 challenge 和 DONE，指定备库返回该 ID 的 100/59 和两个已认证成功回执。
