import collections, datetime, json, math, pathlib, sys
from statistics import median
base=pathlib.Path(__file__).resolve().parent
def ids(p):
    if not p.is_file():return {}
    a={}
    with p.open() as f:
        for line in f:
            k,v=line.rstrip().split('\t')
            assert k not in a
            a[k]=int(v)
    return a
for tag in sys.argv[1:]:
    dr=base/(tag+'-evidence')
    p=json.loads((dr/'audit.json').read_text())
    h=p['http']; o=p['onlineCapacity']
    statements=p['pgStatements']['top25']
    q=lambda pattern:next((r for r in statements if pattern in r['query']),{})
    stats={k:round(q(k).get('total_exec_time',0)/1000,3) for k in ('core_execution_batch_v1','persist_core_evidence_groups_v1','core_short_chat_funding_v1','core_context_v1','WITH candidates AS MATERIALIZED')}
    files={s.name:s for s in dr.glob('*.tsv')}
    cost={k:round(v['cpu_seconds'],3) for k,v in p['processes'].items()}
    http=ids(dr/pathlib.Path(h['identity_log']).name)
    ack=ids(dr/'ack.identities.tsv')
    disp=ids(dr/pathlib.Path(h['dispatch_log']).name)
    start=round(datetime.datetime.fromisoformat(h['measurement_started_at'].replace('Z','+00:00')).timestamp()*1000)
    matched=http.keys()&ack.keys()
    window=sum(start<=max(http[k],ack[k])<start+60000 for k in matched)
    assert len(matched)==o['matchedRequests'] and o['fullyCompletedByWindow']==window
    assert http.keys()==disp.keys()
    latency=sorted(max(http[k],ack[k])-disp[k] for k in matched)
    samples=[r for r in p['timeline'] if isinstance(r.get('at'),(int,float))]
    print(json.dumps(dict(label=tag,valid=p['valid'],capacity=p['capacityPassed'],reason=p['failures'],offered=h['offered'],succeeded=h['succeeded'],errors=h['gateway_errors'],transport=h['transport_errors'],httpP99=h['latency_ms']['p99'],sse=h['sse'],window=window,completeRps=round(window/60,3),verifiedJoinedP99=latency[math.ceil(len(latency)*.99)-1] if latency else None,reportedJoined=o.get('completionLatencyMs'),sqlSeconds=stats,cpuSeconds=cost,peakQueue=max(r['queue']['waiting'] for r in samples),upstream=p['upstream'],accounting=p['accounting'],suppliers=p['supplier'],ackedRequests=p['ackedRequests'],delivered=p['delivered'],receiptConfirmedAcks=p['receiptConfirmedAcks'],artifacts=p['environment']['artifacts'],verifiedIDs=list(files)),indent=2))
